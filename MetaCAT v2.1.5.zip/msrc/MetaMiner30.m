function MetaMiner30(IN,OUTFILE,start,finish,dt,blastall_command,val_N_THREADS)
% To run MetMiner standalone without GUI - all input arguments should be ignored, parameters are then loaded from GetParams

tic
if ~exist('blastall_command') || exist('blastall_command') && isempty(blastall_command)
    blastall_command = [];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD ALGORITHM PARAMETERS

start.metaminer_date = date;
start.metaminer_time = clock;

% running MetaMiner from the command line
if ~exist('IN')
    [IN OUTFILE] = GetParams();
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% READ BLAST TABLE
fprintf('1) Reading BLAST Hit Table file: ''%s''...\n\n',IN.BLAST_file_name)

fid  = fopen(IN.BLAST_file_name,'r');
if fid==-1
    errmsg=sprintf('debug %s.m: cannot open BLAST output file: ''%s''\n',mfilename,IN.BLAST_file_name);
    fprintf('%s\n',errmsg);
    errordlg(errmsg);
    keyboard
end

Table = textscan(fid, '%s %s %f %f %f %f %f %f %f %f %f %f');

if isempty(Table{1})
    errmsg = sprintf('debug %s.m: BLAST output file (%s) is empty\n',mfilename,IN.BLAST_file_name);
    fprintf('%s\n',errmsg);
    errordlg(errmsg);
    keyboard
end

fclose(fid);

Phage_gene_vec        = Table{1};                                       % RefSeq gene ID
Contig_vec            = Table{2};                                       % Metagenome gene object ID
Percent_Ident_vec     = Table{3};                                       % Percent Identity
Align_length_vec      = Table{4};                                       % Length of alignment
Number_of_Ident_vec   = round(Percent_Ident_vec.*Align_length_vec/100); % Number of identical amino acids in alignment
E_value_vec           = Table{11};                                      % E value

clear Table;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REDUCE TABLE TO FIRST HIT FOR EACH REFSEQ GENE AND STORE + COUNT THE NUMBER OF CONTIGS RELATED TO THIS HITS (WITH HIGHER E VALUES)
% HIT TABLE IS ORGANIZED AS FOLLOWS:
%
% REFSEQ GENE 1   - CONTIG #1 ... E VALUE (LOWEST E VALUE)  ---> keep E value
% REFSEQ GENE 1   - CONTIG #2 ... E VALUE                   ---> store contig list
% REFSEQ GENE 1   - CONTIG #3 ... E VALUE
%    :               :
% REFSEQ GENE 2   - CONTIG #1 ... E VALUE (LOWEST E VALUE)  ---> keep E value
% REFSEQ GENE 2   - CONTIG #2 ... E VALUE                   ---> store contig list
% REFSEQ GENE 2   - CONTIG #3 ... E VALUE
%    :               :
fprintf('2) Finding best hit for each RefSeq gene...\n')

j=1;
count=0;
while j<= length(Contig_vec);
    
    % FIND NUMBER OF TIMES EACH REFSEQ GENE HIT APPEARS (=NUMBER OF CONTIGS RELATED TO THE SAME REFSEQ GENE)
    i_vec = find(strcmp(Phage_gene_vec,Phage_gene_vec{j}));
    count = count + 1;
    
    [ttt sel_uniq_ind_vec] = unique(Contig_vec(i_vec)); % Same Contig can appear more than once in blast report for the same REFSEQ gene (if e.g. two or more contigs parts are treated separately)
    % therefore we need the 'unique' function. This may also be important in case tblastn is used for nucl file and the same contig has more
    % than reading frame with a solution. We do not want to count these as separate solutions.
    sel_uniq_ind_vec       = sort(sel_uniq_ind_vec); % keep order of contigs the same
    
    % BEST HIT TABLE (BHT)
    BHT.List_of_contigs{count}         = Contig_vec(i_vec(sel_uniq_ind_vec)); % Select unique contigs (ignore repititions)
    BHT.N_contigs_vec(count)           = length(BHT.List_of_contigs{count}); % Each contig appears only once in this list
    
    % TAKE SCORE OF FIRST CONTIG (=LOWEST E VALUE) FOR EACH REFSEQ PHAGE GENE
    BHT.min_E_value_vec(count)             = E_value_vec(i_vec(1)); % blastall output is such that first contig has the lowest E value
    BHT.max_Percent_Ident_vec(count)       = Percent_Ident_vec(i_vec(1));
    BHT.max_Number_of_Ident_vec(count)     = Number_of_Ident_vec(i_vec(1));
    BHT.Unique_phage_gene_vec(count)       = Phage_gene_vec(i_vec(1));
    BHT.best_Align_length_vec(count)       = Align_length_vec(i_vec(1));
    BHT.best_Gene_len_vec(count)           = -1;
    BHT.best_Align_perc_of_gene_vec(count) = -1;
    BHT.best_seq_vec{count}                = 'N/A';
    BHT.best_description_vec{count}        = 'N/A';
    
    % GO TO NEXT REFSEQ PHAGE HIT
    j = max(i_vec) + 1;
end

clear Phage_gene_vec E_value_vec Number_of_Ident_vec Align_length_vec Contig_vec Percent_Ident_vec;

% PRINT TABLE TO FILE
msg = 'Hit Table showing only the record for the best metagenome gene object for each RefSeq gene (no filtering of RefSeq genes, E value threshold as set in blastall)';
write_RelatedContigs(OUTFILE{2},BHT,msg);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REMOVE ALL REFSEQ GENES THAT DO NOT PASS HOMOLOGY THRESHOLD WITH RESPECT TO BEST HIT IN THE METAGENOME
% Statistic used for sorting in next sheet:  E<=E_th=1e-7 (default value)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n3) Filtering RefSeq genes (E value<=%g)',IN.E_TH );
% Parse the FASTA/GenPept file
if isempty(IN.GENPEP_REFSEQ_FILE)
    fprintf('\nParsing RefSeq FASTA file ''%s''...\n',IN.FASTA_REFSEQ_FILE);
    % try to parse FASTA file retrieving the Definition and file location of every record
    FILE_PARSE = parse_FASTA(IN.FASTA_REFSEQ_FILE);
else
    fprintf('\nParsing RefSeq GenPept file ''%s''...\n',IN.GENPEP_REFSEQ_FILE);
    % try to parse GenPept file retrieving the Version and file location of every record
    FILE_PARSE = parse_GENPEPT(IN.GENPEP_REFSEQ_FILE);
end

if isempty(FILE_PARSE)
    errmsg= sprintf('debug %s.m: problem parsing - no values returned.\n',mfilename);
    fprintf('%s\n',errmsg);
    errordlg(errmsg);
    keyboard;
end
Lrecs = length(FILE_PARSE);
fprintf('\nDone. Read a total of %d RefSeq genes.\n\n',Lrecs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
fprintf('Filtering list:\n');

count = 0;tmp=0;
% FORM FILTERED BLAST HIT TABLE (FBHT)
for i =1:length(BHT.Unique_phage_gene_vec)
    
    % PRINT TO SCREEN PERCENT FINISHED
    if length(BHT.Unique_phage_gene_vec)>100 && i/100==round(i/100)
        tmp=tmp+1; if tmp ==10, fprintf('\n'); tmp=0; end;
        fprintf('%d%%...',round(100*i/length(BHT.Unique_phage_gene_vec)));
    end
    
    % FILTERING CONDITION
    if (BHT.min_E_value_vec(i) <= IN.E_TH) %|| (BHT.max_Percent_Ident_vec(i) >= IN.MIN_PERC_IDNT) && (BHT.max_Number_of_Ident_vec(i) >= IN.MIN_IDT_LEN )
        % RETRIEVE AND STORE DATA ON NEW FOUND REFSEQ GENE
        count = count + 1;
        hit_vec(count) = i;
        FBHT.List_of_contigs{count} = BHT.List_of_contigs{i};
        gene_id                     = BHT.Unique_phage_gene_vec{i}; % This is the ID of the gene as appeared in the blastall file
        
        % Find location of this gene's record in the FASTA or GenPept file (doing it in the main is more memory efficient)
        rec=0; found = 0;
        if isempty(IN.GENPEP_REFSEQ_FILE)
            % FASTA FILE SUPPLIED
            while ~found && rec<Lrecs
                rec=rec+1;
                % Search for gene_id in FASTA header
                if ~isempty(strfind(FILE_PARSE(rec).Header,gene_id)), found = 1; end
            end
            if ~found
                errmsg=sprintf('debug %s.m: gene ID ''%s'' was not found in: %s\n',mfilename, gene_id, IN.FASTA_REFSEQ_FILE);
                fprintf('%s\n',errmsg);
                errordlg(errmsg);
                keyboard
            end
            OUT  = obtain_description_FASTA(IN.FASTA_REFSEQ_FILE,FILE_PARSE(rec).RecordLocation,gene_id);
            
        else % GENPEPT FILE SUPPLIED
            while ~found && rec<Lrecs
                rec=rec+1;
                % Search for Version in gene_id
                % NOTE: According to RefSeq release notes "The GI and
                % "ACCESSION.VERSION"  identifiers provide the finest resolution reference to a sequence"
                if ~isempty(strfind(gene_id,FILE_PARSE(rec).Version)), found = 1; end
            end
            if ~found
                errmsg=sprintf('\n%s.m debug: gene ID ''%s'' was not found in: %s\n',mfilename, gene_id, IN.GENPEP_REFSEQ_FILE);
                fprintf('%s\n',errmsg);
                errordlg(errmsg);
                keyboard
            end
            if rec==1
                StartOfRecord = 0;
                StartSearchFrom = []; % don't need this
            else
                StartOfRecord = []; % will need to find this
                StartSearchFrom = FILE_PARSE(rec-1).RecordLocation; % file location of last Version field - start search from here
            end
            OUT  = obtain_description_GENPEPT(IN.GENPEP_REFSEQ_FILE,StartSearchFrom,StartOfRecord);
        end
        
        FBHT.best_Gene_len_vec(count)           = OUT.gene_len;
        FBHT.best_Align_perc_of_gene_vec(count) = BHT.best_Align_length_vec(i)/OUT.gene_len*100;
        FBHT.best_seq_vec{count}                = OUT.Sequence;
        FBHT.best_description_vec{count}        = OUT.Definition;
        FBHT.LocusGenBankDivision{count}        = OUT.LocusGenBankDivision;
        FBHT.LocusMoleculeType{count}           = OUT.LocusMoleculeType;
        FBHT.Source{count}                      = OUT.Source;
        FBHT.SourceOrganism{count}              = OUT.SourceOrganism;
        FBHT.Comment{count}                     = OUT.Comment;
        FBHT.Features{count}                    = OUT.Features;
    end
end

FBHT.N_contigs_vec                = BHT.N_contigs_vec(hit_vec);
FBHT.min_E_value_vec              = BHT.min_E_value_vec(hit_vec);
FBHT.max_Percent_Ident_vec        = BHT.max_Percent_Ident_vec(hit_vec);
FBHT.max_Number_of_Ident_vec      = BHT.max_Number_of_Ident_vec(hit_vec);
FBHT.Unique_phage_gene_vec        = BHT.Unique_phage_gene_vec(hit_vec);
FBHT.best_Align_length_vec        = BHT.best_Align_length_vec(hit_vec);

fprintf('\ndone.\n');

clear BHT;

% PRINT REDUCED FILT TABLE TO FILE
msg1 = 'Hit Table showing only the record for the best metagenome gene object for each RefSeq gene (after filtering of RefSeq genes):';
msg2 = sprintf('E <= %g',IN.E_TH);
msg3 = sprintf('%s\n%s',msg1,msg2);
write_RelatedContigs(OUTFILE{3},FBHT,msg3);

clear FILE_PARSE

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIND RELATED REFSEQ GENES
% FOR EACH REFSEQ PHAGE GENE (i-TH HIT) FIND NETWORK OF OTHER REFSEQ PHAGE GENES THAT HAVE
% A SIMILAR (NOT NECESSARILTY IDENTICAL) CONTIG LIST. THUS FOR EACH REFSEQ PHAGE GENE WE ASSOCIATE A NETORK OF REFSEQ PHAGE GENES.
N_RefSeq_genes = length(FBHT.Unique_phage_gene_vec);
save ../tmp/tmp_MetaMiner30CheckPoint.mat
fprintf('\n\n4) Determining related RefSeq genes...\n\n');
if val_N_THREADS>1
    % open 'val_N_THREADS' matlab workers
    fprintf('\nParallel processing is ON for MetaCAT post filtering analysis\n')
    eval(sprintf('matlabpool open local %d',val_N_THREADS));
else
    fprintf('\nParallel processing is OFF for MetaCAT post filtering analysis\n')
end
% For each RefSeq gene (index i), related_hits_for_ith_hit{i} is a vector of all related RefSeq genes
related_hits_for_ith_hit = find_related_genes(val_N_THREADS, N_RefSeq_genes,FBHT.List_of_contigs,IN.MIN_IDNT_PERC_OF_CONTIG_LISTS);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FOR EACH REFSEQ GENE NETWORK ELECT A DELEGATE TO REPRESENT THIS NETWORK (THE ONE WITH THE LOWEST E VALUE)
% For each RefSeq gene (index i) lowest_E_value_index_vec(i) is the index of the best delegate (lowest E value)
lowest_E_value_index_vec = find_delegates(related_hits_for_ith_hit, FBHT);

% COMBINE ALL THE REFSEQ GENES THAT ARE REPRESENTED BY THE SAME DELEGATE REFSEQ GENE %(FORMING THE SHORT TABLE 'ST')
% :
% FBHT index
% 1)
% 2)
% :
% i)  -->  'lowest_E_value_index_vec(i)' = RefSeq gene that has the lowest E value out of the genes related to i  = index of RefSeq gene in FBHT to represent i
% :
% :
ST = keep_only_delegates(lowest_E_value_index_vec, FBHT);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PRINT LIST OF ALL RELATED REFSEQ GENES WITH FULL DESCRIPTION OF GENE (SORTED BY NUMBER OF RELATED CONTIGS)
write_RelatedGenesTable(OUTFILE{4},FBHT,ST.N_contigs_vec,ST.related_refseq_genes_FHBT_ind_vec,ST.best_ST_or_FBHT_indx_vec);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PRINT REDUCED FILT UNIQUE TABLE (SORTED BY NUMBER OF RELATED CONTIGS)
msg4 = sprintf('RefSeq genes with similar metagenome gene object lists (>= %d%% identity) but with higher E values were removed.',IN.MIN_IDNT_PERC_OF_CONTIG_LISTS);
msg = sprintf('%s\n%s',msg3,msg4);
global PROG_NAME
fprintf('\n5) Generating Short Table (with redundancy):\n')
write_SortedShortTable(OUTFILE{5},ST,msg)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('\n6) Removing redundant genes from Short Table:\n')

N_RefSeq_genes_last = length(ST.N_contigs_vec);
c=0;
save tmp_state

while 1
    c=c+1;
    fprintf('Iteration %d...\n',c);
    % For each RefSeq gene (index i), related_hits_for_ith_hit{i} is a vector of indices of all related RefSeq genes
    related_hits_for_ith_hit = find_related_genes(val_N_THREADS, N_RefSeq_genes_last, ST.List_of_contigs, IN.MIN_IDNT_PERC_OF_CONTIG_LISTS);
    
    % 'lowest_E_value_index_vec(i)' = index of RefSeq gene that has the lowest E value out of the genes related to i  = index of RefSeq gene in ST to represent i
    lowest_E_value_index_vec = find_delegates(related_hits_for_ith_hit, ST);
    ST = keep_only_delegates(lowest_E_value_index_vec, ST);
    N_RefSeq_genes_cur = length(ST.N_contigs_vec);
    fprintf('Iteration %d of compression, # of reported genes = %d->%d\n',c,N_RefSeq_genes_last,N_RefSeq_genes_cur);

    if N_RefSeq_genes_cur==N_RefSeq_genes_last, break, end
    N_RefSeq_genes_last = N_RefSeq_genes_cur;
end

fprintf('Coverged to %d reported genes\n',N_RefSeq_genes_last);

fprintf('Compression completed.\n');

msg = sprintf('%s\n%s\nShort list of reported genes was iteratively compressed to remove all reported genes that are related.',msg3,msg4);
write_SortedShortTable(OUTFILE{6},ST,msg);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd(['..' filesep 'msrc']);
save workspace_env
cd(['..' filesep 'bin']);

dt.metaminer = toc;
fprintf('\nRun time = %.1f hours\n',dt.metaminer/3600);

finish.metaminer_date = date;
finish.metaminer_time = clock;

% Write param file to output
write_params(IN,OUTFILE,start,finish,dt,blastall_command);
open(OUTFILE{1});

if val_N_THREADS>1
    matlabpool close
end

