function badfilename = CheckIfFilenameIsIllegal(filename,action)
% should be legal for both UNIX and DOS. blast files can't have spaces for PCs

if ~exist('action')
    action = [];
end;

x=filename;

if isempty(x) || isempty(strtrim(x))
    h=errordlg('File name can''t be blank');
    uiwait(h)
    badfilename = 1;
    return
end

if strcmp(action,'blast')
    badfilename = max(x=='"' | x=='*' | x=='/' | x==':' | x=='<' | x=='>' | x=='?' | x=='\' | x=='|' | x=='%' | x==';' | x=='&' | x==' ');
else
    badfilename = max(x=='"' | x=='*' | x=='/' | x==':' | x=='<' | x=='>' | x=='?' | x=='\' | x=='|' | x=='%' | x==';' | x=='&');
end

badfilename = badfilename | x(1)=='.' | x(1)=='-' | x(end)=='.';

if badfilename 
    % invalid entry
    if strcmp(action,'blast')
        h=errordlg('Bad file name. Hint: filename can''t include the following characters: " * / : < > ? \ | % ; & space');
    else
        h=errordlg('Bad file name. Hint: filename can''t include the following characters: " * / : < > ? \ | % ; &');
    end
    uiwait(h);
    return
end