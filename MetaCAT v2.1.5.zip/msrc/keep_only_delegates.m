function ST = keep_only_delegates(lowest_E_value_index_vec, ST_or_FBHT)
count = 0;
for i=1:length(lowest_E_value_index_vec)
    % Find all other RefSeq genes who belong to networks where 'lowest_E_value_index_vec(i)' is the RefSeq gene with the lowest E value
    if lowest_E_value_index_vec(i)~=-1
        % All the genes related to 'lowest_E_value_index_vec(i)' that have higher E values
        ST_or_FBHT_indices_vec = find(lowest_E_value_index_vec==lowest_E_value_index_vec(i));
        
        % add one more solution
        count = count + 1;
        
        ST.best_ST_or_FBHT_indx_vec(count) = lowest_E_value_index_vec(i);
        
        % List of contigs for best refseq gene
        ST.List_of_contigs{count}   = ST_or_FBHT.List_of_contigs{lowest_E_value_index_vec(i)};
        
        % All ST_or_FBHT_indices_vec genes are related to 'lowest_E_value_index_vec(i)'.
        % 'lowest_E_value_index_vec(i)' may not be in this list because it may be represented by another RegSeq gene
        ST.related_refseq_genes_FHBT_ind_vec{count} = unique([lowest_E_value_index_vec(i), ST_or_FBHT_indices_vec]);
        ST.Number_of_related_NCBI_genes(count)      = length(ST.related_refseq_genes_FHBT_ind_vec{count});
        
        % Go over gene in current networks and combine contig list
        ST.Tot_list_of_contigs_in_network{count}    = [];
        for j = 1:length(ST.related_refseq_genes_FHBT_ind_vec{count})
            next_gene_ind                               = ST.related_refseq_genes_FHBT_ind_vec{count}(j);
            ST.Tot_list_of_contigs_in_network{count}    = [ST.Tot_list_of_contigs_in_network{count}, ST_or_FBHT.List_of_contigs{next_gene_ind}'];
        end
        ST.Tot_list_of_contigs_in_network{count}    = unique(ST.Tot_list_of_contigs_in_network{count});
        ST.N_tot_contigs_in_network(count)          = length(ST.Tot_list_of_contigs_in_network{count});
        
        % Remove these indices for next interations, don't need to visit them again
        lowest_E_value_index_vec(ST_or_FBHT_indices_vec) = -1;
    end
end


% Report back these BLAST values for each of best REFSEQ genes found
ST.N_contigs_vec                = ST_or_FBHT.N_contigs_vec(ST.best_ST_or_FBHT_indx_vec);          % Each element = number of contigs assoicated with the REFSEQ gene yielding the lowest E value for a given network
ST.min_E_value_vec              = ST_or_FBHT.min_E_value_vec(ST.best_ST_or_FBHT_indx_vec);        % Each element = lowest E value for a given network
ST.max_Percent_Ident_vec        = ST_or_FBHT.max_Percent_Ident_vec(ST.best_ST_or_FBHT_indx_vec);  % Each element = percent identity of best contig with respect to REFSEQ gene yielding the lowest E value for a given network
ST.max_Number_of_Ident_vec      = ST_or_FBHT.max_Number_of_Ident_vec(ST.best_ST_or_FBHT_indx_vec);% Each element = number of identical aa of best contig with respect to REFSEQ gene yielding the lowest E value for a given network
ST.Unique_phage_gene_vec        = ST_or_FBHT.Unique_phage_gene_vec(ST.best_ST_or_FBHT_indx_vec);  % Each element = Description of  REFSEQ gene yielding the lowest E value for a given network
ST.best_Align_length_vec        = ST_or_FBHT.best_Align_length_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_Gene_len_vec            = ST_or_FBHT.best_Gene_len_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_Align_perc_of_gene_vec  = ST_or_FBHT.best_Align_perc_of_gene_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_seq_vec                 = ST_or_FBHT.best_seq_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_description_vec         = ST_or_FBHT.best_description_vec(ST.best_ST_or_FBHT_indx_vec);
ST.LocusGenBankDivision         = ST_or_FBHT.LocusGenBankDivision(ST.best_ST_or_FBHT_indx_vec);
ST.LocusMoleculeType            = ST_or_FBHT.LocusMoleculeType(ST.best_ST_or_FBHT_indx_vec);
ST.Source                       = ST_or_FBHT.Source(ST.best_ST_or_FBHT_indx_vec);
ST.SourceOrganism               = ST_or_FBHT.SourceOrganism(ST.best_ST_or_FBHT_indx_vec);
ST.Comment                      = ST_or_FBHT.Comment(ST.best_ST_or_FBHT_indx_vec);
ST.Features                     = ST_or_FBHT.Features(ST.best_ST_or_FBHT_indx_vec);


