function write_params(IN,OUTFILE,start,finish,dt,blastall_command)
fprintf('Writing output file: %s\n\n',OUTFILE{1});
global PROG_NAME;

fid2 = fopen(OUTFILE{1},'w');

% GATHER SYSTEM INFORMATION
fprintf(fid2, 'SYSTEM INFORMATION:\n');
fprintf(fid2, '-------------------\n\n');

try
    [ttt computer_name] = system('hostname');
    fprintf(fid2,'Host name = %s\n',computer_name);
catch
    fprintf(fid2,'Cannot resolve host name\n');
end
fprintf(fid2,'Matlab version = %s\n',version);
v=ver; 
for i=1:length(v); 
    if ~isempty(strfind(lower(v(i).Name),'parallel'));
        fprintf(fid2,'Parallel toolbox found = %s %s %s %s\n',v(i).Name,v(i).Version,v(i).Release,v(i).Date);
    end;
end

fprintf(fid2,'Operating system detected = %s\n',computer);
fprintf(fid2,'Path = %s\n\n',pwd);

% GATHER METACAT RUN INFORMATION
fprintf(fid2,'%s %s RUN SUMMARY:\n',PROG_NAME,IN.version);
fprintf(fid2, '--------------------------\n\n');


if exist('blastall_command') && ~isempty(blastall_command)
    % BLAST EXECUTION INFO:
    fprintf(fid2,'BLAST command(s) executed:\n');
    for i=1:length(blastall_command)
        fprintf(fid2,'%s\n',blastall_command{i});
    end

    fprintf(fid2,'\nBLAST START TIME %s %dh%dm%ds\n'   ,start.blast_date, round(start.blast_time(4:end)));
    fprintf(fid2,'BLAST END TIME   %s %dh%dm%ds\n'  ,finish.blast_date, round(finish.blast_time(4:end)));
    fprintf(fid2,'Run time = %.2f hours\n\n',dt.blast/3600);
end

fprintf(fid2,'MetaCAT START TIME %s %dh%dm%ds\n'   ,start.metaminer_date, round(start.metaminer_time(4:end)));
fprintf(fid2,'MetaCAT END TIME   %s %dh%dm%ds\n'  ,finish.metaminer_date, round(finish.metaminer_time(4:end)));
fprintf(fid2,'Run time = %.2f hours\n\n',dt.metaminer/3600);

fprintf(fid2,'\nINPUT PARAMETERS FOR MetaCAT:\n');
fprintf(fid2,'\n-----------------------------\n\n');
names = fieldnames(IN);

for i=1:length(names);
    next_field = getfield(IN,names{i});
    if ischar(next_field)
        fprintf(fid2,'%s = %s\n',names{i}, next_field);
    else
        fprintf(fid2,'%s = %g\n',names{i}, next_field);
    end
end

fprintf(fid2,'\n\nOUTPUT FILES GENERATED:\n');
fprintf(fid2,'\n\n-----------------------\n\n');
for i = 1:length(OUTFILE)
    fprintf(fid2,'%s\n',OUTFILE{i});
end

fclose(fid2);


