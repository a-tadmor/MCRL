function  [new_filenames ID] = SplitFile(infile, n_files)

finished = 0;

% find number of genes in file
N_genes_tot = GetNumOfGenes(infile);

% open infile
fp_in = fopen(infile,'r');

% tmp file ID
rand('seed',sum(100*clock));
ID = ceil(1000000*rand);

% determine number of genes per file
N_genes_per_file = ceil(N_genes_tot/n_files);

% new file tmp names
for i=1:n_files
    new_filenames{i} = sprintf('%s_%d_%d',infile,i,ID);
end

% split infile into 'n_file' outfiles
for i=1:n_files
    % open next new tmp file
    try
        fp_out = fopen(new_filenames{i},'w');
    catch
        fprintf('debug: %s can''t write file to disk\n',mfilename);
        keyboard
    end
    
    % need to find first gene (in case there are a few empty lines in the start of the file)
    if i==1
        line = fgets(fp_in);
        line_trim = strtrim(line);   
        found =0;
        % search for first line which has a '>'
        while  ~found
            if ~isempty(line_trim) && line_trim(1)=='>'
                found = 1;
            else
                % write out this empty line and go to next line
                fprintf(fp_out,'%s',line);
                line = fgets(fp_in);
                line_trim = strtrim(line);
            end
        end
    end
    n_gene_cur_file = 1; % gene coutner for current file
    
    % copy first 'N_genes_per_file' genes to new file or file is finished, which ever comes first
    while ~feof(fp_in) && n_gene_cur_file<=N_genes_per_file
        fprintf(fp_out,'%s',line);
        line = fgets(fp_in);
        % found new gene?
        line_trim = strtrim(line);
        if ~isempty(line_trim) && line_trim(1)=='>'
               n_gene_cur_file = n_gene_cur_file + 1;
        end
    end
    if feof(fp_in) && ~finished
        % write last line in the file
        fprintf(fp_out,'%s',line);
        finished = 1;
    end

    fclose(fp_out);
    fprintf('file %d/%d done\n',i,n_files);
end

fclose(fp_in);
