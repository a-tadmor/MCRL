function  N_genes = GetNumOfGenes(infile)

% open infile
fp = fopen(infile,'r');

line = []; N_genes = 0;
while ~feof(fp)
    line = strtrim(fgetl(fp));
    if ~isempty(line) && line(1)=='>'
        N_genes = N_genes + 1;
    end
end
fclose(fp);
