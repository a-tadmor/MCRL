function percent_min = calc_percent_identical_contigs(list1, list2)
% Determine percent identity between two lists .
% Note that percent (output) is symetric with respect to list1 and list2:
%
% calc_percent_identical_contigs(list1, list2) = calc_percent_identical_contigs(list2, list1)

matches = 0;
for i = 1:length(list1)
    debug_ttt=0;
    for j = 1:length(list2)
        if strcmp(list1{i},list2{j})
            matches = matches + 1;
            debug_ttt = debug_ttt + 1;
        end
    end
    if debug_ttt>1 
        % debug_ttt should always be 0 or 1
        sprintf('%s.m debug flag: dual entry in contig list.\n',mfilename)
        keyboard
    end
end

% Score is symetric with respect to list1 and list2. 
percent_min = min([matches/length(list1)*100, matches/length(list2)*100]); % Require that the contig overlap with respect to both genes exceeds the threshold 
%percent_max = max([matches/length(list1)*100, matches/length(list2)*100]); % For debugging purposes

