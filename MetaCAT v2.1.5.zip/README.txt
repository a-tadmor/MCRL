MetaCAT, Metagenome Cluster Analysis Tool

RELEASE
v2.1.5 (August 25 2016)

AUTHORS
Arbel D. Tadmor(1,2)
1) TRON - Translational Oncology at the University Medical Center of the Johannes Gutenberg, University Mainz, 55131, Mainz, Germany
2) Department of Biochemistry and Molecular Biophysics, California Institute of Technology, Pasadena, CA 91125, USA

SYSTEM REQUIREMENTS
* Matlab version 7.4 or higher 
* Bioinformatics toolbox 
* Parallel Computing toolbox v4.2 or higher (optional) 
* Installation of MetaCAT requires an internet connection 

MetaCAT is platform independent.

INSTALLATION INSTRUCTIONS
1. Extract the compressed sources of MetaCAT locally 
2. Start up Matlab 
3. Change directories in Matlab to the 'bin' folder of MetaCAT 
4. Run MetaCAT by typing MetaCAT_EXE in the Matlab command prompt 
5. Click �Automatic installation (recommended)� 
6. Once the installation of BLAST starts click �next� and accept all of the default entries. Once blast is locally installed MetaCAT will proceed to download and assemble the most recent viral RefSeq database.
7. Once the main interface of MetaCAT loads you may start using MetaCAT. 

It is recommended to install MetaCAT as the root/administrator and disable the firewall for the installation.

Installation may take 10 to 20 minutes depending on the computer.

USER GUIDE
For more detailed information regarding installation and use of MetaCAT please refer to the user guide (User Guide.pdf).
LICENSE AGREENENT 
By using this program you agree to the terms provided in the license agreement (License.txt).

CITATION
Tadmor A. D., Mahmoudabadi G., Phillips R., Biogeographic patterns of ubiquitous commensal phage families in humans, 2016 (submitted)
Tadmor A. D., Ottesen E. A., Leadbetter J. R., Phillips R., Probing individual environmental bacteria for viruses by using microfluidic digital PCR. Science 333, 58-62 (2011)


