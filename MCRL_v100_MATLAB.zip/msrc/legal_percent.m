function good = legal_percent(x,COMMAND_LINE)
% <--MCRL_MAIN.m

if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

good = 0;
if isempty(x) || ~isempty(x) && (x<0 || x>100)
    % invalid entry
    if ~COMMAND_LINE
        h=warndlg('Percent must be between 0 to 100','Notice'); uiwait(h);
    else
        error('Percent must be between 0 to 100');
    end
    return
end
good = 1;