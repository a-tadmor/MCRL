function CombineFiles(infiles,outfile)

fp_out = fopen(outfile,'w');

for i = 1:length(infiles)
    fprintf('combining file (%d/%d): %s\n',i,length(infiles),infiles{i});
    fp_in = fopen(infiles{i},'r');
    while ~feof(fp_in)
        next_line = fgets(fp_in);        
        if next_line(1) ~= -1
            fprintf(fp_out,'%s',next_line);
        end
    end
    fclose(fp_in);
end

fclose(fp_out);

