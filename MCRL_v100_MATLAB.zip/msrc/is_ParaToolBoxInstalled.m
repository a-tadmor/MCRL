function ParallelToolBoxFound = is_ParaToolBoxInstalled()

MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer)
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end