function write_RelatedContigs(outfile,TABLE,msg)
% <--MCRL_MAIN.m

% TABLE = BHT/FBHT

fprintf('Writing output file: %s\n\n',outfile);

fp0 = fopen(outfile,'w');

fprintf(fp0,'%s\n\n',msg);
fprintf(fp0,'\tIndex\tReference gene\tReference gene definition\tRepresentative contig\tSize of signature of reference gene\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tReference gene length (amino acids)\t %% of Reference gene aligned\tReference aa sequence\n');

if isempty(TABLE)
    fprintf(fp0,sprintf('No hits found\n'));
    fclose(fp0);
    return
end

for i =1:length(TABLE.N_contigs_vec)
    % These fields are not available for 'AllGenes' file
    [best_Gene_len_vec,  best_Align_perc_of_gene_vec] = str_format(TABLE.best_Gene_len_vec(i),TABLE.best_Align_perc_of_gene_vec(i));
    
    fprintf(fp0,'\ntable\t%d)\t%s\t%s\t%s\t%d\t%.1f\t%d\t%e\t%d\t%s\t%s\t%s\t \n',i,TABLE.Unique_phage_gene_vec{i}, TABLE.best_description_vec{i}, TABLE.List_of_contigs{i}{1}, TABLE.N_contigs_vec(i),TABLE.max_Percent_Ident_vec(i), TABLE.max_Number_of_Ident_vec(i),TABLE.min_E_value_vec(i), TABLE.best_Align_length_vec(i), best_Gene_len_vec,best_Align_perc_of_gene_vec,TABLE.best_seq_vec{i});
    fprintf(fp0,'Signature:\n');
    for j=1:length(TABLE.List_of_contigs{i})
        fprintf(fp0,'%s\n',TABLE.List_of_contigs{i}{j});
    end
end

fclose(fp0);