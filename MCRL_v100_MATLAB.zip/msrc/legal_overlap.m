function good = legal_overlap(x, COMMAND_LINE)

if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

good = 0;
if isempty(x) || length(x)>1 || ~isempty(x) && (x<0 || x>100)
    % invalid entry
    if ~COMMAND_LINE
        h=warndlg('Overlap must be between 0 to 100','Notice');  uiwait(h);
    else
        error('Overlap must be between 0 to 100')
    end
    return
end
good = 1;