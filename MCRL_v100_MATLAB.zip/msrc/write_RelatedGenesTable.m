function write_RelatedGenesTable(outfile, FBHT, ST_N_contigs_vec, ST_related_refseq_genes_TOT_array, ST_best_ST_or_FBHT_str, msg1)
%<-- MCRL_MAIN.m

fprintf('Writing output file: %s\n\n',outfile);
fp2= fopen(outfile ,'w');

fprintf(fp2,sprintf('%s\n\n',msg1));

fprintf(fp2,'\tIndex\tReference gene\tReference gene definition\tMin %% of shared contigs between signatures\tMax %% of shared contigs between signatures\tSize of signature of reference gene\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tReference gene length (amino acids)\t %% of reference gene aligned\tGenPept Features\n');

if isempty(FBHT)
    fprintf(fp2,sprintf('No hits found\n'));
    fclose(fp2);
    return
end

[~, Ncontig_sort_ind] = sort(ST_N_contigs_vec); % Sort RefSeqs by number of related contigs
Ncontig_sort_ind = fliplr(Ncontig_sort_ind);


for n = 1:length(ST_related_refseq_genes_TOT_array)
    % FIRST PRINT THE REFSEQ GENE WITH THE LOWEST E VALUE
    i = Ncontig_sort_ind(n);                 % Sorted indices of short table entries/ST_related_refseq_genes_FHBT_ind_vecs based on number of contigs
    
    Declared_RefSeq_gene = ST_best_ST_or_FBHT_str{i};
    
    % Find corresponding index if FBHT
    i_min = find(strcmp(FBHT.Unique_phage_gene_vec, Declared_RefSeq_gene));
    if isempty(i_min), fprintf('%s.m: error\n', mfilename), keyboard; end
        
    [best_Gene_len_vec,  best_Align_perc_of_gene_vec] = str_format(FBHT.best_Gene_len_vec(i_min),FBHT.best_Align_perc_of_gene_vec(i_min));
    
    fprintf(fp2,'\ntable1\t%d)\t%s\t%s\t\t\t%d\t%.1f\t%d\t%e\t%d\t%s\t%s\t%s\n',n,FBHT.Unique_phage_gene_vec{i_min},FBHT.best_description_vec{i_min},FBHT.N_contigs_vec(i_min),FBHT.max_Percent_Ident_vec(i_min), FBHT.max_Number_of_Ident_vec(i_min),FBHT.min_E_value_vec(i_min), FBHT.best_Align_length_vec(i_min), best_Gene_len_vec,best_Align_perc_of_gene_vec,FBHT.Features{i_min});

    % NOW PRINT ALL OF THE OTHER RELATED GENES THAT COMRPISE THIS NETWORK
    other_indices_in_this_network = setdiff(ST_related_refseq_genes_TOT_array{i}, Declared_RefSeq_gene); % take out i_min from other indices of this network
    fprintf(fp2,'      %d related genes:\n',length(other_indices_in_this_network));

    if ~isempty(other_indices_in_this_network)        
       for k=1:length(other_indices_in_this_network) % print related genes in this network
           % Find corresponding index if FBHT
           curr_i = find(strcmp(FBHT.Unique_phage_gene_vec, other_indices_in_this_network{k}));
           if isempty(curr_i), fprintf('%s.m: error \n', mfilename), keyboard; end

            % Percent of contigs shared between chosen RefSeq gene and
            % other related RefSeq genes
            [perct_sim_contig_list_MIN, perct_sim_contig_list_MAX] = calc_percent_identical_contigs(FBHT.List_of_contigs{i_min},FBHT.List_of_contigs{curr_i});
            
            [best_Gene_len_vec,  best_Align_perc_of_gene_vec] = str_format(FBHT.best_Gene_len_vec(curr_i),FBHT.best_Align_perc_of_gene_vec(curr_i));
            
            fprintf(fp2,'table2\t\t%s\t%s\t%.1f\t%.1f\t%d\t%.1f\t%d\t%e\t%d\t%s\t%s\t%s\n',FBHT.Unique_phage_gene_vec{curr_i},FBHT.best_description_vec{curr_i},perct_sim_contig_list_MIN,perct_sim_contig_list_MAX,FBHT.N_contigs_vec(curr_i),FBHT.max_Percent_Ident_vec(curr_i), FBHT.max_Number_of_Ident_vec(curr_i),FBHT.min_E_value_vec(curr_i), FBHT.best_Align_length_vec(curr_i), best_Gene_len_vec,best_Align_perc_of_gene_vec,FBHT.Features{curr_i});
        end
    end
end
fclose(fp2);