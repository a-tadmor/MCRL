function ctfroot_str2 = get_ctfroot()

ctfroot_str = ctfroot;
% deal with escape characters
ctfroot_str2='';
for is=1:length(ctfroot_str)
    if ctfroot_str(is)=='\'
        ctfroot_str2 = [ctfroot_str2 '\\'];
    else
        ctfroot_str2 = [ctfroot_str2 ctfroot_str(is)];
    end
end