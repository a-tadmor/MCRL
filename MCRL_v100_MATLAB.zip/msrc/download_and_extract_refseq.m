function [fail, RefSeq_file_name_header] = download_and_extract_refseq(ext, files, cur_dir, ftpobj, RefSeq_release)

fail = 1;
RefSeq_file_name_header = [];

download_files = [];
j=0;
for i=1:length(files)
    file_ending = files(i).name(end-3-length(ext):end);
    if ~files(i).isdir && strcmp(files(i).name(1:5), 'viral') && strcmp(file_ending, sprintf('.%s.gz', ext)) && isempty(strfind(files(i).name, 'nonredundant'))
        j=j+1;
        download_files{j} = files(i).name;
    end
end

if isempty(download_files)
    fprintf('*.%s files not found\n', ext);
    fail = 1;
    return
end

cd(cur_dir);
% delete all files in this folder execpt the matlab source
fclose all;
d=dir(['..' filesep 'Combine_RefSeq_files']);
for i=1:length(d)
    if  d(i).isdir==0 && isempty(strfind(d(i).name, 'util_concat_all_files_in_folder'))
        delete(['..' filesep 'Combine_RefSeq_files' filesep d(i).name])
    end
end
% make sure all files were deleted
ALL_DELETED=1;
d=dir(['..' filesep 'Combine_RefSeq_files']);
for i=1:length(d)
    if  d(i).isdir==0 && isempty(strfind(d(i).name, 'util_concat_all_files_in_folder'))
       ALL_DELETED=0;
       break
    end
end

if ~ALL_DELETED
    fprintf('Cannot delete all files in Combine_RefSeq_files folder\n');
    fail = 2;
    return
end

cd(['..' filesep 'Combine_RefSeq_files']);
combinepath = pwd;

cd(cur_dir);
cd(['..' filesep 'RefSeq_database']);
refseqpath = pwd;
cd(cur_dir);
cd(['..' filesep 'tmp']);
tmppath = pwd;
cd(cur_dir);

% download *.ext files to tmp folder
try
    for j=1:length(download_files)
        cd(['..' filesep 'tmp'])
        fprintf(sprintf('Downloading %s...\n', download_files{j}));
        mget(ftpobj, download_files{j});
        cd(cur_dir);
        fprintf(sprintf('Extracting %s...\n', download_files{j}));
        
        % extract gz files to Combine_RefSeq_files folder
        gunzip([tmppath filesep download_files{j}], combinepath);
        
        % delete gz files from tmp folder
        delete([tmppath filesep download_files{j}]);
    end
    % combine files in Combine_RefSeq_files folder to one file
    fprintf(sprintf('Combining %s...\n', download_files{j}));
    cd(cur_dir);
    cd(['..' filesep 'Combine_RefSeq_files']);
    util_concat_all_files_in_folder_fun();
    
    % move final combined file to RefSeq folder
    RefSeq_file_name_header = sprintf('viral_%s', RefSeq_release);
    movefile([combinepath filesep 'combined_all'], [refseqpath filesep sprintf('%s.%s', RefSeq_file_name_header, ext)])
    
    % delete *.ext files from  Combine_RefSeq_files folder
    delete(sprintf('*.%s', ext));
    
    cd(cur_dir);
catch
    fail = 1;
    return
end

fail = 0;

