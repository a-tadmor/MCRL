function FILE_PARSE = parse_FASTA(FASTA_filename)
% Return the header and location of the start of all records (i.e. '>')

FILE_PARSE = [];
fid  = fopen(FASTA_filename,'r');

if fid==-1
    fprintf('%s.m Error: cannot open FASTA file ''%s''\n',mfilename,FASTA_filename);
    keyboard
end

line = fgetl(fid);

last_record_count = -1;
record_count      = 0;
last_location     = 0;
ttt               = 0;

while ~feof(fid) 
    % Print counter to screen
    if record_count/1e4 == round(record_count/1e4) && record_count>last_record_count && record_count>0
        fprintf('%d genes read...',record_count);
        ttt=ttt+1; if ttt ==4, fprintf('\n'); ttt=0; end
        last_record_count = record_count;
    end
    
    % Find the next record
    if  ~isempty(strfind(line,'>'))
        record_count = record_count +1;
        FILE_PARSE(record_count).Header         = line;           % Entire header of record
        FILE_PARSE(record_count).RecordLocation = last_location;  % File location of header
    end
    last_location = ftell(fid);
    line = fgetl(fid);
end
fprintf('done.\n')
fclose(fid);