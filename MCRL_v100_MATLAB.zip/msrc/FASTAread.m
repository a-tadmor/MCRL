function FASTA = FASTAread(FASTA_filename, MODE, record, COMMAND_LINE)
% Return the header and location of the start of all records (i.e. '>')

if ~exist('COMMAND_LINE','var') || exist('COMMAND_LINE','var') && isempty(COMMAND_LINE)
    COMMAND_LINE = 0;
end

if ~exist('record','var') || exist('record','var') && isempty(record)
    record = 0;
end

if ~exist('MODE','var') || exist('MODE','var') && isempty(MODE)
    MODE = '';
end

FASTA = fastaread_fun(FASTA_filename, MODE, record, COMMAND_LINE);


