function [installed locate_sources_manually] = install_blast()
% Install BLAST from ncbi website
locate_sources_manually = 0;
global PROG_NAME
global blast_ver 

installed = 0;

ncbi_website = 'ftp.ncbi.nlm.nih.gov';
blast_ftp_dir = ['blast/executables/blast+/' blast_ver(1:end-1)];


if isunix
    ANS = questdlg([PROG_NAME ' needs to download and install blast ' blast_ver ' from NCBI (requires internet connection and root privileges)' ],'BLAST installation','Automatic installation (recommended)', 'Locate sources on computer','Quit','Automatic installation (recommended)');
else
    ANS = questdlg([PROG_NAME ' needs to download and install blast ' blast_ver ' from NCBI (requires internet connection)' ],'BLAST installation','Automatic installation (recommended)', 'Locate sources on computer','Quit','Automatic installation (recommended)');
end
% find which blast to install
switch computer
    case 'GLNX86'
        %blast_filename  = ['ncbi-blast-' blast_ver '-1.i686.rpm'];
        blast_filename  = ['ncbi-blast-' blast_ver '-ia32-linux.tar.gz'];
    case 'GLNXA64'
        %blast_filename  = ['ncbi-blast-' blast_ver '-1.x86_64.rpm'];
        blast_filename  = ['ncbi-blast-' blast_ver '-x64-linux.tar.gz'];
    case {'MAC','MACI','MACI64'}
        blast_filename  = ['ncbi-blast-' blast_ver '-universal-macosx.tar.gz'];
    case {'PCWIN'}
        blast_filename  = ['ncbi-blast-' blast_ver '-win32.exe']; 
    case {'PCWIN64'}
        blast_filename  = ['ncbi-blast-' blast_ver '-win64.exe']; 
    case {'SOL64'} % Sun Solaris on SPARC
        blast_filename  = ['ncbi-blast-' blast_ver '-sparc64-solaris.tar.gz'];
    otherwise
        h=errordlg(sprintf('%s does not support a blast utility for this computer type. Please proceed to manually install blast %s',PROG_NAME,blast_ver));
        uiwait(h);
        return
end

switch ANS
    case 'Automatic installation (recommended)'
        % open ftp connection to ncbi
        try
            fprintf(sprintf('Openning ftp connection to %s...\n', ncbi_website));
            ftpobj = ftp(ncbi_website);
        catch
            h=errordlg(sprintf('Could not establish ftp connection: try turning off firewall or download and install %s manually from %s',blast_filename,['ftp://' ncbi_website '/' blast_ftp_dir]));
            uiwait(h);
            return
        end
        
        % change diretories at ftp site
        try
            cd(ftpobj,blast_ftp_dir);
        catch
            h=errordlg(sprintf('Could not establish ftp connection: try turning off firewall or download and install %s manually from %s',blast_filename,['ftp://' ncbi_website '/' blast_ftp_dir]));
            uiwait(h);
            close(ftpobj);
            return
        end

        % download the file
        try
            fprintf(sprintf('Downloading %s...\n', blast_filename));
            cur_dir = pwd;
            cd(['..' filesep 'blast'])
            blast_folder = pwd;
            h=msgbox('Beginning MCRL installation - this may take a few minutes...');
            mget(ftpobj, blast_filename);
            cd(cur_dir);
            close(h)
        catch
            cd(cur_dir);
            h=errordlg(sprintf('Could not establish ftp connection: try turning off firewall or download and install %s manually from %s',blast_filename,['ftp://' ncbi_website '/' blast_ftp_dir]));
            uiwait(h);
            close(ftpobj);
            return
        end
        close(ftpobj);

        % install blast
        fprintf(sprintf('Installing %s...\n', blast_filename));
        cd(['..' filesep 'blast'])
 
        switch computer
            %case {'GLNX86','GLNXA64'}
            %    %stat = system(['rpm -ivh ' blast_filename]); % RedHat
            case {'PCWIN','PCWIN64'}
                stat = system(blast_filename(1:end-4));
            case {'MAC','MACI','MACI64','SOL64','GLNX86','GLNXA64'}
                stat = system(['tar -zxvf ' blast_filename]);
        end
        cd(cur_dir);

        if stat~=0 %failed to install
            ANS = questdlg('Could not install blast. See Troubleshoot for more details','','Troubleshoot','Quit','Troubleshoot');
            switch ANS
                case 'Troubleshoot'
                    if isunix
                        h=errordlg(sprintf('You need to be logged on as user with root privileges. Install %s manually from %s',[blast_folder,blast_filename],blast_filename,blast_folder));
                    else
                        h=errordlg(sprintf('Install %s manually from %s',[blast_folder,blast_filename],blast_filename,blast_folder));
                    end
                    uiwait(h);
                    return
                case 'Quit'
                    return
            end
        end
        installed = 1;
     
    case {'Locate sources on computer'}
        locate_sources_manually = 1;
        return
  
    case {'Quit'}
        return
end

