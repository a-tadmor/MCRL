function [filepath_withsep filename_nospaces fullfilename_nospaces success] = GetPathAndName(fullfilename,action)
% remove spaces and copy file to appropriate local directory needed to run blast

success = 1;
[pth name ext]        = fileparts(fullfilename);
filename              = [name ext];
filename_nospaces     = filename;
filepath_withsep      = [pth filesep];
fullfilename_nospaces = fullfilename;

if exist('action')
    % check if file exists
    if exist(fullfilename)==0
        errordlg(sprintf('%s does not exist',fullfilename))
        success = 0;
        return
    end

    % remove spaces from file name
    spaces = find(filename==' ');
    if ~isempty(spaces)
        filename_nospaces(spaces)='_';
    end
    fullfilename_nospaces = [filepath_withsep filename_nospaces];
      
    % local path (legal format for blast)
    switch action
        case 'refseq'
            filepath_withsep  = ['..' filesep 'RefSeq_database' filesep];

        case 'metagenome'
            filepath_withsep  = ['..' filesep 'data' filesep];
        
        otherwise
            fprintf('debug %s.m: unknown action %s\n',mfilename,action)
            keyboard
    end

    fullfilename_nospaces = [filepath_withsep filename_nospaces];
    
    % check if both files with full paths are the same
    cur_path=pwd;
    cd(pth);
    fullpath_in =  [pwd filesep];
    cd(cur_path);
    cd(filepath_withsep);
    fullpath_out = [pwd filesep];
    cd(cur_path);
  
    % copy files to local directory

    if ~strcmp([fullpath_in filename],[fullpath_out filename_nospaces])
        % if the original path the user gave is the same as the local path
        % - then it's the same file -no need to copy and overwrite
        [s m id] = copyfile(fullfilename, fullfilename_nospaces, 'f');
    end
end

