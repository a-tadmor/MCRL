function varargout = main_gui2(varargin)
% MAIN_GUI2 M-file for main_gui2.fig
%      MAIN_GUI2, by itself, creates a new MAIN_GUI2 or raises the existing
%      singleton*.
%
%      H = MAIN_GUI2 returns the handle to a new MAIN_GUI2 or the handle to
%      the existing singleton*.
%
%      MAIN_GUI2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_GUI2.M with the given input arguments.
%
%      MAIN_GUI2('Property','Value',...) creates a new MAIN_GUI2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_gui2_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_gui2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES


% Edit the above text to modify the response to help main_gui2

% Last Modified by GUIDE v2.5 22-Aug-2011 22:34:03

% Begin initialization code - DO NOT EDIT

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @main_gui2_OpeningFcn, ...
    'gui_OutputFcn',  @main_gui2_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main_gui2 is made visible.
function main_gui2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main_gui2 (see VARARGIN)

% Choose default command line output for main_gui2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main_gui2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_gui2_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in FASTA_REFSEQ_FILE_BROWSE.
function FASTA_REFSEQ_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(sprintf('..%sRefSeq_database',filesep));
[file path] = uigetfile('*.faa');
cd(sprintf('..%sbin',filesep));

if file(1)~=0
    handles.val_FASTA_REFSEQ_PATHFILE = [path file];
    FASTA_REFSEQ_FILE_Callback(handles.FASTA_REFSEQ_FILE, [], handles)
end
% --- Executes on button press in FASTA_METAGENOME_FILE_BROWSE.
function FASTA_METAGENOME_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_METAGENOME_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(sprintf('..%sdata',filesep));
[file path] = uigetfile('*.*');
cd(sprintf('..%sbin',filesep));

if file(1)~=0
    handles.val_FASTA_METAGENOME_FILE =  file;
    handles.val_FASTA_METAGENOME_PATH =  path;
    FASTA_METAGENOME_FILE_Callback(handles.FASTA_METAGENOME_FILE, [], handles)
end

% --- Executes on button press in GENPEP_REFSEQ_FILE_BROWSE.
function GENPEP_REFSEQ_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to GENPEP_REFSEQ_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(sprintf('..%sRefSeq_database',filesep));
[file path] = uigetfile('*.gpff');
cd(sprintf('..%sbin',filesep));

if file(1)~=0
    handles.val_GENPEP_REFSEQ_FILE = [path file];
    GENPEP_REFSEQ_FILE_Callback(handles.GENPEP_REFSEQ_FILE, [], handles)
end

function E_VALUE_METAMINER_Callback(hObject, eventdata, handles)
% hObject    handle to E_VALUE_METAMINER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
good = legal_evalue(str2num(get(hObject,'String')));
if ~good 
    set(hObject,'String','');
end
% Hints: get(hObject,'String') returns contents of E_VALUE_METAMINER as text
%        str2double(get(hObject,'String')) returns contents of E_VALUE_METAMINER as a double


% --- Executes during object creation, after setting all properties.
function E_VALUE_METAMINER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_VALUE_METAMINER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN = GetParams();
set(hObject,'string',sprintf('%g',IN.E_TH));

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function GENPEP_REFSEQ_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to GENPEP_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_GENPEP_REFSEQ_FILE')
    set(hObject,'String',handles.val_GENPEP_REFSEQ_FILE);
end
% Hints: get(hObject,'String') returns contents of GENPEP_REFSEQ_FILE as text
%        str2double(get(hObject,'String')) returns contents of GENPEP_REFSEQ_FILE as a double


% --- Executes during object creation, after setting all properties.
function GENPEP_REFSEQ_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to GENPEP_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN = GetParams();
set(hObject,'string',IN.GENPEP_REFSEQ_FILE);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_VALUE_BLAST_Callback(hObject, eventdata, handles)
% hObject    handle to E_VALUE_BLAST (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_VALUE_BLAST as text
%        str2double(get(hObject,'String')) returns contents of E_VALUE_BLAST as a double
good = legal_evalue(str2num(get(hObject,'String')));
if ~good 
    set(hObject,'String','');
end
% --- Executes during object creation, after setting all properties.
function E_VALUE_BLAST_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_VALUE_BLAST (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
[t t BLAST] = GetParams();
set(hObject,'string',sprintf('%g',BLAST.E_TH));


% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FASTA_REFSEQ_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_FASTA_REFSEQ_PATHFILE')
    set(hObject,'string',handles.val_FASTA_REFSEQ_PATHFILE);
end
% Hints: get(hObject,'String') returns contents of FASTA_REFSEQ_FILE as text
%        str2double(get(hObject,'String')) returns contents of FASTA_REFSEQ_FILE as a double


% --- Executes during object creation, after setting all properties.
function FASTA_REFSEQ_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN  = GetParams();
set(hObject,'string',IN.FASTA_REFSEQ_FILE);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FASTA_METAGENOME_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_METAGENOME_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_FASTA_METAGENOME_PATH') && isfield(handles,'val_FASTA_METAGENOME_FILE')
    set(hObject,'String',[handles.val_FASTA_METAGENOME_PATH handles.val_FASTA_METAGENOME_FILE]);
end
% Hints: get(hObject,'String') returns contents of FASTA_METAGENOME_FILE as text
%        str2double(get(hObject,'String')) returns contents of FASTA_METAGENOME_FILE as a double


% --- Executes during object creation, after setting all properties.
function FASTA_METAGENOME_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FASTA_METAGENOME_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
[t t BLAST] = GetParams();
set(hObject,'String',BLAST.FASTA_METAGENOME_FILE);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BLAST_OUTPUT_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_BLAST_OUTPUT_PATHFILE')
    set(hObject,'String',handles.val_BLAST_OUTPUT_PATHFILE);
end
% Hints: get(hObject,'String') returns contents of BLAST_OUTPUT_FILE as text
%        str2double(get(hObject,'String')) returns contents of BLAST_OUTPUT_FILE as a double


% --- Executes during object creation, after setting all properties.
function BLAST_OUTPUT_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

IN = GetParams();
[t default_filename_no_path t] = GetPathAndName(IN.BLAST_file_name);
set(hObject,'String',default_filename_no_path);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function METAMINER_OUTPUT_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to METAMINER_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%set(hObject,'String',handles.METAMINER_OUTPUT_FILE)
x = get(hObject,'String');
badfilename = CheckIfFilenameIsIllegal(x);
if badfilename 
    % invalid entry
    set(hObject,'String','');
    return
end
% Hints: get(hObject,'String') returns contents of METAMINER_OUTPUT_FILE as text
%        str2double(get(hObject,'String')) returns contents of METAMINER_OUTPUT_FILE as a double


% --- Executes during object creation, after setting all properties.
function METAMINER_OUTPUT_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to METAMINER_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN = GetParams();
set(hObject,'String', IN.OUTPUT_NAME);


% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in RUN_BLAST_METAMINER.
function RUN_BLAST_METAMINER_Callback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXECUTE BLAST AND METAMINER
%
%
% hObject    handle to RUN_BLAST_METAMINER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Initial values for output 

% check to see if blast is installed

start            = [];
finish           = [];
dt               = [];
blastall_command = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get MetMiner parameters
% works only if Parallel Computing Toolbox is on
MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer);
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end

% Aug 20, 2016: val_N_THREADS=1 if parallel toolbox is not installed
if ParallelToolBoxFound
    val_N_THREADS                 = get(handles.N_THREADS                            ,'Value');   % pull down menu - all values are legal
else
    val_N_THREADS = 1;
end

val_E_TH_METAMINER            = str2num(get(handles.E_VALUE_METAMINER            ,'String')); % value checked to be legal on callback
val_GENPEPT_REFSEQ_PATHFILE   = strtrim(get(handles.GENPEP_REFSEQ_FILE           ,'String')); % value checked below
val_METMINER_OUTNAME          = strtrim(get(handles.METAMINER_OUTPUT_FILE        ,'String')); % value checked below
[val_BLAST_OUTPUT_PATH, val_BLAST_OUTPUT_FILE, val_BLAST_OUTPUT_PATHFILE]    = GetPathAndName(strtrim(get(handles.BLAST_OUTPUT_FILE ,'String'))); % checked below
val_METAG_DATA_TYPE           = get(handles.METAG_DATA_TYPE                      ,'Value'); % value checked below
if val_METAG_DATA_TYPE==1
    MolTypeFromGUI = 'prot';
else
    MolTypeFromGUI = 'nucl';
end

% make sure all files/directories in GUI for MetaMiner are valid files/directories and that all needed parameters were entered
% GenPept RefSeq (if it was defined it needs to be valid)
if ~FileOrPathExists(val_GENPEPT_REFSEQ_PATHFILE), return; end

if CheckIfFilenameIsIllegal(val_METMINER_OUTNAME)==1, return; end

if ~legal_evalue(val_E_TH_METAMINER), return; end

if  (get(handles.BLAST_ON,'Value') ~= get(handles.BLAST_ON,'Max'))
    % BLAST OFF (file+path)- check that file exists  
    if ~FileOrPathExists(val_BLAST_OUTPUT_PATHFILE), return; end    

else
    % BLAST ON (file name only) - check file name is a legal blast file name
    if CheckIfFilenameIsIllegal(val_BLAST_OUTPUT_FILE,'blast')==1, return; end
    val_BLAST_OUTPUT_PATHFILE = ['..' filesep 'output' filesep val_BLAST_OUTPUT_FILE];   
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get BLAST PARAMETERS (if blast is checked on)
% check if Checkbox is on or off
if  (get(handles.BLAST_ON,'Value') == get(handles.BLAST_ON,'Max'))
    % Checkbox on - run BLAST
    % Check if ncbi.ini is found in c:\windows (this is from the C version of blast and will interfere with the program)
    move_ncbi_ini = 0;
    if ispc
        if exist('c:\windows\ncbi.ini')>0
            move_ncbi_ini = 1;
            movefile('c:\windows\ncbi.ini','c:\windows\ncbi.ini~')
        end
    end
    % Get all params from the GUI 
    
    % Make all filenames exist,remove spaces in filename if exist and copy files to local directory if not their already
    [val_FASTA_METAGENOME_PATH, val_FASTA_METAGENOME_FILE, val_FASTA_METAGENOME_PATHFILE, success] = GetPathAndName(strtrim(get(handles.FASTA_METAGENOME_FILE,'String')),'metagenome'); % checked
    if ~success, return; end;
    
    [val_FASTA_REFSEQ_PATH,     val_FASTA_REFSEQ_FILE,     val_FASTA_REFSEQ_PATHFILE, success]     = GetPathAndName(strtrim(get(handles.FASTA_REFSEQ_FILE    ,'String')),'refseq'); % checked
    if ~success, return; end;
    
    val_E_TH_BLAST  = str2num(get(handles.E_VALUE_BLAST        ,'String')); % checked below

    load blast_bin_folder %Gets val_BLAST_BIN_FOLDER
    val_BLAST_BIN_FOLDER         = [val_BLAST_BIN_FOLDER filesep];
    
    % make sure all other parameters from GUI are valid 
    
    % path of bin folder of blastall/formatdb executibles
    if ~found_blast_sourcecode(val_BLAST_BIN_FOLDER), 
        h=errordlg('Could not locate blast source code in the specified folder');
        uiwait(h);
        return; 
    end

    if ~legal_evalue(val_E_TH_BLAST),return; end
    
    % Check if metagenome data type is correct
    % Autodetect type of molecule (nuct or prot) in metagenome file
    MolTypeAuto = AutoDetectMolType(val_FASTA_METAGENOME_PATHFILE);
    % Is molecule type is not recognized? - i.e., non stardard characters found (gaps are considered nonstandard)

    if strcmp(MolTypeAuto,'unknown')
        % Chose MolType again
        MolTypeGUI = questdlg(sprintf('Nonstandard characters were detected in %s. Please reselect data type:',val_FASTA_METAGENOME_PATHFILE),'Molecule type','nucl','prot','abort & diagnose','abort & diagnose');
        switch MolTypeGUI
            case 'prot'
                set(handles.METAG_DATA_TYPE, 'Value', 1);
            case 'nucl'
                set(handles.METAG_DATA_TYPE, 'Value', 2);
            otherwise
                keyboard     
        end
    elseif ~strcmp(MolTypeAuto,MolTypeFromGUI)
        % Molecule type does not agree with what user put in
        switch MolTypeAuto
            case 'prot'
                MolTypeFromGUI = questdlg(sprintf('MCRL autodetected that %s is a PROTEIN file. Please reselect data type:',val_FASTA_METAGENOME_PATHFILE),'Molecule type','nucl','prot','abort & diagnose','prot');
            case 'nucl'
                MolTypeFromGUI = questdlg(sprintf('MCRL autodetected that %s is a NUCLEOTIDE file. Please reselect data type:',val_FASTA_METAGENOME_PATHFILE),'Molecule type','nucl','prot','abort & diagnose','nucl');
        end
        switch MolTypeFromGUI
            case 'prot'
                set(handles.METAG_DATA_TYPE, 'Value', 1); drawnow;
            case 'nucl'
                set(handles.METAG_DATA_TYPE, 'Value', 2); drawnow;
            otherwise
                keyboard
        end
    end
 
    % fprintf('MolType = %s\n',MolTypeFromGUI);    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Passed all the checks - continue
    
    % time and date BLAST started
    start.blast_date = date;
    start.blast_time = clock;
    tic

    PARALLEL = val_N_THREADS>1;
    if isunix
        QUOTE = '''';
    else
        QUOTE = '"';
    end
    
    % Format the metagenome FASTA file in local (data) directory
    fprintf('*** Formatting %s ***\n\n',val_FASTA_METAGENOME_FILE);
    %format_command = sprintf('%sformatdb -i ''%s'' -p T'    ,val_BLAST_BIN_FOLDER,[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE]);
    %format_command = sprintf('legacy_blast.pl formatdb -i ''%s'' -p T'    ,[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE]);   
    
    switch MolTypeFromGUI
        case 'prot'
            fprintf('Processing %s as a PROTEIN file\n\n',val_FASTA_METAGENOME_PATHFILE);
            format_command = [ QUOTE val_BLAST_BIN_FOLDER  'makeblastdb' QUOTE ' -dbtype prot -parse_seqids -in ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE];
        case 'nucl'
            fprintf('Processing %s as a NUCLEOTIDE file\n\n',val_FASTA_METAGENOME_PATHFILE);
            format_command = [ QUOTE val_BLAST_BIN_FOLDER  'makeblastdb' QUOTE ' -dbtype nucl -parse_seqids -in ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE];
    end
    
    fprintf('>%s\n',format_command);
        
    if system(format_command)~=0
        h=errordlg('problem executing makeblastdb');
        uiwait(h);
        return
    end

    % PARALLEL BLASTALL
    
    if PARALLEL
        % Split input FASTA file into number of threads based on input number by user
        fprintf('\nParallel processing is ON\n')
        fprintf('splitting RefSeq FASTA file into %d files...\n',val_N_THREADS);
        [val_FASTA_REFSEQ_PATHFILE_NEW ID] = SplitFile(val_FASTA_REFSEQ_PATHFILE, val_N_THREADS);
    else
        fprintf('Parallel processing is OFF\n')
    end
    
    % print message what is going to happen next
    fprintf('\n*** Blasting %s against %s (number of threads used: %d)***\n\n',val_FASTA_REFSEQ_FILE, val_FASTA_METAGENOME_FILE,val_N_THREADS);

    % run blastp
    % c code command is: /..../blast-###/bin/blastall �i <RefSeq_FASTA> �p blastp �d <metagenome_FASTA> �o <outputfile> �m 8 �e <E_value_thresh>
    
    if PARALLEL
        % write parallel blast commands
        for blst_thds = 1:val_N_THREADS
            % tmp out file names
            val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds}= sprintf('%s_%d_%d',val_BLAST_OUTPUT_PATHFILE,blst_thds,ID);

            switch MolTypeFromGUI
                 
                case 'prot'                   
                    %blastall_command{blst_thds} = sprintf('%sblastall -i ''%s'' -p blastp -d ''%s'' -o ''%s'' -m 8 -e %g',val_BLAST_BIN_FOLDER,val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds},[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE],val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds},val_E_TH_BLAST );
                    %blastall_command{blst_thds} = sprintf('legacy_blast.pl
                    %blastall -i ''%s'' -p blastp -d ''%s'' -o ''%s'' -m 8 -e %g',val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds},[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE],val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds},val_E_TH_BLAST );
                    blastall_command{blst_thds} = [QUOTE val_BLAST_BIN_FOLDER 'blastp' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds} QUOTE ' -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds} QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
                case 'nucl'
                    % The '-seg no' options means no filtering on the query = RefSeq genes. An example of filtering is low complexity filtering - filtering regions of 
                    % low complexity that may lead to FA. For blastp the default is 'no'. For tblastn the default is with filtering while for blastp the default is no filtering.
                    % Although '-seg no' may yield false alarms, the E value for a genuine hit is
                    % closer to reality. Since we are filtering results by E value, it is important for the E value to reflect the true E value.
                    
                    blastall_command{blst_thds} = [QUOTE val_BLAST_BIN_FOLDER 'tblastn' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds} QUOTE ' -seg no -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds} QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
            end          
            fprintf('>%s\n',blastall_command{blst_thds})
        end

        % open 'val_N_THREADS' matlab workers
%         eval(sprintf('matlabpool open local %d',val_N_THREADS));
        poolobj = parpool(val_N_THREADS);

        % run blastall
        parfor blst_thds = 1:val_N_THREADS
            stat(blst_thds) = system(blastall_command{blst_thds});
        end
        
%         matlabpool close
          delete(poolobj)
      
        if max(stat)~=0
            h=errordlg('problem executing blast (with parallel on)');
            uiwait(h);
            return
        end
        
        % combine results files together
        CombineFiles(val_BLAST_OUTPUT_PATHFILE_NEW,val_BLAST_OUTPUT_PATHFILE);
        
    else % NOT PARALLEL
        switch MolTypeFromGUI
            case 'prot'
                %blastall_command{1} = [QUOTE val_BLAST_BIN_FOLDER
                %'tblastn' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE QUOTE ' -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST)];
                blastall_command{1} = [QUOTE val_BLAST_BIN_FOLDER 'blastp' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE QUOTE ' -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
            case 'nucl'
                blastall_command{1} = [QUOTE val_BLAST_BIN_FOLDER 'tblastn' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE QUOTE ' -seg no -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
        end
        
        fprintf('>%s\n',blastall_command{1});
        %blastall_command{1}
        %keyboard
        if system(blastall_command{1})~=0
            h=errordlg('problem executing blast (with parallel off)');
            uiwait(h);
            return
        end
    end
    
    % note time BLAST analysis finished to report in output file
    dt.blast = toc;
    finish.blast_date = date;
    finish.blast_time = clock;
    
    % delete tmp files we created
    if PARALLEL
        DeleteFiles(val_FASTA_REFSEQ_PATHFILE_NEW);
        DeleteFiles(val_BLAST_OUTPUT_PATHFILE_NEW);
    end
    if move_ncbi_ini
        movefile('c:\windows\ncbi.ini~','c:\windows\ncbi.ini')
    end
end

% run MetaMiner
% get MetaMiner parameters from GUI and GetParams

% Check if RefSeq file is GenPept format or FASTA format
fp = fopen(val_GENPEPT_REFSEQ_PATHFILE,'r');
line = [];
while isempty(line)
    line = strtrim(fgetl(fp));
end
if line(1)=='>'
    IN.FASTA_REFSEQ_FILE = val_GENPEPT_REFSEQ_PATHFILE;
    IN.GENPEP_REFSEQ_FILE  = '';
else
    IN.FASTA_REFSEQ_FILE  = '';
    IN.GENPEP_REFSEQ_FILE = val_GENPEPT_REFSEQ_PATHFILE;
end

cd(['..' filesep 'output'])
val_MetaMiner_output_FOLDER  = [pwd filesep];
cd(['..' filesep 'bin']);

[IN_DEFAULT t t outfile_ext] = GetParams();

IN.BLAST_file_name               = val_BLAST_OUTPUT_PATHFILE;
IN.OUTPUT_NAME                   = val_METMINER_OUTNAME;
IN.E_TH                          = val_E_TH_METAMINER;
IN.MIN_IDNT_PERC_OF_CONTIG_LISTS = IN_DEFAULT.MIN_IDNT_PERC_OF_CONTIG_LISTS;
IN.version                       = IN_DEFAULT.version;
IN.FASTA_METAGENOME_FILE         = val_FASTA_METAGENOME_PATHFILE;

% add output path to outfile names with .txt extention
tt = find(val_BLAST_OUTPUT_FILE=='.');
if ~isempty(tt)
    blast_outfile_no_ext = val_BLAST_OUTPUT_FILE(1:tt(1)-1);
else
    blast_outfile_no_ext = val_BLAST_OUTPUT_FILE;
end
for i=1:length(outfile_ext)
    OUTFILE{i} = [val_MetaMiner_output_FOLDER,  blast_outfile_no_ext, '_', IN.OUTPUT_NAME, outfile_ext{i}, '.txt'];
end

% run MetaMiner
global PROG_NAME 
fprintf('\n*** Running %s ***\n\n',PROG_NAME)
% load(['..' filesep 'msrc' filesep 'RefSeq_file_name_header.mat']);
% IN.FASTA_REFSEQ_FILE   = sprintf('%s.faa', RefSeq_file_name_header);
% IN.GENPEP_REFSEQ_FILE  = sprintf('%s.gpff', RefSeq_file_name_header);

MetaMiner30(IN,OUTFILE,start,finish,dt,blastall_command,val_N_THREADS);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function FASTA_REFSEQ_FILE_BROWSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes during object creation, after setting all properties.
function text16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN  = GetParams();
set(hObject,'String',IN.version,'HorizontalAlignment','left');



% --- Executes on button press in BLAST_OUTPUT_FILE_BROWSE.
function BLAST_OUTPUT_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(['..' filesep 'output']);
[file path] = uigetfile('*.txt');
cd(['..' filesep 'bin']);

if file(1)~=0
    handles.val_BLAST_OUTPUT_PATHFILE = [path file];
    BLAST_OUTPUT_FILE_Callback(handles.BLAST_OUTPUT_FILE, [], handles)
end



% --- Executes on button press in BLAST_BIN_FOLDER_BROWSE.
function BLAST_BIN_FOLDER_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


val_BLAST_BIN_FOLDER = uigetdir(get(handles.BLAST_BIN_FOLDER,'String'));

if val_BLAST_BIN_FOLDER(1)~=0
    handles.val_BLAST_BIN_FOLDER = val_BLAST_BIN_FOLDER ;
    BLAST_BIN_FOLDER_Callback(handles.BLAST_BIN_FOLDER, [], handles)
    try
        save blast_bin_folder val_BLAST_BIN_FOLDER
    catch
        warndlg('Problem writing defult params to disk')
    end
end

function BLAST_BIN_FOLDER_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_BLAST_BIN_FOLDER')
    set(hObject,'String',handles.val_BLAST_BIN_FOLDER);
    % check if blast folder exists, if it does if blast is installed, and if not download it from ftp website

end

% Hints: get(hObject,'String') returns contents of BLAST_BIN_FOLDER as text
%        str2double(get(hObject,'String')) returns contents of BLAST_BIN_FOLDER as a double


% --- Executes during object creation, after setting all properties.
function BLAST_BIN_FOLDER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if exist('blast_bin_folder.mat')>0
    load blast_bin_folder.mat
    bin_folder = val_BLAST_BIN_FOLDER;
else
    [t t BLAST] = GetParams();
    bin_folder = BLAST.BLAST_BIN_FOLDER;
end
set(hObject,'String',bin_folder);



% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in BLAST_ON.
function BLAST_ON_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of BLAST_ON

IN = GetParams();
[t default_filename_no_path default_filename_with_path] = GetPathAndName(IN.BLAST_file_name);

global PROG_NAME
if (get(hObject,'Value') == get(hObject,'Max'))
   % Checkbox is checked-take approriate action
   % Activate certain fields
   %set(handles.BLAST_BIN_FOLDER            ,'Enable','on');
   %set(handles.BLAST_BIN_FOLDER_BROWSE     ,'Enable','on');
   set(handles.FASTA_METAGENOME_FILE       ,'Enable','on');
   set(handles.FASTA_METAGENOME_FILE_BROWSE,'Enable','on');
   set(handles.E_VALUE_BLAST               ,'Enable','on'); 
   set(handles.FASTA_REFSEQ_FILE           ,'Enable','on');
   set(handles.FASTA_REFSEQ_FILE_BROWSE    ,'Enable','on');
   set(handles.BLAST_OUTPUT_FILE           ,'String',default_filename_no_path);
   set(handles.BLAST_OUTPUT_FILE_BROWSE    ,'Enable','off');
   set(handles.RUN_BLAST_METAMINER, 'String', ['Run BLAST &' PROG_NAME]);

else
   % Checkbox is not checked-take approriate action
   % Inactivate certain fields
   %set(handles.BLAST_BIN_FOLDER            ,'Enable','off');
   %set(handles.BLAST_BIN_FOLDER_BROWSE     ,'Enable','off');
   set(handles.FASTA_METAGENOME_FILE       ,'Enable','off');
   set(handles.FASTA_METAGENOME_FILE_BROWSE,'Enable','off');
   set(handles.E_VALUE_BLAST               ,'Enable','off');
   set(handles.FASTA_REFSEQ_FILE           ,'Enable','off');
   set(handles.FASTA_REFSEQ_FILE_BROWSE    ,'Enable','off');
   set(handles.BLAST_OUTPUT_FILE           ,'String',default_filename_with_path);
   set(handles.BLAST_OUTPUT_FILE_BROWSE    ,'Enable','on');
   set(handles.RUN_BLAST_METAMINER, 'String', ['Run ' PROG_NAME]);
end

% --- Executes during object creation, after setting all properties.
function BLAST_ON_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Default is set to ON
set(hObject,'Value', get(hObject,'Max'));



% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
%axes(hObject);
%imshow('caltech_logo.gif');
% Hint: place code in OpeningFcn to populate axes1




% --- Executes on selection change in N_THREADS.
function N_THREADS_Callback(hObject, eventdata, handles)
% hObject    handle to N_THREADS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns N_THREADS contents as cell array
%        contents{get(hObject,'Value')} returns selected item from N_THREADS


% --- Executes during object creation, after setting all properties.
function N_THREADS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N_THREADS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% works only if Parallel Computing Toolbox is on
MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer);
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end

if ParallelToolBoxFound
    Ncpus = maxNumCompThreads('automatic');
    threads = [1:Ncpus];
%     set(hObject,'Enable','on','String',num2cell(threads),'HorizontalAligment','center','Value',maxNumCompThreads);
    set(hObject,'Enable','on','String',num2cell(threads),'Value',maxNumCompThreads);
else
    set(hObject,'Enable','off');
end

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function CALTECH_LOGO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CALTECH_LOGO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
%axes(hObject);
%set(hObject,'NextPlot','add')
%imshow('caltech_logo.gif');



% Hint: place code in OpeningFcn to populate CALTECH_LOGO




% --- Executes during object creation, after setting all properties.
function NUM_CPU_TEXT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NUM_CPU_TEXT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer);
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end
if ParallelToolBoxFound
    set(hObject,'Enable','on');
else
    set(hObject,'Enable','off');
end



% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'Name','');



% --- Executes on button press in ABOUT.
function ABOUT_Callback(hObject, eventdata, handles)
% hObject    handle to ABOUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
IN = GetParams();
msgbox(sprintf('MCRL - Metagenome Clustering by Reference Library %s (beta)\n\nWritten by: Arbel D. Tadmor \nCalifornia Institute of Technology\nPasadena, CA 91125, USA\n\nThis program uses blast2.2.22+ provided by NCBI\n\nCopyright 2019 California Institute of Technology, Pasadena, CA.\nAll Rights Reserved.',IN.version));

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text25.
function text25_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function pushbutton12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



% --- Executes during object creation, after setting all properties.
function CAT_LOGO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CAT_LOGO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
%hObject
%axes(hObject);
set(hObject,'NextPlot','add')
%imshow('cat.gif');
x=imread('cat2.gif');
f=image(x);

% Hint: place code in OpeningFcn to populate CAT_LOGO




% --- Executes during object creation, after setting all properties.
function BLAST_BIN_FOLDER_BROWSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close all;
return;


% --- Executes during object creation, after setting all properties.
function BLAST_OUTPUT_FILE_BROWSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

set(hObject,'Enable','off');





% --- Executes on selection change in METAG_DATA_TYPE.
function METAG_DATA_TYPE_Callback(hObject, eventdata, handles)

% hObject    handle to METAG_DATA_TYPE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns METAG_DATA_TYPE contents as cell array
%        contents{get(hObject,'Value')} returns selected item from METAG_DATA_TYPE


% --- Executes during object creation, after setting all properties.
function METAG_DATA_TYPE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to METAG_DATA_TYPE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
