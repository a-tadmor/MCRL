function write_RelatedContigs(outfile,TABLE,msg)
% TABLE = BHT/FBHT

fprintf('Writing output file: %s\n\n',outfile);

fp0 = fopen(outfile,'w');

fprintf(fp0,'%s\n\n',msg);
fprintf(fp0,'\tIndex\tRefSeq gene\tRefSeq gene definition\tMetagenome gene object ID with lowest E value\t# of metagenome gene objects similar to this RefSeq gene\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tRefSeq gene length (amino acids)\t %% of RefSeq gene length aligned\taa sequence\n');
  
for i =1:length(TABLE.N_contigs_vec)
    % These fields are not available for 'AllGenes' file
    [best_Gene_len_vec,  best_Align_perc_of_gene_vec] = str_format(TABLE.best_Gene_len_vec(i),TABLE.best_Align_perc_of_gene_vec(i));
    
    fprintf(fp0,'\ntable\t%d)\t%s\t%s\t%s\t%d\t%.1f\t%d\t%e\t%d\t%s\t%s\t%s\t \n',i,TABLE.Unique_phage_gene_vec{i}, TABLE.best_description_vec{i}, TABLE.List_of_contigs{i}{1}, TABLE.N_contigs_vec(i),TABLE.max_Percent_Ident_vec(i), TABLE.max_Number_of_Ident_vec(i),TABLE.min_E_value_vec(i), TABLE.best_Align_length_vec(i), best_Gene_len_vec,best_Align_perc_of_gene_vec,TABLE.best_seq_vec{i});
    fprintf(fp0,'All related contigs:\n');
    for j=1:length(TABLE.List_of_contigs{i})
        fprintf(fp0,'%s\n',TABLE.List_of_contigs{i}{j});
    end
end

fclose(fp0);