function OUT = obtain_description_GENPEPT(genpeptfile,StartSearchFrom,StartOfRecord)

% FASTA file:
%>gene_id DESCRRIPTION...
%MLMMVIRIYIHKRLNAKDYNNFYTSIGDFGYTIPGSDAPQYNIESDSEHYLNFGIAHINFNNGTNNQITN...
%
% gene_id is extracted by BLASTALL and is part of the hit table

% Prepare variables for location of the pervious Version field in the GenPept file


GENPEPT = retrieve_GENPEPT_record(StartOfRecord,StartSearchFrom,genpeptfile);

OUT.Sequence                 = upper(GENPEPT.Sequence);
OUT.gene_len                 = length(OUT.Sequence);
OUT.Source                   = GENPEPT.Source;
OUT.SourceOrganism           = GENPEPT.SourceOrganism;
OUT.Definition               = GENPEPT.Definition;
OUT.LocusGenBankDivision     = GENPEPT.LocusGenBankDivision;
OUT.LocusMoleculeType        = GENPEPT.LocusMoleculeType;

% GET Comment FIELD
Nrows = size(GENPEPT.Comment);
str=' ';
for j=1:Nrows
    str=[str sprintf('%s  ',strtrim(GENPEPT.Comment(j,:)))];
end;
OUT.Comment = str;

% GET SourceOrganism FIELD
Nrows = size(GENPEPT.SourceOrganism);
str=[];
for j=1:Nrows
    str=[str sprintf('%s  ',strtrim(GENPEPT.SourceOrganism(j,:)))];
end;
OUT.SourceOrganism = str;


% GET FEATURES FIELD
Nrows = size(GENPEPT.Features);
str=[];
for j=1:Nrows
    str=[str sprintf('%s  ',strtrim(GENPEPT.Features(j,:)))];
end;
OUT.Features = str;

