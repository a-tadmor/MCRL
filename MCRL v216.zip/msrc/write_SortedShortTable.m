function write_SortedShortTable(outfile,ST,msg)

fprintf('Writing output file: %s\n\n',outfile);

% Sort RefSeqs by number of related contigs
[ttt Ncontig_sort_ind] = sort(ST.N_contigs_vec); 
Ncontig_sort_ind = fliplr(Ncontig_sort_ind);

% PRINT JUST SHORT LIST OF EACH NCBI GENE REPRESENTATIVE FOR EACH NETWORK
fp3 = fopen(outfile,'w');

fprintf(    '%s\n\n',msg);
fprintf(fp3,'%s\n\n',msg);

fprintf(    'Index\tRefSeq gene\tMetagenome gene object ID with lowest E value\t# of metagenome gene objects similar to this RefSeq gene\ttot # of metagenome gene objects associated with this RefSeq gene group\t# of related RefSeq genes\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tRefSeq gene length (amino acids)\t %% of RefSeq gene length aligned\taa sequence\tRefSeq gene definition');
fprintf(fp3,'Index\tRefSeq gene\tMetagenome gene object ID with lowest E value\t# of metagenome gene objects similar to this RefSeq gene\ttot # of metagenome gene objects associated with this RefSeq gene group\t# of related RefSeq genes\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tRefSeq gene length (amino acids)\t %% of RefSeq gene length aligned\taa sequence\tRefSeq gene definition');
fprintf(     '\tGenPept GenBank division\tGenPept molecule type\tGenPept source\tGenPept classification\tGenPept comments\tGenPept Features\n');
fprintf(fp3, '\tGenPept GenBank division\tGenPept molecule type\tGenPept source\tGenPept classification\tGenPept comments\tGenPept Features\n');

for j=1:length(ST.N_contigs_vec)
    i= Ncontig_sort_ind(j);
      
    [best_Gene_len_vec,  best_Align_perc_of_gene_vec] = str_format(ST.best_Gene_len_vec(i),ST.best_Align_perc_of_gene_vec(i));

    fprintf(    '%d)\t%s\t%s\t%d\t%d\t%d\t%.1f\t%d\t%e\t%d\t%s\t%s\t%s\t%s',j,ST.Unique_phage_gene_vec{i}, ST.List_of_contigs{i}{1}, ST.N_contigs_vec(i),ST.N_tot_contigs_in_network(i),ST.Number_of_related_NCBI_genes(i),ST.max_Percent_Ident_vec(i), ST.max_Number_of_Ident_vec(i),ST.min_E_value_vec(i), ST.best_Align_length_vec(i), best_Gene_len_vec,best_Align_perc_of_gene_vec,ST.best_seq_vec{i},ST.best_description_vec{i});
    fprintf(fp3,'%d)\t%s\t%s\t%d\t%d\t%d\t%.1f\t%d\t%e\t%d\t%s\t%s\t%s\t%s',j,ST.Unique_phage_gene_vec{i}, ST.List_of_contigs{i}{1}, ST.N_contigs_vec(i),ST.N_tot_contigs_in_network(i),ST.Number_of_related_NCBI_genes(i),ST.max_Percent_Ident_vec(i), ST.max_Number_of_Ident_vec(i),ST.min_E_value_vec(i), ST.best_Align_length_vec(i), best_Gene_len_vec,best_Align_perc_of_gene_vec,ST.best_seq_vec{i},ST.best_description_vec{i});

    fprintf(    '\t%s\t%s\t%s\t%s\t%s\t%s\n',ST.LocusGenBankDivision{i}, ST.LocusMoleculeType{i} , ST.Source{i}, ST.SourceOrganism{i}, ST.Comment{i}, ST.Features{i});
    fprintf(fp3,'\t%s\t%s\t%s\t%s\t%s\t%s\n',ST.LocusGenBankDivision{i}, ST.LocusMoleculeType{i} , ST.Source{i}, ST.SourceOrganism{i}, ST.Comment{i}, ST.Features{i});

end

fclose(fp3);
