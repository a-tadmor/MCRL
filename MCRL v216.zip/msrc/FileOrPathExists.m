function good = FileOrPathExists(filename)
% should be legal for both UNIX and DOS. blast files can't have spaces for PCs

good = 1;
if isempty(filename)
    good = 0;
    h=errordlg('File name cann''t be blank');
    uiwait(h);
    return
end

if exist(filename)==0
    h=errordlg([filename ' does not exist']);
    uiwait(h);
    good = 0;
    return
end