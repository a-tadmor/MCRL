clear all
outfile = 'combined_all';


%addpath(['..' filesep 'msrc']);
filenames = dir;
filenames = filenames(3:end);

f = 0;
for i=1:length(filenames)
    if ~strcmp(filenames(i).name, sprintf('%s.m',mfilename))
        f=f+1;
        good_filenames{f} = filenames(i).name;
    end
end

%CombineFiles(good_filenames,outfile);


fp_out = fopen(outfile,'w');

for i = 1:length(good_filenames)
    fprintf('combining file (%d/%d): %s\n',i,length(good_filenames),good_filenames{i});
    fp_in = fopen(good_filenames{i},'r');
    while ~feof(fp_in)
        next_line = fgets(fp_in);        
        if next_line(1) ~= -1
            fprintf(fp_out,'%s',next_line);
        end
    end
    fclose(fp_in);
end

fclose(fp_out);


fprintf('The output file "%s" in\n %s \nis a concatenation of the following files:\n',outfile,pwd);
for i=1:f
        fprintf('%s\n',good_filenames{i});
end
