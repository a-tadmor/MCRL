function related_hits_for_ith_hit = find_related_genes(val_N_THREADS, N_RefSeq_genes,List_of_contigs,MIN_IDNT_PERC_OF_CONTIG_LISTS, SIGNATURE_MIN_MAX_STR, RUN_ID)
% <--MCRL_MAIN.m

ttt=0;
Min_RefSeq_genes = 40; % Minimum # of RefSeq genes for paralell processing

PARALLEL = val_N_THREADS>1;
 if PARALLEL && (N_RefSeq_genes<Min_RefSeq_genes || N_RefSeq_genes/val_N_THREADS<10)
     PARALLEL = 0;
     fprintf('Too few RefSeq genes for parallel processing\n');
 end
 
% There is still room for speedup by X2 since RelatedGene matrix is symmetric

if PARALLEL %Sept 13, 2011 v2.1.1
    fprintf('Parallel processing is ON\n');
    % PARALLEL PROCESSING ACTIVE
    last_i=1; 
    % Find RefSeq indices for each matlab worker
    for i=1:val_N_THREADS-1
        cur_i = last_i + round(N_RefSeq_genes/val_N_THREADS) -1;
        RefSeq_genes_indx_vec(i,:) = [last_i, cur_i];
        last_i = cur_i + 1;            
    end
    
    RefSeq_genes_indx_vec(val_N_THREADS,:) = [last_i, N_RefSeq_genes];
    
    % Delete previous tmp files
    for i=1:val_N_THREADS    
        if exist(sprintf('../tmp/%s_tmp_%d.txt',  RUN_ID, i),'file')==2
            delete(sprintf('../tmp/%s_tmp_%d.txt',RUN_ID, i));
        end
    end
        
    related_hits_for_ith_hit_tmp=cell([1,val_N_THREADS]); 
    parfor blst_thd = 1:val_N_THREADS
        ttt=0;
        for i = RefSeq_genes_indx_vec(blst_thd,1) : RefSeq_genes_indx_vec(blst_thd,2)
            % Print counter to screen
            if blst_thd==1
                if N_RefSeq_genes/val_N_THREADS > 100 && i/10==round(i/10)
                    ttt = ttt + 1; if ttt == 10, fprintf('\n'); ttt=0; end
                    fprintf('%d%%...',round(100*i/(N_RefSeq_genes/val_N_THREADS)));
                end
            end
            
            % Find related genes to i-th RefSeq gene
            related_hits_for_ith_hit_tmp{blst_thd} = [];
            for  j = 1:N_RefSeq_genes
                [percent_identical_contigs_MIN, percent_identical_contigs_MAX] = calc_percent_identical_contigs(List_of_contigs{i},List_of_contigs{j}); % This function is symetric in i and j
                switch SIGNATURE_MIN_MAX_STR
                    case 'stringent'
                        if percent_identical_contigs_MIN >= MIN_IDNT_PERC_OF_CONTIG_LISTS
                            % Each genes points to several other REFSEQ genes that have a similar contig list. Thus each REFSEQ gene is assoicated witha network. This network always contains at least one elemet: the gene pointing to itself.
                            related_hits_for_ith_hit_tmp{blst_thd} = [related_hits_for_ith_hit_tmp{blst_thd}, j];
                        end
                    case 'inclusive'
                        if percent_identical_contigs_MAX >= MIN_IDNT_PERC_OF_CONTIG_LISTS
                            % Each genes points to several other REFSEQ genes that have a similar contig list. Thus each REFSEQ gene is assoicated witha network. This network always contains at least one elemet: the gene pointing to itself.
                            related_hits_for_ith_hit_tmp{blst_thd} = [related_hits_for_ith_hit_tmp{blst_thd}, j];
                        end
                end
            end
            % For each RefSeq gene add to the temparary text file a line with all the indices of the RefSeq genes related to this RefSeq gene
            if isunix
                dlmwrite(sprintf('../tmp/%s_tmp_%d.txt',RUN_ID, blst_thd), related_hits_for_ith_hit_tmp{blst_thd},  '-append', 'newline','unix')
            else
                dlmwrite(sprintf('../tmp/%s_tmp_%d.txt',RUN_ID, blst_thd), related_hits_for_ith_hit_tmp{blst_thd},  '-append', 'newline','pc') 
            end
        end
    end

    % Combine results from text files
    fprintf('\nCombining results from files...\n');
    related_hits_for_ith_hit = [];
    for i=1:val_N_THREADS
        k = RefSeq_genes_indx_vec(i,1);
        fid=fopen(sprintf('../tmp/%s_tmp_%d.txt',RUN_ID, i));
        while 1
            tline = fgetl(fid);
            if ~ischar(tline), break, end
            eval(sprintf('related_hits_for_ith_hit{k}=[%s];',tline));
            k = k + 1;
        end
        fclose(fid);
    end    
    
    %related_hits_for_ith_hit_par = related_hits_for_ith_hit;
    %save tmp_par related_hits_for_ith_hit_par;
else
    % NO PARALLEL PROCESSING
    fprintf('Parallel processing is OFF\n');
    related_hits_for_ith_hit = cell([1,N_RefSeq_genes]);

    for i = 1:N_RefSeq_genes
        % PRINT OUT TO SCREEN PERCENT FINISHED SO FAR
        if N_RefSeq_genes>100 && i/10==round(i/10)
            ttt=ttt+1; if ttt ==10, fprintf('\n'); ttt=0; end
            fprintf('%d%%...',round(100*i/N_RefSeq_genes));
        end
        
        % COMPARE EACH CONTIG LIST OF A GIVEN REFSEQ GENE TO THE CONTIG LIST OF EVERY THER GENE (INCLUDING SELF)
        for  j = 1:N_RefSeq_genes
            [percent_identical_contigs_MIN, percent_identical_contigs_MAX] = calc_percent_identical_contigs(List_of_contigs{i},List_of_contigs{j}); % This function is symetric in i and j
            switch SIGNATURE_MIN_MAX_STR
                case 'stringent'
                    percent_identical_contigs = percent_identical_contigs_MIN;
                case 'inclusive'
                    percent_identical_contigs = percent_identical_contigs_MAX;
            end
            if percent_identical_contigs >= MIN_IDNT_PERC_OF_CONTIG_LISTS
                % Each genes points to several other REFSEQ genes that have a similar contig list. Thus each REFSEQ gene is assoicated witha network. This network always contains at least one elemet: the gene pointing to itself.
                related_hits_for_ith_hit{i} = [related_hits_for_ith_hit{i}, j]; % this vector will always include the self
            end
        end
    end
    %related_hits_for_ith_hit_nopar = related_hits_for_ith_hit;
    %save tmp_nopar related_hits_for_ith_hit_nopar;
end

fprintf('done.\n');
