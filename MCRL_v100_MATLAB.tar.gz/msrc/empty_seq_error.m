function empty_seq_error(FASTA_filename, COMMAND_LINE)
%<--fastaread_fun.m
fprintf('%s.m Error: FASTA file ''%s'' has an illegal format: detected empty record\n',mfilename,FASTA_filename);
if ~COMMAND_LINE
    errordlg(sprintf('FASTA file ''%s'' has an illegal format: detected empty record',FASTA_filename),'Notice');
    error('FASTA file ''%s'' has an illegal format: detected empty record',FASTA_filename);
else
    error('FASTA file ''%s'' has an illegal format: detected empty record',FASTA_filename);
end
keyboard