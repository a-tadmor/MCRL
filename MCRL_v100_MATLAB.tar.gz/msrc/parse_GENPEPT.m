function FILE_PARSE = parse_GENPEPT(genpeptfile)
% Find location value of 'Version' fields 

FILE_PARSE = [];
fid  = fopen(genpeptfile,'r');
if fid==-1
    fprintf('%s debug: cannot open GenPept file ''%s''\n',mfilename,genpeptfile);
    keyboard
end

line = fgetl(fid);
last_record_count = -1;
record_count = 0;
last_location = 0;
ttt=0;

while ~feof(fid)
    if record_count/5000 == round(record_count/5000) && record_count>last_record_count && record_count>0
        fprintf('%d genes read...',record_count);
        ttt=ttt+1; if ttt ==4, fprintf('\n'); ttt=0; end
        last_record_count = record_count;
    end
    % Find next VERSION field
    L = length(line);
    line10 = line(1:min([L,10]));
    if ~isempty(strfind(line10,'VERSION'))
        [s,f,t] = regexp(line,'VERSION\s+(\w|\W)+');  %#ok
        rmdr = line(t{1}(1):t{1}(2));
        GIPos = strfind(rmdr,'GI:');
        if ~isempty(GIPos)
            Version = strtrim(rmdr(1:GIPos-1));
        else
            Version = strtrim(rmdr);
        end
        record_count = record_count +1;
       % NOTE: According to RefSeq release notes "The GI and "ACCESSION.VERSION"  identifiers provide the finest resolution reference to a sequence"
        FILE_PARSE(record_count).Version                          = Version;       % Version field
        FILE_PARSE(record_count).RecordLocation                   = last_location; % File location of Version field
    end
    last_location = ftell(fid);
    line = fgetl(fid);
end
fprintf('done.\n')
fclose(fid);
