function [installed, locate_sources_manually] = install_blast()
% Install BLAST from ncbi website
locate_sources_manually = 0;
global PROG_NAME
global blast_ver

installed = 0;

ncbi_website = 'ftp.ncbi.nlm.nih.gov';
blast_ftp_dir = ['blast/executables/blast+/' blast_ver(1:end-1)];


if isunix
    ANS = questdlg([PROG_NAME ' needs install blast ' blast_ver ' (requires root privileges)' ],'BLAST installation','Automatic installation (recommended)', 'Locate sources on computer','Quit','Automatic installation (recommended)');
else
    ANS = questdlg([PROG_NAME ' needs install blast ' blast_ver],                               'BLAST installation','Automatic installation (recommended)', 'Locate sources on computer','Quit','Automatic installation (recommended)');
end
% find which blast to install
switch computer
    case 'GLNX86'
        %blast_filename  = ['ncbi-blast-' blast_ver '-1.i686.rpm'];
        blast_filename  = ['ncbi-blast-' blast_ver '-ia32-linux.tar.gz'];
    case 'GLNXA64'
        %blast_filename  = ['ncbi-blast-' blast_ver '-1.x86_64.rpm'];
        blast_filename  = ['ncbi-blast-' blast_ver '-x64-linux.tar.gz'];
    case {'MAC','MACI','MACI64'}
        blast_filename  = ['ncbi-blast-' blast_ver '-universal-macosx.tar.gz'];
    case {'PCWIN'}
        blast_filename  = ['ncbi-blast-' blast_ver '-win32.exe'];
    case {'PCWIN64'}
        blast_filename  = ['ncbi-blast-' blast_ver '-win64.exe'];
    case {'SOL64'} % Sun Solaris on SPARC
        blast_filename  = ['ncbi-blast-' blast_ver '-sparc64-solaris.tar.gz'];
    otherwise
        h=warndlg(sprintf('%s does not support the blast utility for your OS. Please proceed to manually install blast version %s from %s',PROG_NAME, blast_ver, ncbi_website),'Notice');
        uiwait(h);
        return
end

switch ANS
    case 'Automatic installation (recommended)'
        % fail ftp
        error_msg =  sprintf('Could not establish an ftp connection. Troubleshooting tips:\n\n(1) Make sure you have an internet connection\n(2) Run MCRL from a local drive (not a network drive)\n(3) Disconnect VPNs\n(4) Temporarily disable your firewall\n(5) Download and install %s manually from %s',blast_filename,['ftp://' ncbi_website '/' blast_ftp_dir]);
        % fail to install
        error_msg2 = sprintf('Could not install blast. Troubleshooting tips:\n\n(1) Run MCRL from a local drive (not a network drive)\n(2) Make sure you have writing privileges\n(3) Make sure other programs are not interfering with running executables\n(4) Download and install %s manually from %s',blast_filename,['ftp://' ncbi_website '/' blast_ftp_dir]);
        if 1 
            % open ftp connection to ncbi
            try
                fprintf(sprintf('Opening ftp connection to %s...\n', ncbi_website));
                ftpobj = ftp(ncbi_website);
            catch
                h=errordlg(error_msg);
                uiwait(h);
                return
            end
            
            % change diretories at ftp site
            try
                cd(ftpobj,blast_ftp_dir);
            catch
                h=errordlg(error_msg);
                uiwait(h);
                close(ftpobj);
                return
            end
            
            % download the file
            try
                fprintf(sprintf('Downloading %s...\n', blast_filename));
                cur_dir = pwd;
                cd(['..' filesep 'blast'])
                blast_folder = pwd;
                fprintf('Beginning MCRL installation - this may take a few minutes...(note: prompts requiring user response are sometimes minimized in the taskbar)\n');
                mget(ftpobj, blast_filename);
                cd(cur_dir);
            catch
                cd(cur_dir);
                h=errordlg(error_msg);
                uiwait(h);
                close(ftpobj);
                return
            end
            close(ftpobj);
        end 
                % install blast
        fprintf(sprintf('Installing %s...\n', blast_filename));
        cd(['..' filesep 'blast'])
 
        switch computer
            %case {'GLNX86','GLNXA64'}
            %    %stat = system(['rpm -ivh ' blast_filename]); % RedHat
            case {'PCWIN','PCWIN64'}
                stat = system(blast_filename(1:end-4));
            case {'MAC','MACI','MACI64','SOL64','GLNX86','GLNXA64'}
                stat = system(['tar -zxvf ' blast_filename]);
        end
        cd(cur_dir);

        if stat~=0 %failed to install
            h=errordlg(error_msg2);
            uiwait(h);
            return
        end
        installed = 1;
        
    case {'Locate sources on computer'}
        locate_sources_manually = 1;
        return
        
    case {'Quit'}
        return
end

