function RUN_ID = get_random_ID()
% <-- main_gui2.m, SetParams.m

RUN_ID = dec2hex(ceil(2^30*rand));

while length(RUN_ID)<8
    RUN_ID = sprintf('%sX',RUN_ID');
end
