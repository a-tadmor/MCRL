function data=retrieve_GENPEPT_record(StartOfRecord,StartSearchFrom,genpeptfile)
% StartOfRecord - where record start (if known)
% StartSearchFrom - file location of last Version field 


%GENPEPTREAD reads GenPept format data files.
%
%   DATA = GENPEPTREAD(FILE) reads in the GenPept formatted sequence from
%   FILE and creates a structure DATA containing fields corresponding to
%   the GenPept keywords. If the file contains information about multiple
%   sequences, then the information will be stored in an array of
%   structures.
%
%   DATA contains these fields:
%       LocusName
%       LocusSequenceLength
%       LocusMoleculeType
%       LocusGenBankDivision
%       LocusModificationDate
%       Definition
%       Accession
%       PID
%       Version
%       GI
%       DBSource
%       Keywords
%       Source
%       SourceDatabase
%       SourceOrganism
%       Reference.Number
%       Reference.Authors
%       Reference.Consrtm
%       Reference.Title
%       Reference.Journal
%       Reference.MedLine
%       Reference.PubMed
%       Reference.Remark
%       Comment
%       Features
%       Weight
%       Length
%       Sequence
%
%   FILE can also be a URL or a MATLAB character array that contains the
%   text of a GenPept format file.
%
%   Based on version 141.0 of GenBank
%
%   Examples:
%
%       % Download a GenPept file to your local drive.
%       getgenpept('AAA59174', 'TOFILE', 'HGENPEPTAAA59174.GPT')
%
%       % Then bring it into a MATLAB sequence.
%       data = genpeptread('HGENPEPTAAA59174.GPT')
%
%   See also FASTAREAD, GENBANKREAD, GETGENPEPT, PDBREAD, SEQTOOL.

% Copyright 2002-2006 The MathWorks, Inc.
% $Revision: 1.16.4.16 $   $Date: 2006/11/08 17:46:25 $

fid  = fopen(genpeptfile,'r');
if fid==-1
    fprintf('%s debug: cannot open Genpept file ''%s''\n',mfilename,genpeptfile);
    keyboard
end

if isempty(StartOfRecord)
    % Now go back to previous VERSION field and find start of record
    fseek(fid,StartSearchFrom,'bof');
    found = 0;
    line = fgetl(fid);
    while ~found
        L = length(line); 
        % MUST LOOK AT FIRST 3 CHARS SINCE SOMETIMES RECORDS HAVE URL ADDRESS (HTTP://)
        line3 = line(1:min([L,3]));
        if ~isempty(strfind(line3,'//'))
            found = 1;
            StartOfRecord = ftell(fid);
        end
        line = fgetl(fid);
    end
end

% Go to start of record
fseek(fid,StartOfRecord,'bof');

% Now read next 1000 lines in file a=
N_line_to_read = 1000;
buffer = textscan(fid,'%s',N_line_to_read,'delimiter','\n','whitespace','');
gptext = char(buffer{1});


% If the input is a string of GenBank data then words LOCUS and DEFINITION must be present
if size(gptext,1)==1 || isempty(strfind(gptext(1,:),'LOCUS')) || isempty(strfind(gptext(2,:),'DEFINITION'));
    error('Bioinfo:genpeptread:NonMinimumRequiredFields','FILE is not a valid GenPept file or url.')
end

% Get first record from this buffer
%line number
ln = 1;

%multiple records possible in one record
record_count=1;

numLines = size(gptext,1);
try

    %LOCUS - Mandatory

    data.LocusName = strtrim(gptext(ln,13:28));  %#ok
    data.LocusSequenceLength =strtrim(gptext(ln,30:40));
    data.LocusNumberofStrands = strtrim(gptext(ln,45:47));
    data.LocusTopology = strtrim(gptext(ln,56:63));
    data.LocusMoleculeType = strtrim(gptext(ln,48:53));
    data.LocusGenBankDivision = strtrim(gptext(ln,65:67));
    data.LocusModificationDate = strtrim(gptext(ln,69:79));

    ln=ln+1;

    %DEFINITION - Mandatory
    [s,f,t] = regexp(gptext(ln,:),'DEFINITION\s+(\w|\W)+'); %#ok
    data.Definition = strtrim(gptext(ln,t{1}(1):t{1}(2)));

    ln=ln+1;

    while ~matchstart(gptext(ln,:),'ACCESSION')
        data.Definition = [data.Definition,' ', strtrim(gptext(ln,:))];
        ln = ln+1;
    end

    %ACCESSION - Mandatory
    [s,f,t] = regexp(gptext(ln,:),'ACCESSION\s+(\w|\W)+');  %#ok
    data.Accession = strtrim(gptext(ln,t{1}(1):t{1}(2)));
    ln=ln+1;
    while ~matchstart(gptext(ln,:),'VERSION')
        data.Accession=[data.Accession ' ' strtrim(gptext(ln,:))];
        ln=ln+1;
    end


    %VERSION - Mandatory
    [s,f,t] = regexp(gptext(ln,:),'VERSION\s+(\w|\W)+');  %#ok
    rmdr = gptext(ln,t{1}(1):t{1}(2));
    GIPos = strfind(rmdr,'GI:');
    data.Version = strtrim(rmdr(1:GIPos-1));

    %GI - Mandatory (part of version)
    data.GI = deblank(rmdr(GIPos+3:end));

    ln=ln+1;

    %PROJECT - New field introduced by NCBI in Feb 2006, treated as
    %optional
    data.Project=[];
    [s,f,t] = regexp(gptext(ln,:),'PROJECT\s+(\w|\W)+'); %#ok
    if ~isempty(s)
        data.Project=deblank(gptext(ln,t{1}(1):t{1}(2)));
        ln=ln+1;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ADT MODIFICATION TO FIT REFSEQ 37/38
    %DBLINK OPTIONAL
    [s,f,t] = regexp(gptext(ln,:),'DBLINK\s+(\w|\W)+'); %#ok
    if ~isempty(s)
        data.DBlink=deblank(gptext(ln,t{1}(1):t{1}(2)));
        ln=ln+1;
    end
    % END OF MODIFICATION
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % ADT MODIFICATION TO FIT REFSEQ 77 Aug 2016
    % skip additional fields until "DBSOURCE" is reached
    while isempty(strfind(gptext(ln,:), 'DBSOURCE'))
        ln=ln+1;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %DBSOURCE
    [s,f,t] = regexp(gptext(ln,:),'DBSOURCE\s+(\w|\W)+');  %#ok
    data.DBSource = strtrim(gptext(ln,t{1}(1):t{1}(2)));

    ln = ln + 1;
    while ~matchstart(gptext(ln,:),'KEYWORDS')
        data.DBSource = [data.DBSource ' ' strtrim(gptext(ln,:))];
        ln=ln+1;
    end

    %KEYWORDS - Mandatory for all annotated records.
    data.Keywords=[];
    [s,f,t] = regexp(gptext(ln,:),'KEYWORDS\s+(\w|\W)+');  %#ok
    if ~isempty(s)
        data.Keywords=deblank(gptext(ln,t{1}(1):t{1}(2)));
        ln=ln+1;
    end
    while ~isempty(s) && ~matchstart(gptext(ln,:),'SOURCE')
        data.Keywords=strvcat(data.Keywords, strtrim(gptext(ln,:)));  %#ok
        ln=ln+1;
    end
    if all(~isletter(data.Keywords))
        data.Keywords = '';
    end

    %SOURCE - Mandatory for all annotated records.
    [s,f,t] = regexp(gptext(ln,:),'SOURCE\s+(\w|\W)+');  %#ok
    data.Source = deblank(gptext(ln,t{1}(1):t{1}(2)));
    ln=ln+1;
    while ~matchstart(gptext(ln,:),'ORGANISM') && ~matchstart(gptext(ln,:),'REFERENCE')
        data.Source = [data.Source ' ' strtrim(gptext(ln,:))];
        ln=ln+1;
    end

    %ORGANISM - Mandatory for all annotated records.
    data.SourceOrganism = [];
    [s,f,t] = regexp(gptext(ln,:),'ORGANISM\s+(\w|\W)+');  %#ok
    if ~isempty(s)
        data.SourceOrganism = strtrim(gptext(ln,t{1}(1):t{1}(2)));
        ln=ln+1;
        while ~matchstart(gptext(ln,:),'REFERENCE') && ~matchstart(gptext(ln,:),'COMMENT')
            % while all(cellfun('isempty',regexp(gptext(ln,:),{'REFERENCE';'COMMENT';'FEATURES';'ORIGIN'})))
            data.SourceOrganism = strvcat(data.SourceOrganism, strtrim(gptext(ln,:)));  %#ok
            ln = ln+1;
        end
    end

    %REFERENCE
    [data,gptext,ln] = referenceparse(data,gptext,ln,record_count);

    %COMMENT - Optional
    data.Comment = [];
    [s,f,t] = regexp(gptext(ln,:),'COMMENT\s+(\w|\W)+');  %#ok
    if ~isempty(s)
        data.Comment = strtrim(gptext(ln,t{1}(1):t{1}(2)));
        ln=ln+1;
        while ~matchstart(gptext(ln,:),'FEATURES') && ~matchstart(gptext(ln,:),'ORIGIN')
            data.Comment=strvcat(data.Comment, strtrim(gptext(ln,:))); %#ok
            ln=ln+1;
        end
    end

    %FEATURES - Optional
    data.Features = [];
    lnFeatures = inf;
    if matchstart(gptext(ln,:),'FEATURES')
        lnFeatures = ln; % save this position to get preamble text later
        feats = cell(numLines-ln,1);
        ln=ln+1;
        featCount = 1;
        feats{featCount} = gptext(ln,1:end);
        ln=ln+1;
        while ~matchstart(gptext(ln,:),'ORIGIN')
            featCount = featCount+1;
            feats{featCount} = gptext(ln,1:end);
            ln=ln+1;
        end
        data.Features = strtrim(strvcat(feats(1:featCount)));  %#ok
    end

    %ORIGIN - Mandatory
    if matchstart(gptext(ln,:),'ORIGIN')
        lnOrigin = ln; % save this position to get preamble text later
        ln=ln+1;
    end

    % SEQUENCE
    data.Sequence = '';
    startln = ln;
    % the sequence will go up to the start of the next possible record
    ln = find(gptext(ln:end,1) == '/' | gptext(ln:end,1) == 'L',1) + ln -1;
    if isempty(ln)
        ln = size(gptext,1);
    end
    endln = ln-1;
    seq = gptext(startln:endln,:)';
    seq = seq(:)';
    seq(~isletter(seq)) = '';
    data.Sequence = seq;


catch
    le = lasterror;
    if strcmpi(le.identifier,'matlab:nomem')
        clear data
        rethrow(le)
    else
        warning('Bioinfo:genpeptread:GenPeptIncomplete',...
            'Problems reading the GenPept data. The structure may be incomplete.');
        keyboard
    end
end


fclose(fid);

