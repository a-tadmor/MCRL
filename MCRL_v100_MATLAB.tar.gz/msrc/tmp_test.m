file = 'tmpbad.faa';
FASTA  = fastaread(file);
FASTA2 = FASTAread(file);
if length(FASTA)~=length(FASTA2)
        fprintf('bad'); keyboard;
end
for i=1:length(FASTA)
    if ~strcmp(FASTA(i).Header,FASTA2(i).Header)
        fprintf('bad'); keyboard;
    end
    if ~strcmp(FASTA(i).Sequence,FASTA2(i).Sequence)
        fprintf('bad'); keyboard;
    end
end
fprintf('EXACT\n');