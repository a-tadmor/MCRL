function MCRL_MAIN(IN, OUTFILE, start, finish, dt, blastall_command, val_N_THREADS, COMMAND_LINE, RUN_ID, val_N_THREADS_BLAST)
% <-- main_gui2.m

% To run MetMiner standalone without GUI - all input arguments should be ignored, parameters are then loaded from GetParams

tic
if ~exist('blastall_command','var') || exist('blastall_command','var') && isempty(blastall_command)
    blastall_command = [];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD ALGORITHM PARAMETERS

start.metaminer_date = date;
start.metaminer_time = clock;

% running MetaMiner from the command line
if ~exist('IN','var')
    [IN, OUTFILE] = GetParams();
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% READ BLAST TABLE
fprintf('1) Reading BLAST hit table file: ''%s''...\n\n',IN.BLAST_file_name)

fid  = fopen(IN.BLAST_file_name,'r');
if fid==-1
    errmsg=sprintf('Cannot open BLAST output file: ''%s''\n',IN.BLAST_file_name);
    fprintf('%s\n',errmsg);
    if ~COMMAND_LINE
        h=errordlg(errmsg);
        uiwait(h);
    else
        error(errmsg);
    end
    return
end

Table = textscan(fid, '%s %s %f %f %f %f %f %f %f %f %f %f');

if isempty(Table{1})
    errmsg = sprintf('BLAST output file %s is empty\n',IN.BLAST_file_name);
    fprintf('%s\n',errmsg);
    if ~COMMAND_LINE, h=warndlg(errmsg,'Notice'); uiwait(h); end
end

fclose(fid);

Phage_gene_vec        = Table{1};                                       % reference gene ID
Contig_vec            = Table{2};                                       % contig ID
Percent_Ident_vec     = Table{3};                                       % Percent Identity
Align_length_vec      = Table{4};                                       % Length of alignment
Number_of_Ident_vec   = round(Percent_Ident_vec.*Align_length_vec/100); % Number of identical amino acids in alignment
E_value_vec           = Table{11};                                      % E value

clear Table;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REDUCE TABLE TO FIRST HIT FOR EACH REFERENCE GENE AND STORE + COUNT THE NUMBER OF CONTIGS RELATED TO THIS HITS (WITH HIGHER E VALUES)
% HIT TABLE IS ORGANIZED AS FOLLOWS:
%
% REFERENCE GENE 1   - CONTIG #1 ... E VALUE (LOWEST E VALUE)  ---> keep E value
% REFERENCE GENE 1   - CONTIG #2 ... E VALUE                   ---> store contig list
% REFERENCE GENE 1   - CONTIG #3 ... E VALUE
%    :               :
% REFERENCE GENE 2   - CONTIG #1 ... E VALUE (LOWEST E VALUE)  ---> keep E value
% REFERENCE GENE 2   - CONTIG #2 ... E VALUE                   ---> store contig list
% REFERENCE GENE 2   - CONTIG #3 ... E VALUE
%    :               :
fprintf('2) Finding best hit for each reference gene...\nPercent completed: ')

j=1;
count=0; BHT=[];
while j<= length(Contig_vec)
    if j/10000==round(j/10000), fprintf('%.1f%%,',j/length(Contig_vec)*100); end
    % FIND NUMBER OF TIMES EACH REFERENCE GENE HIT APPEARS (=NUMBER OF CONTIGS RELATED TO THE SAME REFERENCE GENE)
    i_vec = find(strcmp(Phage_gene_vec,Phage_gene_vec{j}));
    count = count + 1;
    
    [~, sel_uniq_ind_vec] = unique(Contig_vec(i_vec)); % Same Contig can appear more than once in blast report for the same reference gene (if e.g. two or more contigs parts are treated separately)
    % therefore we need the 'unique' function. This may also be important in case tblastn is used for nucl file and the same contig has more
    % than reading frame with a solution. We do not want to count these as separate solutions.
    sel_uniq_ind_vec       = sort(sel_uniq_ind_vec); % keep order of contigs the same
    
    % BEST HIT TABLE (BHT)
    BHT.List_of_contigs{count}         = Contig_vec(i_vec(sel_uniq_ind_vec)); % Select unique contigs (ignore repititions)
    BHT.N_contigs_vec(count)           = length(BHT.List_of_contigs{count}); % Each contig appears only once in this list
    
    % TAKE SCORE OF FIRST CONTIG (=LOWEST E VALUE) FOR EACH REFERENCE GENE
    BHT.min_E_value_vec(count)             = E_value_vec(i_vec(1)); % blastall output is such that first contig has the lowest E value
    BHT.max_Percent_Ident_vec(count)       = Percent_Ident_vec(i_vec(1));
    BHT.max_Number_of_Ident_vec(count)     = Number_of_Ident_vec(i_vec(1));
    BHT.Unique_phage_gene_vec(count)       = Phage_gene_vec(i_vec(1));
    BHT.best_Align_length_vec(count)       = Align_length_vec(i_vec(1));
    BHT.best_Gene_len_vec(count)           = -1;
    BHT.best_Align_perc_of_gene_vec(count) = -1;
    BHT.best_seq_vec{count}                = 'N/A';
    BHT.best_description_vec{count}        = 'N/A';
    
    % GO TO NEXT REFERENCE GENE HIT
    j = max(i_vec) + 1;
end
fprintf('\n');

clear Phage_gene_vec E_value_vec Number_of_Ident_vec Align_length_vec Contig_vec Percent_Ident_vec;

% PRINT TABLE TO FILE
% msg = 'Table showing for each reference gene the representative contig (no filtering of reference genes, E value threshold as set for blastall)';
msg = sprintf('Table showing for each reference gene (E < %g) the representative contig followed by its signature in the metagenome.', IN.E_TH_BLAST);
if IN.DEBUG
    write_RelatedContigs(OUTFILE{2},BHT,msg);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REMOVE ALL REFERENCE GENES THAT DO NOT PASS HOMOLOGY THRESHOLD WITH RESPECT TO BEST HIT IN THE METAGENOME
% Statistic used for sorting in next sheet:  E<=E_th=1e-7 (default value)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('\n3) Filtering reference genes (E value<=%g)',IN.E_TH );
% Parse the FASTA/GenPept file
if isempty(IN.GENPEP_REFSEQ_FILE)
    fprintf('\nParsing reference library FASTA file ''%s''...\n',IN.FASTA_REFSEQ_FILE);
    % try to parse FASTA file retrieving the Definition and file location of every record
    FILE_PARSE = parse_FASTA(IN.FASTA_REFSEQ_FILE);
else
    fprintf('\nParsing reference library GenPept file ''%s''...\n',IN.GENPEP_REFSEQ_FILE);
    % try to parse GenPept file retrieving the Version and file location of every record
    FILE_PARSE = parse_GENPEPT(IN.GENPEP_REFSEQ_FILE);
end

if isempty(FILE_PARSE)
    errmsg= sprintf('Problem parsing reference library files - no values returned.\n');
    fprintf('%s\n',errmsg);
    if ~COMMAND_LINE
        h=errordlg(errmsg);
        uiwait(h);
        error(errmsg)
    else
        error(errmsg)
    end
    keyboard;
end
Lrecs = length(FILE_PARSE);
fprintf('\nDone. Read a total of %d reference genes.\n\n',Lrecs);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
fprintf('Filtering list:\n');

count = 0;tmp=0;
if ~isempty(BHT) % BUG FIX v309
    % FORM FILTERED BLAST HIT TABLE (FBHT)
    for i =1:length(BHT.Unique_phage_gene_vec)
        
        % PRINT TO SCREEN PERCENT FINISHED
        if length(BHT.Unique_phage_gene_vec)>100 && i/100==round(i/100)
            tmp=tmp+1; if tmp ==10, fprintf('\n'); tmp=0; end
            fprintf('%d%%...',round(100*i/length(BHT.Unique_phage_gene_vec)));
        end
        
        % FILTERING CONDITION
        if (BHT.min_E_value_vec(i) <= IN.E_TH) %|| (BHT.max_Percent_Ident_vec(i) >= IN.MIN_PERC_IDNT) && (BHT.max_Number_of_Ident_vec(i) >= IN.MIN_IDT_LEN )
            % RETRIEVE AND STORE DATA ON NEW FOUND REFERENCE GENE
            count = count + 1;
            hit_vec(count) = i;
            FBHT.List_of_contigs{count} = BHT.List_of_contigs{i};
            gene_id                     = BHT.Unique_phage_gene_vec{i}; % This is the ID of the gene as appeared in the blastall file
            
            % Find location of this gene's record in the FASTA or GenPept file (doing it in the main is more memory efficient)
            rec=0; found = 0;
            if isempty(IN.GENPEP_REFSEQ_FILE)
                % FASTA FILE SUPPLIED
                while ~found && rec<Lrecs
                    rec=rec+1;
                    % Search for gene_id in FASTA header
                    if ~isempty(strfind(FILE_PARSE(rec).Header,gene_id)), found = 1; end
                end
                if ~found
                    errmsg=sprintf('gene ID ''%s'' was not found in: %s\n', gene_id, IN.FASTA_REFSEQ_FILE);
                    fprintf('%s\n',errmsg);
                    if ~COMMAND_LINE
                        h=errordlg(errmsg);
                        uiwait(h);
                        error(errmsg)
                    else
                        error(errmsg);
                    end
                    keyboard
                end
                OUT  = obtain_description_FASTA(IN.FASTA_REFSEQ_FILE,FILE_PARSE(rec).RecordLocation,gene_id);
                
            else % GENPEPT FILE SUPPLIED
                while ~found && rec<Lrecs
                    rec=rec+1;
                    % Search for Version in gene_id
                    % NOTE: According to RefSeq release notes "The GI and
                    % "ACCESSION.VERSION"  identifiers provide the finest resolution reference to a sequence"
                    if ~isempty(strfind(gene_id,FILE_PARSE(rec).Version)), found = 1; end
                end
                if ~found
                    errmsg=sprintf('\ngene ID ''%s'' was not found in: %s\n',gene_id, IN.GENPEP_REFSEQ_FILE);
                    fprintf('%s\n',errmsg);
                    if ~COMMAND_LINE
                        h=errordlg(errmsg);
                        uiwait(h);
                        error(errmsg)
                    else
                        error(errmsg);
                    end
                    keyboard
                end
                if rec==1
                    StartOfRecord = 0;
                    StartSearchFrom = []; % don't need this
                else
                    StartOfRecord = []; % will need to find this
                    StartSearchFrom = FILE_PARSE(rec-1).RecordLocation; % file location of last Version field - start search from here
                end
                OUT  = obtain_description_GENPEPT(IN.GENPEP_REFSEQ_FILE,StartSearchFrom,StartOfRecord);
            end
            
            FBHT.best_Gene_len_vec(count)           = OUT.gene_len;
            FBHT.best_Align_perc_of_gene_vec(count) = BHT.best_Align_length_vec(i)/OUT.gene_len*100;
            FBHT.best_seq_vec{count}                = OUT.Sequence;
            FBHT.best_description_vec{count}        = OUT.Definition;
            FBHT.LocusGenBankDivision{count}        = OUT.LocusGenBankDivision;
            FBHT.LocusMoleculeType{count}           = OUT.LocusMoleculeType;
            FBHT.Source{count}                      = OUT.Source;
            FBHT.SourceOrganism{count}              = OUT.SourceOrganism;
            FBHT.Comment{count}                     = OUT.Comment;
            FBHT.Features{count}                    = OUT.Features;
        end
    end
end
switch IN.SIGNATURE_MIN_MAX_STR
    case 'stringent'
        SIGNATURE_STR = 'stringent';
    case 'inclusive'
        SIGNATURE_STR = 'inclusive';
end

if count>0 % BUG FIX v309
    FBHT.N_contigs_vec                = BHT.N_contigs_vec(hit_vec);
    FBHT.min_E_value_vec              = BHT.min_E_value_vec(hit_vec);
    FBHT.max_Percent_Ident_vec        = BHT.max_Percent_Ident_vec(hit_vec);
    FBHT.max_Number_of_Ident_vec      = BHT.max_Number_of_Ident_vec(hit_vec);
    FBHT.Unique_phage_gene_vec        = BHT.Unique_phage_gene_vec(hit_vec);
    FBHT.best_Align_length_vec        = BHT.best_Align_length_vec(hit_vec);
    
    % Create MAP container to look up signatures
    SIGNATURE_HASH = containers.Map(FBHT.Unique_phage_gene_vec, FBHT.List_of_contigs);
    fprintf('\ndone.\n');
    
    clear BHT;
    
    % PRINT REDUCED FILT TABLE TO FILE
    msg1 = sprintf('Table showing for each reference gene (E < %g) the representative contig followed by its signature in the metagenome.', IN.E_TH);
    msg3 = sprintf('%s',msg1);
    
    if 1 %IN.DEBUG
        write_RelatedContigs(OUTFILE{3},FBHT,msg3);
    end
    clear FILE_PARSE
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % FIND RELATED REFERENCE GENES
    % FOR EACH REFERENCE GENE (i-TH HIT) FIND NETWORK OF OTHER REFERENCE GENES THAT HAVE
    % A SIMILAR (RELATED) CONTIG LIST. THUS FOR EACH REFERENCE GENE WE ASSOCIATE A NETORK OF REFERENCE GENES.
    N_RefSeq_genes = length(FBHT.Unique_phage_gene_vec);
    if IN.DEBUG
        % matfile = sprintf('../tmp/%s_MCRL_check_point.mat', RUN_ID);
        matfile = ['..' filesep 'tmp' filesep RUN_ID '_MCRL_check_point.mat'];
        fprintf('Saving debugging file %s...\n',matfile);
        save(matfile);
    end
    
    fprintf('\n\n4) Determining related reference genes...\n\n');
    if val_N_THREADS>1
        % open 'val_N_THREADS' matlab workers
        fprintf('\nParallel processing is ON for MCRL post filtering analysis\n')
        %     eval(sprintf('matlabpool open local %d',val_N_THREADS));
        poolobj = parpool(val_N_THREADS);
    else
        fprintf('\nParallel processing is OFF for MCRL post filtering analysis\n')
        poolobj = [];
    end
    
    % Summary of next steps:
    %
    %
    % 1. For i-th reference gene find all related reference genes:
    %
    %                 related_hits_for_ith_hit{i} = indices of all related reference genes
    %
    % 2. Of the group of all related reference genes find the delegate (reference gene with lowest E value):
    %
    %                  lowest_ST_or_FBHT_E_value_index_vec(i) = index defining
    %                  the delegate of the i-th reference gene (index of reference gene yielding the lowest E value out of all reference genes related to the i-th reference gene)
    %
    % 3. At the end of the first iteration, only the delegates are retained:
    %
    %                 ST.related_refseq_genes_FHBT_ind_vec(count)  = [index of 'count'-th delegate, indices of all other reference genes that elected this delegrate]
    % 			                                                              ^
    %                                                                         |
    %                                                    ST.best_ST_or_FBHT_indx_vec(count) = lowest_E_value_index_vec(i);
    %
    % In RelatedGenes file we print all delegates, followed by the reference genes that elected them (and NOT all reference genes that were related)
    %
    %                ST.related_refseq_genes_FHBT_ind_vec{count} = [lowest_E_value_index_vec(i), list of all other reference genes indices that elected the i-th reference gene but yielded higher E values]
    
    
    % For each reference gene (index i), related_hits_for_ith_hit{i} is a vector of all related reference genes
    related_hits_for_ith_hit = find_related_genes(val_N_THREADS, N_RefSeq_genes,FBHT.List_of_contigs,IN.MIN_IDNT_PERC_OF_CONTIG_LISTS, IN.SIGNATURE_MIN_MAX_STR, RUN_ID);
    related_hits_for_ith_hit0 = related_hits_for_ith_hit; % for debugging
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % FOR EACH REFERENCE GENE NETWORK ELECT A DELEGATE TO REPRESENT THIS NETWORK (THE ONE WITH THE LOWEST E VALUE)
    % For each reference gene (index i) lowest_E_value_index_vec(i) is the index of the best delegate (lowest E value)
    lowest_E_value_index_vec = find_delegates(related_hits_for_ith_hit, FBHT);
    
    % COMBINE ALL THE REFERENCE GENES THAT ARE REPRESENTED BY THE SAME DELEGATE REFERENCE GENE %(FORMING THE SHORT TABLE 'ST')
    % :
    % FBHT index
    % 1)
    % 2)
    % :
    % i)  -->  'lowest_E_value_index_vec(i)' = reference gene that has the lowest E value out of the genes related to i  = index of reference gene in FBHT to represent i
    % :
    % :
    ST = keep_only_delegates(lowest_E_value_index_vec, FBHT, SIGNATURE_HASH);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PRINT LIST OF ALL RELATED REFERENCE GENES WITH FULL DESCRIPTION OF GENE (SORTED BY NUMBER OF RELATED CONTIGS)
    if 1%IN.DEBUG
        msg1 = sprintf('Table showing elected reference genes (E<%g) after first filterng iteration.\nEach elected reference gene is followed by the list of related reference genes that elected the given reference gene.\nSignature overlap definition=%s.', IN.E_TH, SIGNATURE_STR);
        write_RelatedGenesTable(OUTFILE{4}, FBHT, ST.N_contigs_vec, ST.related_refseq_genes_TOT_array, ST.best_ST_or_FBHT_str, msg1);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PRINT REDUCED FILT UNIQUE TABLE (SORTED BY NUMBER OF RELATED CONTIGS)
    if IN.DEBUG
        msg5 = sprintf('Table showing for each reference gene (E<%g) the representative contig (signature overlap definition=%s).', IN.E_TH, SIGNATURE_STR);
        fprintf('\nGenerating Short Table (with redundancy):\n')
        write_SortedShortTable(OUTFILE{5},ST,msg5,IN.FASTA_METAGENOME_FILE,IN.MolType, COMMAND_LINE)
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fprintf('\n5) Removing redundant genes:\n')
    
    N_RefSeq_genes_last = length(ST.N_contigs_vec);
    c=1;
    % save tmp_state
    
    ST_CUR = ST;
    while 1
        c=c+1;
        fprintf('Iteration %d...\n',c);
        % For each reference gene (index i), related_hits_for_ith_hit{i} is a vector of indices of all related reference genes
        related_hits_for_ith_hit = find_related_genes(val_N_THREADS, N_RefSeq_genes_last, ST_CUR.List_of_contigs, IN.MIN_IDNT_PERC_OF_CONTIG_LISTS, IN.SIGNATURE_MIN_MAX_STR, RUN_ID);
        
        % 'lowest_E_value_index_vec(i)' = index of reference gene that has the lowest E value out of the genes related to i  = index of reference gene in ST_CUR to represent i
        lowest_E_value_index_vec = find_delegates(related_hits_for_ith_hit, ST_CUR);
        ST_NEW = keep_only_delegates(lowest_E_value_index_vec, ST_CUR, SIGNATURE_HASH);
        N_RefSeq_genes_cur = length(ST_NEW.N_contigs_vec);
        fprintf('Iteration %d of compression, # of reported genes = %d->%d\n',c,N_RefSeq_genes_last,N_RefSeq_genes_cur);
        
        if N_RefSeq_genes_cur==N_RefSeq_genes_last, break, end
        N_RefSeq_genes_last = N_RefSeq_genes_cur;
        ST_CUR = ST_NEW;
    end
    
    fprintf('Coverged to %d reported genes\n',N_RefSeq_genes_last);
    fprintf('Compression completed.\n');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Write output files for user:
    % Signatures:
    % Filter FBHT to retain only genes in ST to create CFBHT. CFBHT is used to write signatures of final reported reference genes to file
    CFBHT = compress_FBHT(ST_NEW, FBHT);
    msg1 = sprintf('Final nonredundant list of reference genes reported by MCRL, sorted by signature size (highest to lowest).\nEach reference gene is followed by its signature in the metagenome.');
    msg3 = sprintf('%s',msg1);
    write_RelatedContigs(OUTFILE{6},CFBHT,msg3);
    
    % Gene cluster memebers:
    % Write list of reference genes related to each reported reference gene and which elected the reported reference gene
    msg1 = sprintf('Final nonredundant list of reference genes reported by MCRL, sorted by signature size (highest to lowest).\nEach reference gene is followed by the list of all related reference genes that elected the given reference gene.');
    write_RelatedGenesTable(OUTFILE{7}, FBHT, ST_NEW.N_contigs_vec, ST_NEW.related_refseq_genes_TOT_array, ST_NEW.best_ST_or_FBHT_str, msg1);
    
    % Final list of non-redudant reference genes:
    msg6 = sprintf('Final nonredundant list of reference genes reported by MCRL, sorted by signature size (highest to lowest)');
    write_SortedShortTable(OUTFILE{8},ST_NEW,msg6,IN.FASTA_METAGENOME_FILE,IN.MolType, COMMAND_LINE);
    
else
    msg1 = sprintf('Table showing for each reference gene (E < %g) the representative contig followed by its signature in the metagenome.', IN.E_TH);
    msg3 = sprintf('%s',msg1);
    write_RelatedContigs(OUTFILE{3},[],msg3);

    msg1 = sprintf('Table showing elected reference genes (E<%g) after first filterng iteration.\nEach elected reference gene is followed by the list of related reference genes that elected the given reference gene.\nSignature overlap definition=%s.', IN.E_TH, SIGNATURE_STR);
    write_RelatedGenesTable(OUTFILE{4}, [], [], [], [], msg1);
    
    msg1 = sprintf('Final nonredundant list of reference genes reported by MCRL, sorted by signature size (highest to lowest).\nEach reference gene is followed by its signature in the metagenome.');
    msg3 = sprintf('%s',msg1);
    write_RelatedContigs(OUTFILE{6},[],msg3);

    msg1 = sprintf('Final nonredundant list of reference genes reported by MCRL, sorted by signature size (highest to lowest).\nEach reference gene is followed by the list of all related reference genes that elected the given reference gene.');
    write_RelatedGenesTable(OUTFILE{7}, [], [], [], [], msg1);
  
    msg6 = sprintf('Final nonredundant list of reference genes reported by MCRL, sorted by signature size (highest to lowest)');
    write_SortedShortTable(OUTFILE{8},[],msg6,IN.FASTA_METAGENOME_FILE,IN.MolType, COMMAND_LINE);
end % if count>0 % BUG FIX v309
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% cd(['..' filesep 'msrc']);
% save workspace_env
% cd(['..' filesep 'bin']);

dt.metaminer = toc;
fprintf('\nRun time = %.1f hours\n',dt.metaminer/3600);

finish.metaminer_date = date;
finish.metaminer_time = clock;

fprintf('\t--> deleting temporary metagenome file %s\n', IN.FASTA_METAGENOME_FILE)
delete(IN.FASTA_METAGENOME_FILE);


% Write param file to output
write_params(IN,OUTFILE,start,finish,dt,blastall_command, val_N_THREADS, val_N_THREADS_BLAST);
if ~isdeployed && ~IN.PARALLEL_SESSIONS
    open(OUTFILE{1});
end

% Delete more tmp files
for i=1:val_N_THREADS
    if exist(sprintf('../tmp/%s_tmp_%d.txt', RUN_ID, i),'file')==2
        delete(sprintf('../tmp/%s_tmp_%d.txt',RUN_ID, i));
    end
end

% Garbage collection
switch IN.Aligner
    case 'blast'
        switch IN.MolType
            case 'prot'
                delete(sprintf('../tmp/*%s*.psq', RUN_ID));
                delete(sprintf('../tmp/*%s*.psi', RUN_ID));
                delete(sprintf('../tmp/*%s*.psd', RUN_ID));
                delete(sprintf('../tmp/*%s*.pin', RUN_ID));
                delete(sprintf('../tmp/*%s*.phr', RUN_ID));
            case 'nucl'
                delete(sprintf('../tmp/*%s*.nsq', RUN_ID));
                delete(sprintf('../tmp/*%s*.nsi', RUN_ID));
                delete(sprintf('../tmp/*%s*.nsd', RUN_ID));
                delete(sprintf('../tmp/*%s*.nin', RUN_ID));
                delete(sprintf('../tmp/*%s*.nhr', RUN_ID));
        end
        
    case {'diamond --sensitive', 'diamond --more-sensitive', 'diamond (default)'} % v310
        delete(sprintf('../tmp/*%s*.dmnd', RUN_ID));
end

if count>0 && val_N_THREADS>1
    if ~isempty(poolobj)
        delete(poolobj)
    end
    %     matlabpool close
end
fclose all;

fprintf('\tMCRL COMPUTATION IS COMPLETED.\n')

if count>0 && IN.PRECOMPUTE_TRACK
    cluster_nr = OUTFILE{7};
    relatedgenes_nr_HASH  = parse_relatedGenes(cluster_nr);
    reported_ref_genes    = keys(relatedgenes_nr_HASH);
    cluster_iti1 = OUTFILE{4};
    [relatedgenes_HASH_ITI1,  TOT_relatedgenes_HASH_EVAL_ITI1, Delegate_Eval_HASH]   = parse_relatedGenes(cluster_iti1);
    signature_filt = OUTFILE{3};
    signature_HASH0 = parse_all_signatures_from_AllGenesFilt(signature_filt);
    
    %-----------------------------------------------------------------------------------------------------------------------------------------------
    % Calculate tracks
    fprintf('\nCalculating all tracks:\n');
    MEGA_TRACK = calc_MCRL_tracks(signature_HASH0, relatedgenes_HASH_ITI1);
    
    Table_nr = OUTFILE{8};
    [FILEPATH,NAME,EXT] = fileparts(Table_nr);
    i=find(NAME=='_');
    MAT_file_tracks =[FILEPATH filesep NAME(1:i) 'tracks.mat'];
    
    fprintf('Saving tacks to %s\n', MAT_file_tracks);
    save(MAT_file_tracks,'MEGA_TRACK','relatedgenes_nr_HASH','reported_ref_genes','relatedgenes_HASH_ITI1','TOT_relatedgenes_HASH_EVAL_ITI1','Delegate_Eval_HASH','signature_HASH0');
end

if ~COMMAND_LINE
    fprintf('\tRETURNING USER COMMAND TO GUI.\n')
end
