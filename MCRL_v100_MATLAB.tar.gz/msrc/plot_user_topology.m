function [h, reported_gene_node, cluster_vec, f]=plot_user_topology(TOPOLOGY_GRAPH, EDGE_uniq, user_reference_gene_array, signature_HASH0, new_LUT, relatedgenes_nr_HASH, PLOT_NODE_LABLES, MAX_GENES_PER_NETWORK_FOR_LABLE)
% <--plot_network.m

f = figure('visible','off');
drawnow
G=graph(EDGE_uniq(:,1).',EDGE_uniq(:,2).');

G = rmedge(G, 1:numnodes(G), 1:numnodes(G));


if TOPOLOGY_GRAPH
    h=plot(G,'Layout','force');
else
    h=plot(G,'k','Layout','force');
end

% reported_gene_vec = [];
clear SigSize_vec
for gene_j=1:length(user_reference_gene_array)
    RefSeq = user_reference_gene_array{gene_j};
    SigSize = get_hash(signature_HASH0, RefSeq);
    SigSize_vec(gene_j) = length(SigSize);
end
SigSize_vec = log(SigSize_vec)+1;
SigSize_vec = SigSize_vec/max(SigSize_vec)*12;

reported_gene_node_vec = [];
RefSeq_array = {};
for gene_j=1:length(user_reference_gene_array)
    RefSeq = user_reference_gene_array{gene_j};
    reported_gene_node = new_LUT(RefSeq);
    reported_gene_node_vec = [reported_gene_node_vec reported_gene_node];
    RefSeq_plot = fix_label(RefSeq);
    
    RefSeq_array = [RefSeq_array RefSeq_plot];
    
    cluster_array = get_hash(relatedgenes_nr_HASH, RefSeq);
    
    if ~isempty(cluster_array)
        clear cluster_vec
        for j=1:length(cluster_array)
            cluster_vec(j) = new_LUT(cluster_array{j});
        end
        % Now highlight edges of reference gene clusters
        if TOPOLOGY_GRAPH
            highlight(h,reported_gene_node,cluster_vec,'EdgeColor','k')
            highlight(h,reported_gene_node,cluster_vec,'NodeColor','k')
        end
    end
    
    if TOPOLOGY_GRAPH
        title('Networks','fontsize',14);
        highlight(h, reported_gene_node, 'NodeColor','r');
    else
        title('Networks as E value heat maps','fontsize',14);
    end
    highlight(h, reported_gene_node, 'MarkerSize', SigSize_vec(gene_j));
    
end
all_ref_genes = keys(new_LUT);

all_nodes_vec = [];
for i=1:length(all_ref_genes)
    all_nodes_vec = [all_nodes_vec new_LUT(all_ref_genes{i})];
    empty_lables{i} = '';
end
labelnode(h, all_nodes_vec, empty_lables)

if PLOT_NODE_LABLES
    PLOT_ONLY_EPICENTER = MAX_GENES_PER_NETWORK_FOR_LABLE==-1;
    PLOT_ALL_LABLES     = MAX_GENES_PER_NETWORK_FOR_LABLE==inf;
    if ~PLOT_ALL_LABLES && (PLOT_ONLY_EPICENTER || length(user_reference_gene_array)>1 || length(user_reference_gene_array)==1 && length(all_ref_genes) > MAX_GENES_PER_NETWORK_FOR_LABLE)
        labelnode(h,reported_gene_node_vec, RefSeq_array)
    else
        % When only one network is plotted plot lables for all genes in network
        ref4plot_array = {};
        for i=1:length(all_ref_genes)
            
            % Fix lables before plotting
            RefSeq_plot = fix_label(all_ref_genes{i});
            ref4plot_array = [ref4plot_array, RefSeq_plot];
        end
        labelnode(h, all_nodes_vec, ref4plot_array)
    end
end
drawnow