function MolType = AutoDetectMolType(val_FASTA_METAGENOME_PATHFILE, COMMAND_LINE)
% <-- main_gui2.m
if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

record = 1;

% Get the first record
try
    F = fastaread(val_FASTA_METAGENOME_PATHFILE,'Blockread',record);
    Seq = F.Sequence;
    TotNumChars = length(Seq);
catch
    if ~COMMAND_LINE
        warndlg(sprintf('Cannot read %s',val_FASTA_METAGENOME_PATHFILE))
    else
        error('Cannot read %s',val_FASTA_METAGENOME_PATHFILE);
    end
    keyboard
end

% Get more records until one obtains at least 100 characters
while  TotNumChars<100
    record = record + 1;
    try
        F = fastaread(val_FASTA_METAGENOME_PATHFILE,'Blockread',record);
    catch
        if ~COMMAND_LINE
            errordlg('Cannot read fasta file %s',val_FASTA_METAGENOME_PATHFILE);
        else
            error('Cannot read fasta file %s',val_FASTA_METAGENOME_PATHFILE);
        end
        keyboard
    end
    Seq = [Seq, F.Sequence];
    TotNumChars = length(Seq);
end

Seq = upper(Seq);

% Is it nucl? (A,C,T,G + all degenerate)
N_nuc = sum(Seq=='A')+sum(Seq=='B')+sum(Seq=='C')+sum(Seq=='D')+sum(Seq=='G')+sum(Seq=='H')+sum(Seq=='K')+sum(Seq=='M')+sum(Seq=='N')+sum(Seq=='R')+sum(Seq=='S')+sum(Seq=='T')+sum(Seq=='V')+sum(Seq=='W')+sum(Seq=='Y');
if N_nuc==length(Seq)
    MolType = 'nucl';
    return
end

% Is it prot? (20 amino acids + 21st + 22nd + four ambiguous aa)
N_aa = sum(Seq=='A')+sum(Seq=='C')+sum(Seq=='D')+sum(Seq=='E')+sum(Seq=='F')+sum(Seq=='G')+sum(Seq=='H')+sum(Seq=='I')+sum(Seq=='K')+sum(Seq=='L')+sum(Seq=='M')+sum(Seq=='N')+sum(Seq=='P')+sum(Seq=='Q')+sum(Seq=='R')+sum(Seq=='S')+sum(Seq=='T')+sum(Seq=='V')+sum(Seq=='W')+sum(Seq=='Y')+sum(Seq=='U')+sum(Seq=='O')+sum(Seq=='B')+sum(Seq=='Z')+sum(Seq=='J')+sum(Seq=='X');

% Is it prot?
if N_aa==length(Seq)
    MolType = 'prot';
    return
end

MolType = 'unknown';



