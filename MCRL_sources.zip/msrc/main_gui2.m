function varargout = main_gui2(varargin)
% MAIN_GUI2 M-file for main_gui2.fig
%      MAIN_GUI2, by itself, creates a new MAIN_GUI2 or raises the existing
%      singleton*.
%
%      H = MAIN_GUI2 returns the handle to a new MAIN_GUI2 or the handle to
%      the existing singleton*.
%
%      MAIN_GUI2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_GUI2.M with the given input arguments.
%
%      MAIN_GUI2('Property','Value',...) creates a new MAIN_GUI2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_gui2_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_gui2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES


% Edit the above text to modify the response to help main_gui2

% Last Modified by GUIDE v2.5 02-Oct-2019 17:57:19

% Begin initialization code - DO NOT EDIT

if nargin==1
    % Command line execution
    RUN_BLAST_METAMINER_Callback(varargin);
    return
else
    gui_Singleton = 1;
    gui_State = struct('gui_Name',       mfilename, ...
        'gui_Singleton',  gui_Singleton, ...
        'gui_OpeningFcn', @main_gui2_OpeningFcn, ...
        'gui_OutputFcn',  @main_gui2_OutputFcn, ...
        'gui_LayoutFcn',  [] , ...
        'gui_Callback',   []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
    % End initialization code - DO NOT EDIT
end

% --- Executes just before main_gui2 is made visible.
function main_gui2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main_gui2 (see VARARGIN)

% Choose default command line output for main_gui2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main_gui2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% movegui(gcf,'center')
movegui(gcf,'northwest')
% keyboard
% screensize = get( groot, 'Screensize' );
% h = round(screensize(3)/2);
% v = round(screensize(4)/2);
% movegui(gcf,[h,v])


% --- Outputs from this function are returned to the command line.
function varargout = main_gui2_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in FASTA_REFSEQ_FILE_BROWSE.
function FASTA_REFSEQ_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(sprintf('..%sRefSeq_database',filesep));
[file, path] = uigetfile('*.faa');
cd(sprintf('..%sbin',filesep));

if file(1)~=0
    handles.val_FASTA_REFSEQ_PATHFILE = [path file];
    FASTA_REFSEQ_FILE_Callback(handles.FASTA_REFSEQ_FILE, [], handles)
end
% --- Executes on button press in FASTA_METAGENOME_FILE_BROWSE.
function FASTA_METAGENOME_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_METAGENOME_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(sprintf('..%sdata',filesep));
[file, path] = uigetfile('*.*');
cd(sprintf('..%sbin',filesep));

if file(1)~=0
    handles.val_FASTA_METAGENOME_FILE =  file;
    handles.val_FASTA_METAGENOME_PATH =  path;
    FASTA_METAGENOME_FILE_Callback(handles.FASTA_METAGENOME_FILE, [], handles)
end

% --- Executes on button press in GENPEP_REFSEQ_FILE_BROWSE.
function GENPEP_REFSEQ_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to GENPEP_REFSEQ_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(sprintf('..%sRefSeq_database',filesep));
[file, path] = uigetfile('*.gpff');
cd(sprintf('..%sbin',filesep));

if file(1)~=0
    handles.val_GENPEP_REFSEQ_FILE = [path file];
    GENPEP_REFSEQ_FILE_Callback(handles.GENPEP_REFSEQ_FILE, [], handles)
end

function E_VALUE_METAMINER_Callback(hObject, eventdata, handles)
% hObject    handle to E_VALUE_METAMINER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% good = legal_evalue(str2num(get(hObject,'String')));

% if ~good
%     set(hObject,'String','');
% end
% Hints: get(hObject,'String') returns contents of E_VALUE_METAMINER as text
%        str2double(get(hObject,'String')) returns contents of E_VALUE_METAMINER as a double


% --- Executes during object creation, after setting all properties.
function E_VALUE_METAMINER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_VALUE_METAMINER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN = GetParams();
set(hObject,'string',sprintf('%g',IN.E_TH));

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function GENPEP_REFSEQ_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to GENPEP_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_GENPEP_REFSEQ_FILE')
    set(hObject,'String',handles.val_GENPEP_REFSEQ_FILE);
end
% Hints: get(hObject,'String') returns contents of GENPEP_REFSEQ_FILE as text
%        str2double(get(hObject,'String')) returns contents of GENPEP_REFSEQ_FILE as a double


% --- Executes during object creation, after setting all properties.
function GENPEP_REFSEQ_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to GENPEP_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN = GetParams();
set(hObject,'string',IN.GENPEP_REFSEQ_FILE);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function E_VALUE_BLAST_Callback(hObject, eventdata, handles)
% hObject    handle to E_VALUE_BLAST (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of E_VALUE_BLAST as text
%        str2double(get(hObject,'String')) returns contents of E_VALUE_BLAST as a double
% good = legal_evalue(str2num(get(hObject,'String')));
% if ~good
%     set(hObject,'String','');
% end
% --- Executes during object creation, after setting all properties.
function E_VALUE_BLAST_CreateFcn(hObject, eventdata, handles)
% hObject    handle to E_VALUE_BLAST (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
[~, ~, BLAST] = GetParams();
set(hObject,'string',sprintf('%g',BLAST.E_TH));


% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function FASTA_REFSEQ_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_FASTA_REFSEQ_PATHFILE')
    set(hObject,'string',handles.val_FASTA_REFSEQ_PATHFILE);
end
% Hints: get(hObject,'String') returns contents of FASTA_REFSEQ_FILE as text
%        str2double(get(hObject,'String')) returns contents of FASTA_REFSEQ_FILE as a double


% --- Executes during object creation, after setting all properties.
function FASTA_REFSEQ_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN  = GetParams();
set(hObject,'string',IN.FASTA_REFSEQ_FILE);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FASTA_METAGENOME_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to FASTA_METAGENOME_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_FASTA_METAGENOME_PATH') && isfield(handles,'val_FASTA_METAGENOME_FILE')
    set(hObject,'String',[handles.val_FASTA_METAGENOME_PATH handles.val_FASTA_METAGENOME_FILE]);
end
% Hints: get(hObject,'String') returns contents of FASTA_METAGENOME_FILE as text
%        str2double(get(hObject,'String')) returns contents of FASTA_METAGENOME_FILE as a double


% --- Executes during object creation, after setting all properties.
function FASTA_METAGENOME_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FASTA_METAGENOME_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
[~, ~, BLAST] = GetParams();
set(hObject,'String',BLAST.FASTA_METAGENOME_FILE);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BLAST_OUTPUT_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isfield(handles,'val_BLAST_OUTPUT_PATHFILE')
    set(hObject,'String',handles.val_BLAST_OUTPUT_PATHFILE);
end
% Hints: get(hObject,'String') returns contents of BLAST_OUTPUT_FILE as text
%        str2double(get(hObject,'String')) returns contents of BLAST_OUTPUT_FILE as a double


% --- Executes during object creation, after setting all properties.
function BLAST_OUTPUT_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

IN = GetParams();
% IN.BLAST_file_name does not contain the RUN_ID, so GetPathAndName() is
% run in 'blast_GUI' mode w/o a RUN_ID to return the name (w/o RUN_ID)
% provided by the user.
default_filename_no_path = GetPathAndName(IN.BLAST_file_name,'blast_GUI');
set(hObject,'String',default_filename_no_path);

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function METAMINER_OUTPUT_FILE_Callback(hObject, eventdata, handles)
% hObject    handle to METAMINER_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%set(hObject,'String',handles.METAMINER_OUTPUT_FILE)
x = get(hObject,'String');
badfilename = CheckIfFilenameIsIllegal(x, 'output');
if badfilename
    % invalid entry
    set(hObject,'String','');
    return
end
% Hints: get(hObject,'String') returns contents of METAMINER_OUTPUT_FILE as text
%        str2double(get(hObject,'String')) returns contents of METAMINER_OUTPUT_FILE as a double


% --- Executes during object creation, after setting all properties.
function METAMINER_OUTPUT_FILE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to METAMINER_OUTPUT_FILE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN = GetParams();
set(hObject,'String', IN.OUTPUT_NAME);


% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in RUN_BLAST_METAMINER.
function RUN_BLAST_METAMINER_Callback(hObject, eventdata, handles)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EXECUTE BLAST AND MCRL
%
%
% hObject    handle to RUN_BLAST_METAMINER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Initial values for output


% (1) RefSeq FASTA file is copied to tmp with a RUN_ID (and deleted in the end)
%   - If parallel processing is on then later on RefSeq FASTA file with RUN_ID is split to smaller files  (and deleted in the end)
%   - Genpept file is not copied locally
% (2) Metagenome FASTA file is copied to tmp file with a RUN_ID
%   - If format of FASTA records needs to be fixed, the temp metagenome fasta file is erased and replaced with a new one (and deleted in the end)
% (3) BLAST table is assinged a RUN_ID (all BLAST tmp files will have a RUN_ID and deleted in the end)
% (4) Temperary files created by find_related_genes.m also has a RUN_ID (and deleted in the end)
% (5) Debug mat file is saved with a RUN_ID




% check to see if blast is installed

start            = [];
finish           = [];
dt               = [];
blastall_command = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get MetMiner parameters
% works only if Parallel Computing Toolbox is on
MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer)
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end

COMMAND_LINE = 0;
if iscell(hObject) && length(hObject)==1
    COMMAND_LINE = 1;
    command.in          = hObject{1};
end


% Aug 20, 2016: val_N_THREADS=1 if parallel toolbox is not installed
if ParallelToolBoxFound
    if ~COMMAND_LINE
        val_N_THREADS                 = get(handles.N_THREADS                            ,'Value');   % pull down menu - all values are legal
    else
        val_N_THREADS = command.in.val_N_THREADS; 
        if ~isdeployed
            Max_threads = maxNumCompThreads('automatic');
        else
            c_local = parcluster('local');
            Max_threads = c_local.NumWorkers;
        end
        if val_N_THREADS > Max_threads
            error('Maximum number of threads allowed = %d', Max_threads);
        end
        if val_N_THREADS<=0
            error('Illegal number of threads');
        end
    end
    
    % START Aug 5, 2019
    % Shut down parallel processing if open
    poolobj = gcp('nocreate');
    if ~isempty(poolobj)
        delete(poolobj);
    end
    % END
else
    val_N_THREADS = 1;
end


% tmp file ID
if ~COMMAND_LINE
    % In GUI mode set random number generator here
    try
        % Newer random seeding command
        rng('shuffle', generator)
    catch
        rand('seed',sum(100*clock));
    end
    RUN_ID = get_random_ID();
else
    % Random number generator was set in SetParams.m
    RUN_ID = command.in.RUN_ID; % for par_command_line_MCRL_EXE.m script this ID must be generated externally
end
   
if COMMAND_LINE && command.in.BLAST_SETUP==1 || ~COMMAND_LINE && (get(handles.BLAST_ON,'Value') == get(handles.BLAST_ON,'Max'))
    blast_action = 'blast';
else
    blast_action = 'blast_rerun';
end
    
if COMMAND_LINE && command.in.PRECOMPUTE_TRACK==1 || ~COMMAND_LINE && (get(handles.TRACK,'Value') == get(handles.BLAST_ON,'Max'))
    PRECOMPUTE_TRACK = 1;
else
    PRECOMPUTE_TRACK = 0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% v3.0.8
if strcmp(blast_action,'blast_rerun')
    % Don't allow to proceed uf user did not provide a valid BLAST table
    % with a MAT file as well
    BLAST_TABLE_IS_NOT_VALID=0;
    BLAST_TABLE = strtrim(get(handles.BLAST_OUTPUT_FILE ,'String'));
    [pth, name, ext] = fileparts(BLAST_TABLE);
    BLAST_MAT_TABLE = [pth filesep name '.mat'];
    % BLAST table and BLAST mat file must exist to enter this mode!
    if ~exist(BLAST_TABLE,'file') ||  ~exist(BLAST_MAT_TABLE,'file')
        BLAST_TABLE_IS_NOT_VALID=1;
    end

    if BLAST_TABLE_IS_NOT_VALID
        if ~COMMAND_LINE
            h=errordlg('BLAST table file is not valid');
            uiwait(h);
        else
            error('BLAST table file is not valid');
        end
        return;
    end
    
    % In case user pasted BLAST_Table path (otherwise this is updated when
    % pressing the browse button)
    if isdeployed
        if isempty(pth)
            load(['..' filesep 'output' filesep BLAST_MAT_TABLE], 'MAT');
        else
            load(BLAST_MAT_TABLE, 'MAT');
        end
    else
        load(BLAST_MAT_TABLE, 'MAT');
    end
    
    set(handles.FASTA_METAGENOME_FILE,  'String', MAT.FASTA_METAGENOME_FILE); % once starting the execution the tempearay metagenome file without +/- will be created if needed
    set(handles.GENPEP_REFSEQ_FILE,     'String', MAT.GENPEP_REFSEQ_FILE);
    set(handles.FASTA_REFSEQ_FILE,      'String', MAT.FASTA_REFSEQ_FILE);
    switch MAT.MolType
        case 'prot'
            set(handles.METAG_DATA_TYPE                      ,'Value', 1)
        case 'nucl'
            set(handles.METAG_DATA_TYPE                      ,'Value', 2)
    end
    drawnow;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


if ~COMMAND_LINE
    val_E_TH_METAMINER              = str2num(get(handles.E_VALUE_METAMINER            ,'String')); % value checked to be legal on callback
    val_E_TH_BLAST_TMP              = str2num(get(handles.E_VALUE_BLAST                ,'String')); % value checked to be legal on callback
    val_GENPEPT_REFSEQ_PATHFILE     = strtrim(get(handles.GENPEP_REFSEQ_FILE           ,'String')); % value checked below
    val_FASTA_REFSEQ_PATHFILE_tmp   = strtrim(get(handles.FASTA_REFSEQ_FILE            ,'String')); % value checked below
    val_METMINER_OUTNAME            = strtrim(get(handles.METAMINER_OUTPUT_FILE        ,'String')); % value checked below
    % In GUI mode handles.BLAST_OUTPUT_FILE does not comtain the RUN_ID, therefore this is added by GetPathAndName()
    [val_BLAST_OUTPUT_FILE, val_BLAST_OUTPUT_PATHFILE]    = GetPathAndName(strtrim(get(handles.BLAST_OUTPUT_FILE ,'String')),blast_action, COMMAND_LINE, RUN_ID); % checked below
    val_METAG_DATA_TYPE             = get(handles.METAG_DATA_TYPE                      ,'Value'); % value checked below
    val_SIGNATURE_MIN_MAX           = get(handles.SIGNATURE_MIN_MAX                    ,'Value'); % value checked below
    valOverlapThreshold             = str2num(get(handles.valOverlapThreshold          ,'String')); % value checked to be legal on callback
    if val_METAG_DATA_TYPE==1
        MolTypeFromGUI = 'prot';
    else % val_METAG_DATA_TYPE=2
        MolTypeFromGUI = 'nucl';
    end
    
    if val_SIGNATURE_MIN_MAX==1
        SIGNATURE_MIN_MAX_STR = 'inclusive';
    else
        SIGNATURE_MIN_MAX_STR = 'stringent';
    end

else
    val_E_TH_METAMINER            = command.in.E_TH;
    val_E_TH_BLAST_TMP            = command.in.E_TH_BLAST;
    val_GENPEPT_REFSEQ_PATHFILE   = command.in.GENPEP_REFSEQ_FILE;
    val_FASTA_REFSEQ_PATHFILE_tmp = command.in.FASTA_REFSEQ_FILE;
    val_METMINER_OUTNAME          = command.in.OUTPUT_NAME;
    % In command line mode command.in.BLAST_file_name does not comtain the RUN_ID, therefore this is added by GetPathAndName()
    
    [val_BLAST_OUTPUT_FILE, val_BLAST_OUTPUT_PATHFILE]    = GetPathAndName(strtrim(command.in.BLAST_file_name),blast_action, COMMAND_LINE, RUN_ID);
    MolTypeFromGUI                = command.in.MolType;
    if ~strcmp(MolTypeFromGUI,'prot') && ~strcmp(MolTypeFromGUI,'nucl')
        error('valid values for MolType are ''prot'' and ''nucl''');
    end
    
    SIGNATURE_MIN_MAX_STR         = command.in.SIGNATURE_MIN_MAX_STR;
    if ~strcmp(SIGNATURE_MIN_MAX_STR,'inclusive') && ~strcmp(SIGNATURE_MIN_MAX_STR,'stringent')
        error('valid values for SIGNATURE_MIN_MAX_STR are ''inclusive'' and ''stringent''');
    end
    valOverlapThreshold           = command.in.MIN_IDNT_PERC_OF_CONTIG_LISTS;
end

% make sure all files/directories in GUI for MetaMiner are valid files/directories and that all needed parameters were entered
% GenPept RefSeq (if it was defined it needs to be valid)
if ~FileOrPathExists(val_GENPEPT_REFSEQ_PATHFILE, COMMAND_LINE), return; end

if CheckIfFilenameIsIllegal(val_METMINER_OUTNAME, 'output', COMMAND_LINE)==1, return; end

if ~legal_evalue(val_E_TH_METAMINER,   COMMAND_LINE),   return; end
if ~legal_evalue(val_E_TH_BLAST_TMP,   COMMAND_LINE),   return; end
if ~legal_percent(valOverlapThreshold, COMMAND_LINE),   return; end


if  strcmp(blast_action,'blast_rerun')
    % BLAST OFF (file+path)- check that file exists
    if ~FileOrPathExists(val_BLAST_OUTPUT_PATHFILE, COMMAND_LINE), return; end
    
else
    % BLAST ON (file name only) - check file name is a legal blast file name
    if CheckIfFilenameIsIllegal(val_BLAST_OUTPUT_FILE,'blast',COMMAND_LINE)==1, return; end
    % val_BLAST_OUTPUT_PATHFILE = ['..' filesep 'output' filesep val_BLAST_OUTPUT_FILE];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get BLAST PARAMETERS (if blast is checked on)
% check if Checkbox is on or off
val_FASTA_METAGENOME_PATHFILE_to_save= '';

if  strcmp(blast_action,'blast')
    % Checkbox on - run BLAST
    % Check if ncbi.ini is found in c:\windows (this is from the C version of blast and will interfere with the program)
    move_ncbi_ini = 0;
    if ispc
        if exist('c:\windows\ncbi.ini','file')>0
            move_ncbi_ini = 1;
            movefile('c:\windows\ncbi.ini','c:\windows\ncbi.ini~')
        end
    end
    % Get all params from the GUI
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Make sure all other parameters from GUI are valid
    % First check that files exist before potentially copying files
    if  ~COMMAND_LINE
        [~, val_FASTA_METAGENOME_PATHFILE_TMP, success] = GetPathAndName(strtrim(get(handles.FASTA_METAGENOME_FILE,'String')),'CHECK_FILE_EXISTS', COMMAND_LINE); % checked
        
    else
        [~, val_FASTA_METAGENOME_PATHFILE_TMP, success] = GetPathAndName(strtrim(command.in.FASTA_METAGENOME_FILE),           'CHECK_FILE_EXISTS', COMMAND_LINE); % checked
    end
    if ~success, return; end
 
    % Check Mol type before potentially copying files
    if  ~COMMAND_LINE
        [MolTypeFromGUI, handles, success] = check_MolTypeFromGUI_vs_auto_Detet(MolTypeFromGUI, val_FASTA_METAGENOME_PATHFILE_TMP, COMMAND_LINE, handles);
      if ~success, return; end
    else
        % If wrong molecular type program will abort
        MolTypeFromGUI = check_MolTypeFromGUI_vs_auto_Detet(MolTypeFromGUI, val_FASTA_METAGENOME_PATHFILE_TMP, COMMAND_LINE);
    end
    
    % Check that BLAST folder exists before potentially copying files
    if isdeployed
        load(['..' filesep 'msrc' filesep 'blast_bin_folder.mat'],'val_BLAST_BIN_FOLDER');
    else
        load blast_bin_folder %Gets val_BLAST_BIN_FOLDER
    end
    val_BLAST_BIN_FOLDER         = [val_BLAST_BIN_FOLDER filesep];
    
    % path of bin folder of blastall/formatdb executibles
    if ~found_blast_sourcecode(val_BLAST_BIN_FOLDER)
        if ~COMMAND_LINE
            h=errordlg('Could not locate blast source code in the specified folder');
            uiwait(h);
        else
            error('Could not locate blast source code in the specified folder');
        end
        return;
    end
    
    if  ~COMMAND_LINE
        val_E_TH_BLAST  = str2num(get(handles.E_VALUE_BLAST        ,'String')); % checked below
    else
        val_E_TH_BLAST  = command.in.E_TH_BLAST; % checked below
    end
    
    if ~legal_evalue(val_E_TH_BLAST, COMMAND_LINE) ,return; end
    
    if  ~COMMAND_LINE
        [~,     ~, success]     = GetPathAndName(strtrim(get(handles.FASTA_REFSEQ_FILE,'String')),   'CHECK_FILE_EXISTS', COMMAND_LINE); % checked
    else
        [~,     ~, success]     = GetPathAndName(strtrim(command.in.FASTA_REFSEQ_FILE),              'CHECK_FILE_EXISTS', COMMAND_LINE); % checked
    end
    if ~success, return; end
      %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
    % Make all filenames exist,remove spaces in filename if exist and copy files to local directory with tmp RUN_ID to allow running the same
    % metagenome and refseq files from the same MCRL instalation folder
    
    % Copy metagenome file to the tmp directory with the RUN_ID (if needed replace +/- with _)
    if  ~COMMAND_LINE
        [val_FASTA_METAGENOME_FILE, val_FASTA_METAGENOME_PATHFILE, success] = GetPathAndName(strtrim(get(handles.FASTA_METAGENOME_FILE,'String')),'metagenome', COMMAND_LINE, RUN_ID); % checked
        val_FASTA_METAGENOME_PATHFILE_to_save = strtrim(get(handles.FASTA_METAGENOME_FILE,'String'));

    else
        [val_FASTA_METAGENOME_FILE, val_FASTA_METAGENOME_PATHFILE, success] = GetPathAndName(strtrim(command.in.FASTA_METAGENOME_FILE),'metagenome',            COMMAND_LINE, RUN_ID); % checked
        val_FASTA_METAGENOME_PATHFILE_to_save = strtrim(command.in.FASTA_METAGENOME_FILE);
    end
    if ~success, return; end
    
    % Copy RefSeq to the tmp directory with the RUN_ID
    if  ~COMMAND_LINE
        [val_FASTA_REFSEQ_FILE,     val_FASTA_REFSEQ_PATHFILE, success]     = GetPathAndName(strtrim(get(handles.FASTA_REFSEQ_FILE,'String')),   'refseq', COMMAND_LINE, RUN_ID); % checked
    else
        [val_FASTA_REFSEQ_FILE,     val_FASTA_REFSEQ_PATHFILE, success]     = GetPathAndName(strtrim(command.in.FASTA_REFSEQ_FILE),'refseq',               COMMAND_LINE, RUN_ID); % checked
    end
    if ~success, return; end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Passed all the checks - continue
    if  strcmp(blast_action,'blast')
        % update GUI with new blast table name (in case file is rerun later)
        if ~COMMAND_LINE, set(handles.BLAST_OUTPUT_FILE ,'String', val_BLAST_OUTPUT_FILE); end
    end
    % time and date BLAST started
    start.blast_date = date;
    start.blast_time = clock;
    tic
    
    PARALLEL = val_N_THREADS>1;
    if isunix
        QUOTE = '''';
    else
        QUOTE = '"';
    end
    
    % Format the metagenome FASTA file in local (data) directory
    fprintf('*** Formatting %s ***\n\n',val_FASTA_METAGENOME_FILE);
    %format_command = sprintf('%sformatdb -i ''%s'' -p T'    ,val_BLAST_BIN_FOLDER,[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE]);
    %format_command = sprintf('legacy_blast.pl formatdb -i ''%s'' -p T'    ,[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE]);
    
    switch MolTypeFromGUI
        case 'prot'
            fprintf('Processing %s as a PROTEIN file\n\n',val_FASTA_METAGENOME_PATHFILE);
            format_command = [ QUOTE val_BLAST_BIN_FOLDER  'makeblastdb' QUOTE ' -dbtype prot -parse_seqids -in ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE];
        case 'nucl'
            fprintf('Processing %s as a NUCLEOTIDE file\n\n',val_FASTA_METAGENOME_PATHFILE);
            format_command = [ QUOTE val_BLAST_BIN_FOLDER  'makeblastdb' QUOTE ' -dbtype nucl -parse_seqids -in ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE];
    end
    
    fprintf('>%s\n',format_command);
    
    if system(format_command)~=0
        if ~COMMAND_LINE
            h=errordlg('problem executing makeblastdb');
            uiwait(h);
        else
            error('problem executing makeblastdb');
        end
        return
    end
    
    % PARALLEL BLASTALL

    if PARALLEL
        % Split input FASTA file into number of threads based on input number by user
        fprintf('\nParallel processing is ON\n')
        fprintf('splitting RefSeq FASTA file into %d files...\n',val_N_THREADS);
        val_FASTA_REFSEQ_PATHFILE_NEW = SplitFile(val_FASTA_REFSEQ_PATHFILE, val_N_THREADS);
    else
        fprintf('Parallel processing is OFF\n')
    end
    
    % print message what is going to happen next
    fprintf('\n*** Blasting %s against %s (number of threads used: %d)***\n\n',val_FASTA_REFSEQ_FILE, val_FASTA_METAGENOME_FILE,val_N_THREADS);
    
    % run blastp
    % c code command is: /..../blast-###/bin/blastall �i <RefSeq_FASTA> �p blastp �d <metagenome_FASTA> �o <outputfile> �m 8 �e <E_value_thresh>
    
    % Manually confirmed that blastp is gapped blast
    if PARALLEL
        % write parallel blast commands
        for blst_thds = 1:val_N_THREADS
            % tmp out file names
            val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds}= sprintf('%s_%d',val_BLAST_OUTPUT_PATHFILE, blst_thds); % RUN_ID is already coded in val_BLAST_OUTPUT_PATHFILE
            
            switch MolTypeFromGUI
                
                case 'prot'
                    %blastall_command{blst_thds} = sprintf('%sblastall -i ''%s'' -p blastp -d ''%s'' -o ''%s'' -m 8 -e %g',val_BLAST_BIN_FOLDER,val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds},[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE],val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds},val_E_TH_BLAST );
                    %blastall_command{blst_thds} = sprintf('legacy_blast.pl
                    %blastall -i ''%s'' -p blastp -d ''%s'' -o ''%s'' -m 8 -e %g',val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds},[val_BLAST_DB_FOLDER val_FASTA_METAGENOME_FILE],val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds},val_E_TH_BLAST );
                    blastall_command{blst_thds} = [QUOTE val_BLAST_BIN_FOLDER 'blastp' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds} QUOTE ' -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds} QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
               
                case 'nucl'
                    % The '-seg no' options means no filtering on the query = RefSeq genes. An example of filtering is low complexity filtering - filtering regions of
                    % low complexity that may lead to FA. For blastp the default is 'no'. For tblastn the default is with filtering while for blastp the default is no filtering.
                    % Although '-seg no' may yield false alarms, the E value for a genuine hit is
                    % closer to reality. Since we are filtering results by E value, it is important for the E value to reflect the true E value.
                    
                    blastall_command{blst_thds} = [QUOTE val_BLAST_BIN_FOLDER 'tblastn' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE_NEW{blst_thds} QUOTE ' -seg no -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE_NEW{blst_thds} QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
            end
            fprintf('>%s\n',blastall_command{blst_thds})
        end
        
        % open 'val_N_THREADS' matlab workers
        %         eval(sprintf('matlabpool open local %d',val_N_THREADS));
        poolobj = parpool(val_N_THREADS);
        
        % run blastall
        parfor blst_thds = 1:val_N_THREADS
            stat(blst_thds) = system(blastall_command{blst_thds});
        end
        
        %         matlabpool close
        delete(poolobj)
        
        if max(stat)~=0
            if ~COMMAND_LINE
                h=errordlg('problem executing blast (with parallel on)');
                uiwait(h);
            else
                error('problem executing blast (with parallel on)')
            end
            return
        end
        
        % combine results files together
        CombineFiles(val_BLAST_OUTPUT_PATHFILE_NEW,val_BLAST_OUTPUT_PATHFILE);
        
    else % NOT PARALLEL
        switch MolTypeFromGUI
            case 'prot'
                %blastall_command{1} = [QUOTE val_BLAST_BIN_FOLDER
                %'tblastn' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE QUOTE ' -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST)];
                blastall_command{1} = [QUOTE val_BLAST_BIN_FOLDER 'blastp' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE QUOTE ' -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
            case 'nucl'
                blastall_command{1} = [QUOTE val_BLAST_BIN_FOLDER 'tblastn' QUOTE ' -query ' QUOTE val_FASTA_REFSEQ_PATHFILE QUOTE ' -seg no -db ' QUOTE val_FASTA_METAGENOME_PATHFILE QUOTE ' -out ' QUOTE val_BLAST_OUTPUT_PATHFILE QUOTE ' -outfmt 6 -evalue ' sprintf('%g',val_E_TH_BLAST) ' -num_descriptions 1000000'];
        end
        
        fprintf('>%s\n',blastall_command{1});
        %blastall_command{1}
        if system(blastall_command{1})~=0
            if ~COMMAND_LINE
                h=errordlg('problem executing blast (with parallel off)');
                uiwait(h);
            else
                error('problem executing blast (with parallel off)');
            end
            return
        end
    end
    
    % note time BLAST analysis finished to report in output file
    dt.blast = toc;
    finish.blast_date = date;
    finish.blast_time = clock;
    
    % delete tmp files we created
    if PARALLEL
        fprintf('\t--> deleting all temporary RefSeq file fragments\n')
        DeleteFiles(val_FASTA_REFSEQ_PATHFILE_NEW);
        DeleteFiles(val_BLAST_OUTPUT_PATHFILE_NEW);
    end
    
    % Also remove temporary complete (original) RefSeq file that was created in the tmp directory for this run
    fprintf('\t--> deleting temporary complete RefSeq file %s\n', val_FASTA_REFSEQ_PATHFILE)
    delete(val_FASTA_REFSEQ_PATHFILE);
    
    if move_ncbi_ini
        movefile('c:\windows\ncbi.ini~','c:\windows\ncbi.ini')
    end
else
    % April 7 2019
    % BLAST box checked off -> get only metagenome file name
    [~, val_FASTA_METAGENOME_PATHFILE, ~] = GetPathAndName(strtrim(get(handles.FASTA_METAGENOME_FILE,'String')),'metagenome',COMMAND_LINE, RUN_ID);
end

% run MetaMiner
% get MetaMiner parameters from GUI and GetParams

% Check if RefSeq file is GenPept format or FASTA format
fp = fopen(val_GENPEPT_REFSEQ_PATHFILE,'r');
line = [];
while isempty(line)
    line = strtrim(fgetl(fp));
end
fclose(fp);

if line(1)=='>'
    % a FASTA file is provided in the GENEPEP field
    IN.FASTA_REFSEQ_FILE = val_GENPEPT_REFSEQ_PATHFILE;
    IN.GENPEP_REFSEQ_FILE  = '';
else
    IN.FASTA_REFSEQ_FILE  = val_FASTA_REFSEQ_PATHFILE_tmp;
    IN.GENPEP_REFSEQ_FILE = val_GENPEPT_REFSEQ_PATHFILE;
end

cd(['..' filesep 'output'])
val_MetaMiner_output_FOLDER  = [pwd filesep];
cd(['..' filesep 'bin']);

[IN_DEFAULT, ~, ~, outfile_ext] = GetParams();

IN.DEBUG                         = IN_DEFAULT.DEBUG;
    
IN.BLAST_file_name               = val_BLAST_OUTPUT_PATHFILE;
IN.OUTPUT_NAME                   = val_METMINER_OUTNAME;
IN.E_TH                          = val_E_TH_METAMINER;
IN.E_TH_BLAST                    = val_E_TH_BLAST_TMP;
IN.MIN_IDNT_PERC_OF_CONTIG_LISTS = valOverlapThreshold; %IN_DEFAULT.MIN_IDNT_PERC_OF_CONTIG_LISTS;
IN.version                       = IN_DEFAULT.version;
IN.FASTA_METAGENOME_FILE         = val_FASTA_METAGENOME_PATHFILE;
IN.SIGNATURE_MIN_MAX_STR         = SIGNATURE_MIN_MAX_STR;
IN.MolType                       = MolTypeFromGUI;
IN.PRECOMPUTE_TRACK              = PRECOMPUTE_TRACK;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% v3.0.8
if  strcmp(blast_action,'blast') % Save only once when the first time BLAST is performed
    % Also save to mat file the name of metagenome and reference library used
    % to create the BLAST file (in case we want to rerun results from the
    % middle later on)
    [pth, name, ext] = fileparts(val_BLAST_OUTPUT_PATHFILE);
    val_BLAST_MAT_OUTPUT_PATHFILE = [pth filesep name '.mat'];
    MAT.FASTA_METAGENOME_FILE     = val_FASTA_METAGENOME_PATHFILE_to_save; % original metagenome name !
    MAT.FASTA_REFSEQ_FILE         = IN.FASTA_REFSEQ_FILE;
    MAT.GENPEP_REFSEQ_FILE        = IN.GENPEP_REFSEQ_FILE;
    MAT.MolType                   = IN.MolType;
    save(val_BLAST_MAT_OUTPUT_PATHFILE, 'MAT');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if COMMAND_LINE
    IN.PARALLEL_SESSIONS             = command.in.PARALLEL_SESSIONS;
else
    IN.PARALLEL_SESSIONS = 0;
end

% add output path to outfile names with .txt extention
tt = find(val_BLAST_OUTPUT_FILE=='.');
if ~isempty(tt)
    blast_outfile_no_ext = val_BLAST_OUTPUT_FILE(1:tt(1)-1);
else
    blast_outfile_no_ext = val_BLAST_OUTPUT_FILE;
end

for i=1:length(outfile_ext)
    if isempty(strtrim(IN.OUTPUT_NAME))
        OUTFILE{i} = [val_MetaMiner_output_FOLDER,  blast_outfile_no_ext, IN.OUTPUT_NAME, outfile_ext{i}, '.txt'];
    else
        OUTFILE{i} = [val_MetaMiner_output_FOLDER,  blast_outfile_no_ext, '_', IN.OUTPUT_NAME, outfile_ext{i}, '.txt'];
    end
end

% run MetaMiner
global PROG_NAME
fprintf('\n*** Running %s ***\n\n',PROG_NAME)
% load(['..' filesep 'msrc' filesep 'RefSeq_file_name_header.mat']);
% IN.FASTA_REFSEQ_FILE   = sprintf('%s.faa', RefSeq_file_name_header);
% IN.GENPEP_REFSEQ_FILE  = sprintf('%s.gpff', RefSeq_file_name_header);

set(handles.RUN_BLAST_METAMINER,'Enable','off');
MCRL_MAIN(IN, OUTFILE, start, finish, dt, blastall_command, val_N_THREADS, COMMAND_LINE, RUN_ID);
set(handles.RUN_BLAST_METAMINER,'Enable','on');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function FASTA_REFSEQ_FILE_BROWSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FASTA_REFSEQ_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes during object creation, after setting all properties.
function text16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
IN  = GetParams();
set(hObject,'String',IN.version,'HorizontalAlignment','left');



% --- Executes on button press in BLAST_OUTPUT_FILE_BROWSE.
function BLAST_OUTPUT_FILE_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cd(['..' filesep 'output']);
[file, path] = uigetfile('*.txt');
cd(['..' filesep 'bin']);

if file(1)~=0
    handles.val_BLAST_OUTPUT_PATHFILE = [path file];
    BLAST_OUTPUT_FILE_Callback(handles.BLAST_OUTPUT_FILE, [], handles)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % v3.0.8
    % Check if BLAST table exists including mat file, if so, correct these
    % fields (if they don't exist MCRL will not allow to execute the "RUN_MCRL" button)
    proposed_BLAST_TABLE_file = handles.val_BLAST_OUTPUT_PATHFILE;
    [pth, name, ext] = fileparts(proposed_BLAST_TABLE_file);
    BLAST_MAT_TABLE = [pth filesep name '.mat'];
    % BLAST table and BLAST mat file must exist to enter this mode!
    if exist(proposed_BLAST_TABLE_file,'file') && exist(BLAST_MAT_TABLE,'file')
        % Change metagenome and ref library fields to match BLAST table info
        if isdeployed
            if isempty(pth)
                load(['..' filesep 'output' filesep BLAST_MAT_TABLE], 'MAT');
            else
                load(BLAST_MAT_TABLE, 'MAT');
            end
        else
            load(BLAST_MAT_TABLE, 'MAT');
        end
        set(handles.FASTA_METAGENOME_FILE,  'String', MAT.FASTA_METAGENOME_FILE); % once starting the execution the tempearay metagenome file without +/- will be created if needed
        set(handles.GENPEP_REFSEQ_FILE,     'String', MAT.GENPEP_REFSEQ_FILE);
        set(handles.FASTA_REFSEQ_FILE,      'String', MAT.FASTA_REFSEQ_FILE);
        
        switch MAT.MolType
            case 'prot'
                set(handles.METAG_DATA_TYPE                      ,'Value', 1)
            case 'nucl'
                set(handles.METAG_DATA_TYPE                      ,'Value', 2)
        end
        
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end




% --- Executes on button press in BLAST_BIN_FOLDER_BROWSE.
function BLAST_BIN_FOLDER_BROWSE_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


val_BLAST_BIN_FOLDER = uigetdir(get(handles.BLAST_BIN_FOLDER,'String'));

if val_BLAST_BIN_FOLDER(1)~=0
    handles.val_BLAST_BIN_FOLDER = val_BLAST_BIN_FOLDER ;
    BLAST_BIN_FOLDER_Callback(handles.BLAST_BIN_FOLDER, [], handles)
    try
%         if isdeployed
            save(['..' filesep 'msrc' filesep 'blast_bin_folder.mat'], val_BLAST_BIN_FOLDER);
%         else
%             save blast_bin_folder val_BLAST_BIN_FOLDER
%         end
    catch
        warndlg('Problem writing default params to disk')
    end
end

function BLAST_BIN_FOLDER_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'val_BLAST_BIN_FOLDER')
    set(hObject,'String',handles.val_BLAST_BIN_FOLDER);
    % check if blast folder exists, if it does if blast is installed, and if not download it from ftp website
    
end

% Hints: get(hObject,'String') returns contents of BLAST_BIN_FOLDER as text
%        str2double(get(hObject,'String')) returns contents of BLAST_BIN_FOLDER as a double


% --- Executes during object creation, after setting all properties.
function BLAST_BIN_FOLDER_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if exist('blast_bin_folder.mat','file')>0
    if isdeployed
        load(['..' filesep 'msrc' filesep 'blast_bin_folder.mat'],'val_BLAST_BIN_FOLDER');
    else
        load blast_bin_folder.mat
    end
    bin_folder = val_BLAST_BIN_FOLDER;
else
    [~, ~, BLAST] = GetParams();
    bin_folder = BLAST.BLAST_BIN_FOLDER;
end
set(hObject,'String',bin_folder);



% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in BLAST_ON.
function BLAST_ON_Callback(hObject, eventdata, handles)
% hObject    handle to BLAST_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of BLAST_ON

% IN = GetParams();
% IN.BLAST_file_name does not contain the RUN_ID, so GetPathAndName() is
% run in 'blast_GUI' mode w/o a RUN_ID to return the name (w/o RUN_ID)
% provided by the user.
% [default_filename_no_path, default_filename_with_path] = GetPathAndName(IN.BLAST_file_name,'blast_GUI');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global PROG_NAME
if (get(hObject,'Value') == get(hObject,'Max'))
    % Checkbox is checked-take approriate action
    % Activate certain fields
    %set(handles.BLAST_BIN_FOLDER            ,'Enable','on');
    %set(handles.BLAST_BIN_FOLDER_BROWSE     ,'Enable','on');
    set(handles.FASTA_METAGENOME_FILE       ,'Enable','on');
    set(handles.FASTA_METAGENOME_FILE_BROWSE,'Enable','on');
    set(handles.E_VALUE_BLAST               ,'Enable','on');
    set(handles.FASTA_REFSEQ_FILE           ,'Enable','on');
    set(handles.FASTA_REFSEQ_FILE_BROWSE    ,'Enable','on');
%     set(handles.BLAST_OUTPUT_FILE           ,'String',default_filename_no_path);
    set(handles.BLAST_OUTPUT_FILE_BROWSE    ,'Enable','off');
    
    set(handles.GENPEP_REFSEQ_FILE        ,  'Enable','on'); % v3.0.8 
    set(handles.GENPEP_REFSEQ_FILE_BROWSE ,  'Enable','on');  
    set(handles.METAG_DATA_TYPE,             'Enable','on');  

    set(handles.RUN_BLAST_METAMINER, 'String', ['Run BLAST & ' PROG_NAME]);
else
    % Checkbox is not checked-take approriate action
    % Inactivate certain fields
    %set(handles.BLAST_BIN_FOLDER            ,'Enable','off');
    %set(handles.BLAST_BIN_FOLDER_BROWSE     ,'Enable','off');
    set(handles.FASTA_METAGENOME_FILE       ,'Enable','off');
    set(handles.FASTA_METAGENOME_FILE_BROWSE,'Enable','off');
    set(handles.E_VALUE_BLAST               ,'Enable','off');
    set(handles.FASTA_REFSEQ_FILE           ,'Enable','off');
    set(handles.FASTA_REFSEQ_FILE_BROWSE    ,'Enable','off');
%     set(handles.BLAST_OUTPUT_FILE           ,'String',default_filename_with_path);
    set(handles.BLAST_OUTPUT_FILE_BROWSE    ,'Enable','on');

    set(handles.GENPEP_REFSEQ_FILE        ,  'Enable','off'); % v3.0.8
    set(handles.GENPEP_REFSEQ_FILE_BROWSE ,  'Enable','off');
    set(handles.METAG_DATA_TYPE,             'Enable','off');  
   
    set(handles.RUN_BLAST_METAMINER, 'String', ['Run ' PROG_NAME]);
end

% --- Executes during object creation, after setting all properties.
function BLAST_ON_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_ON (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Default is set to ON
set(hObject,'Value', get(hObject,'Max'));



% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
%axes(hObject);
%imshow('caltech_logo.gif');
% Hint: place code in OpeningFcn to populate axes1




% --- Executes on selection change in N_THREADS.
function N_THREADS_Callback(hObject, eventdata, handles)
% hObject    handle to N_THREADS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns N_THREADS contents as cell array
%        contents{get(hObject,'Value')} returns selected item from N_THREADS


% --- Executes during object creation, after setting all properties.
function N_THREADS_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N_THREADS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% works only if Parallel Computing Toolbox is on
MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer)
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end
% determine number of cpus
if ParallelToolBoxFound
    if ~isdeployed
        Ncpus = maxNumCompThreads('automatic');
    else
        c_local = parcluster('local');
        Ncpus = c_local.NumWorkers;
    end
    
    threads = [1:Ncpus];
    %     set(hObject,'Enable','on','String',num2cell(threads),'HorizontalAligment','center','Value',maxNumCompThreads);
    if ~isdeployed
        set(hObject,'Enable','on','String',num2cell(threads),'Value',maxNumCompThreads);
    else
        set(hObject,'Enable','on','String',num2cell(threads),'Value',Ncpus);
    end
else
    set(hObject,'Enable','off');
end

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object creation, after setting all properties.
function CALTECH_LOGO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CALTECH_LOGO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
%axes(hObject);
%set(hObject,'NextPlot','add')
%imshow('caltech_logo.gif');



% Hint: place code in OpeningFcn to populate CALTECH_LOGO




% --- Executes during object creation, after setting all properties.
function NUM_CPU_TEXT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to NUM_CPU_TEXT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
MatVer = ver;
ParallelToolBoxFound = 0;
for i=1:length(MatVer)
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end
if ParallelToolBoxFound
    set(hObject,'Enable','on');
else
    set(hObject,'Enable','off');
end



% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'Name','');



% --- Executes on button press in ABOUT.
function ABOUT_Callback(hObject, eventdata, handles)
% hObject    handle to ABOUT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
IN = GetParams();
blast_msg = '';
msgbox(sprintf('MCRL - Metagenomic Clustering by Reference Library %s (beta)\n\nWritten by: Arbel D. Tadmor(1,2) \n(1) California Institute of Technology, Pasadena, CA 91125, USA\n(2) TRON - Translational Oncology at the University Medical Center of the Johannes Gutenberg, University Mainz, 55131, Mainz, Germany\n\nThis program uses blast2.2.22+\nBLAST is government software obtained from the NCBI.\nFor references see:\n\n  - Altschul et al., "Gapped BLAST and PSI-BLAST: a new generation\n   of protein database search programs",\nNucleic Acids Res. 25:3389-3402 (1997).\n\n  - Camacho et al., "BLAST+: architecture and applications.",\n   BMC Bioinformatics 10:421 (2008).\n\nCopyright 2019 California Institute of Technology, Pasadena, CA.\nAll Rights Reserved.',IN.version));

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text25.
function text25_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function pushbutton12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



% --- Executes during object creation, after setting all properties.
function CAT_LOGO_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CAT_LOGO (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
%hObject
%axes(hObject);
set(hObject,'NextPlot','add')
%imshow('cat.gif');
x=imread('cat2.gif');
f=image(x);

% Hint: place code in OpeningFcn to populate CAT_LOGO




% --- Executes during object creation, after setting all properties.
function BLAST_BIN_FOLDER_BROWSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_BIN_FOLDER_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

close all;
return;


% --- Executes during object creation, after setting all properties.
function BLAST_OUTPUT_FILE_BROWSE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BLAST_OUTPUT_FILE_BROWSE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

set(hObject,'Enable','off');


% --- Executes on selection change in METAG_DATA_TYPE.
function METAG_DATA_TYPE_Callback(hObject, eventdata, handles)

% hObject    handle to METAG_DATA_TYPE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns METAG_DATA_TYPE contents as cell array
%        contents{get(hObject,'Value')} returns selected item from METAG_DATA_TYPE


% --- Executes during object creation, after setting all properties.
function METAG_DATA_TYPE_CreateFcn(hObject, eventdata, handles)
% hObject    handle to METAG_DATA_TYPE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in SIGNATURE_MIN_MAX_STR.
function SIGNATURE_MIN_MAX_Callback(hObject, eventdata, handles)
% hObject    handle to SIGNATURE_MIN_MAX_STR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns SIGNATURE_MIN_MAX_STR contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SIGNATURE_MIN_MAX_STR


% --- Executes during object creation, after setting all properties.
function SIGNATURE_MIN_MAX_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SIGNATURE_MIN_MAX_STR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function valOverlapThreshold_Callback(hObject, eventdata, handles)
% hObject    handle to valOverlapThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of valOverlapThreshold as text
%        str2double(get(hObject,'String')) returns contents of valOverlapThreshold as a double
% good = legal_overlap(str2num(get(hObject,'String')));
% if ~good
%     set(hObject,'String','');
% end

% --- Executes during object creation, after setting all properties.
function valOverlapThreshold_CreateFcn(hObject, eventdata, handles)
% hObject    handle to valOverlapThreshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in TRACK.
function TRACK_Callback(hObject, eventdata, handles)
% hObject    handle to TRACK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of TRACK
