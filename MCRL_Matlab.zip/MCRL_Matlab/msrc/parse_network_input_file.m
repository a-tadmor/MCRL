function [FAIL, Table_nr, reference_gene_array, NodeLabels] = parse_network_input_file(config_txt_file)
% <-- plot_network_EXE.m

FAIL = 1; Table_nr = ''; reference_gene_array={}; NodeLabels='';

fid=fopen(config_txt_file,'r');

if fid<0, return; end

[FOUND, tline]= skip_empty_tlines(fid);
if ~FOUND, fclose(fid); return; end
if tline(1)~='#', fclose(fid); return; end

[FOUND, tline]= skip_empty_tlines(fid);
if ~FOUND, fclose(fid); return; end
if tline(1)=='#', fclose(fid); return; end
 
NodeLabels = strtrim(lower(tline));
switch NodeLabels
    case {'all', 'epicenter', 'none', 'auto'}
        % ok
    otherwise
        fclose(fid); return
end

[FOUND, tline]= skip_empty_tlines(fid);
if ~FOUND, fclose(fid); return; end
if tline(1)~='#', fclose(fid); return; end

[FOUND, tline]= skip_empty_tlines(fid);
if ~FOUND, fclose(fid); return; end
if tline(1)=='#', fclose(fid); return; end
 

Table_nr = tline;

[FOUND, tline]= skip_empty_tlines(fid);
if ~FOUND, fclose(fid); return; end
if tline(1)~='#', fclose(fid); return; end

i=0; FOUND_ONE=0;
while 1
    [FOUND, tline, EOF]= skip_empty_tlines(fid);
    if EOF; break; end
    if ~FOUND, fclose(fid); return; end
    i=i+1;
    reference_gene_array{i} = strtrim(tline);
    FOUND_ONE=1;
end
if ~FOUND_ONE, fclose(fid); return; end

fclose(fid);

FAIL=0;
