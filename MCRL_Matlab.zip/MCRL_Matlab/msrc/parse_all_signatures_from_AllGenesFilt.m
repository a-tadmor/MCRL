function signature_HASH = parse_all_signatures_from_AllGenesFilt(MCRL_AllGenesFilt_file)
% <-- benchmark_CDHIT_EXE5.m, confirm_CDHIT_clusters_are_not_overlapping_EXE2.m

fid=fopen(MCRL_AllGenesFilt_file);

tab=sprintf('\t');

fprintf('Parsing all signatures ');
counter=0;
tline = fgetl(fid);
while 1
    if length(tline)>5 && strcmp(tline(1:5),'table') 
        counter=counter+1;
        if counter/1000 == round(counter/1000), fprintf('.'); end
        % Parse RefSeq gene
        it=find(tline==tab);
        RefSeq_gene = tline(it(2)+1:it(3)-1);
        
        tline = fgetl(fid); % skip header
        tline = fgetl(fid); % skip header

        END=0;
        signature = {};
        while ~END
            signature = [signature strip(tline)];
            tline = fgetl(fid);
            END= length(tline)>5 && strcmp(tline(1:5),'table') || ~ischar(tline) || isempty(tline);
        end
        signature_array{counter}   = signature;
        RefSeq_gene_array{counter} = RefSeq_gene;
    else
        tline = fgetl(fid);
        if ~ischar(tline) , break, end
    end
end
fclose(fid);
signature_HASH = containers.Map(RefSeq_gene_array, signature_array);

fprintf('\n');