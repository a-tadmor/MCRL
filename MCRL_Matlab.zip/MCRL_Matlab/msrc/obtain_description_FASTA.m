function OUT = obtain_description_FASTA(FASTA_filename,RecordLocation,gene_id)
% FIND DESCRIPTION OF "gene_id" IN THE NCBI FASTA FILE:
%
%>gene_id DESCRRIPTION...
%MLMMVIRIYIHKRLNAKDYNNFYTSIGDFGYTIPGSDAPQYNIESDSEHYLNFGIAHINFNNGTNNQITN...
%
% gene_id is extracted by BLASTALL and is part of the hit table

% Open the file
fid  = fopen(FASTA_filename,'r');

fseek(fid,RecordLocation,'bof');
line = fgetl(fid); % Header of current record

% Get definition of gene_id
OUT.Definition  = strtrim(line(length(gene_id)+2:end));

% Get Sequence
Sequence = '';
line = fgetl(fid);
while ~feof(fid) && isempty(strfind(line,'>'))
    if ischar(line)
        % because if eof is encounterd line=-1
        Sequence = [Sequence line];
    end
    line = fgetl(fid);
end
if feof(fid) && ischar(line)
    Sequence = [Sequence line];
end

% This infomration is not available in the FASTA file
OUT.Sequence              = upper(Sequence(find(isspace(Sequence)==0)));
OUT.gene_len              = length(OUT.Sequence);

if OUT.gene_len==0
   fprintf('%s debug: bad record encountered in FASTA file ''%s'' - no sequence found\n',mfilename,FASTA_filename)
   keyboard
end
OUT.LocusGenBankDivision  = 'N/A';
OUT.LocusMoleculeType     = 'N/A';
OUT.Source                = 'N/A';
OUT.SourceOrganism        = 'N/A';
OUT.Comment               = 'N/A';
OUT.Features              = 'N/A';

fclose(fid);
