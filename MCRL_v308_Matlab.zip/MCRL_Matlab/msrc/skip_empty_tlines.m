function [FOUND, tline, EOF] = skip_empty_tlines(fid)
% <-- parse_network_input_file.m

FOUND=0; EOF=0;
counter=0;
while counter<100
    tline = fgetl(fid);
    if ~ischar(tline), EOF=1; break, end
    if ~isempty(tline)
        FOUND=1;
        tline = strtrim(tline);
        break;
    end
end
