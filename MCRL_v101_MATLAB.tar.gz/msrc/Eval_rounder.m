function z = Eval_rounder(x)

y = -1 * log10(x);

y = min(y, 100);

z = round(y);

z(z==0)=1;