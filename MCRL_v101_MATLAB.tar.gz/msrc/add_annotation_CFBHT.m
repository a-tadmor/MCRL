function CFBHT  = add_annotation_CFBHT(CFBHT,  ANNOTATION_HASH)
% <-- MCRL_MAIN.m

for j=1:length(CFBHT.Unique_phage_gene_vec)
    reported_gene = CFBHT.Unique_phage_gene_vec{j};
    CFBHT.best_seq_vec{j}         = ANNOTATION_HASH.best_seq_vec(reported_gene);
    CFBHT.best_description_vec{j} = ANNOTATION_HASH.best_description_vec(reported_gene);
    CFBHT.best_Gene_len_vec(j)    = ANNOTATION_HASH.best_Gene_len_vec(reported_gene);
    CFBHT.Features{j}             = ANNOTATION_HASH.Features(reported_gene);

    gene_len = ANNOTATION_HASH.best_Gene_len_vec(reported_gene);
    CFBHT.best_Align_perc_of_gene_vec(j) = CFBHT.best_Align_length_vec(j)/gene_len*100;
end