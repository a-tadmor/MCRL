function  [MolTypeAuto, handles, success] = check_MolTypeFromGUI_vs_auto_Detet(MolTypeFromGUI, val_FASTA_METAGENOME_PATHFILE, COMMAND_LINE, handles)
% <-- main_gui2.m

success = 1;
if ~exist('handles','var')
    handles=[];
end

% Check if metagenome data type is correct
    % Autodetect type of molecule (nuct or prot) in metagenome file
    MolTypeAuto = AutoDetectMolType(val_FASTA_METAGENOME_PATHFILE, COMMAND_LINE);
    % Is molecule type is not recognized? - i.e., non stardard characters found (gaps are considered nonstandard)
    
    if strcmp(MolTypeAuto,'unknown')
        % Chose MolType again
        if ~COMMAND_LINE
            MolTypeGUI = questdlg(sprintf('Nonstandard characters were detected in %s. Please reselect data type:',val_FASTA_METAGENOME_PATHFILE),'Molecule type','nucl','prot','abort & diagnose','abort & diagnose');
            switch MolTypeGUI
                case 'prot'
                    set(handles.METAG_DATA_TYPE, 'Value', 1);
                case 'nucl'
                    set(handles.METAG_DATA_TYPE, 'Value', 2);
                otherwise
                    keyboard
            end
            MolTypeAuto = MolTypeGUI;
        else
            error('Metagenome molecule type is incorrect\n');
        end
    elseif ~strcmp(MolTypeAuto,MolTypeFromGUI)
        % Molecule type does not agree with what user put in
        if ~COMMAND_LINE
            switch MolTypeAuto
                case 'prot'
                    MolTypeFromGUI = questdlg(sprintf('MCRL autodetected that %s is a PROTEIN file. Please reselect data type:',val_FASTA_METAGENOME_PATHFILE),'Molecule type','nucl','prot','abort & diagnose','prot');
                case 'nucl'
                    MolTypeFromGUI = questdlg(sprintf('MCRL autodetected that %s is a NUCLEOTIDE file. Please reselect data type:',val_FASTA_METAGENOME_PATHFILE),'Molecule type','nucl','prot','abort & diagnose','nucl');
            end
            switch MolTypeFromGUI
                case 'prot'
                    set(handles.METAG_DATA_TYPE, 'Value', 1); drawnow;
                case 'nucl'
                    set(handles.METAG_DATA_TYPE, 'Value', 2); drawnow;
                otherwise
                    success = 0;
                    return;
                    %error('unknown metagenome data type');
            end
            MolTypeAuto=MolTypeFromGUI;
        else
            error('Metagenome molecule type is incorrect\n');
        end
    end