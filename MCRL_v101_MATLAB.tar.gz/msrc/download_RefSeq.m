function [RefSeq_was_downloaded, Error, LatestReleaseAlreadyDownloaded, RefSeq_release] = download_RefSeq()
% <--main_gui2.m
Error=1;
LatestReleaseAlreadyDownloaded=0;
RefSeq_was_downloaded = 0;
RefSeq_release='';

fprintf('Download from NCBI latest version of viral RefSeq database\n')
cur_dir = pwd;

ncbi_website = 'ftp.ncbi.nih.gov';

%download release notes
refseq_ftp_dir = 'refseq/release/release-notes';

if ispc
    err_msg =  sprintf('Could not establish an ftp connection. Tips:\n(1) Make sure you have an internet connection\n(2) Make sure MCRL is installed locally\n (3) Make sure the ftp port is not blocked on your computer');
else
    err_msg =  sprintf('Could not establish an ftp connection. Tips:\n(1) Make sure you have an internet connection\n(2) Make sure the ftp port is not blocked on your computer');
end

% open ftp connection to ncbi
try
    fprintf(sprintf('Opening ftp connection to %s...', ncbi_website));
    ftpobj = ftp(ncbi_website);
catch
    fprintf('--> failed\n');
        
    h=errordlg(err_msg);
    uiwait(h);
    return
end

% change diretories at ftp site
try
    cd(ftpobj,refseq_ftp_dir);
catch
    fprintf('--> failed\n');
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
end
% get files in directory
try
    files = dir(ftpobj);
catch
    fprintf('--> failed\n');
    cd(cur_dir);
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
end

if isempty(files)
    fprintf('--> failed\n');
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
end

fprintf('...OK\n');

fprintf('Searching for RefSeq release notes for current version...\n')
found_txt_file = 0;
for i=1:length(files)
    
    % Search for "RefSeq-release*.txt" file
%   if ~files(i).isdir && strcmp(files(i).name(1:14), 'RefSeq-release') && strcmp(files(i).name(end-3:end), '.txt')
    if ~files(i).isdir && ~isempty(strfind(files(i).name, 'RefSeq-release')) && strcmp(files(i).name(end-3:end), '.txt')
        % found "RefSeq-releaseXX.txt" file
        cd(['..' filesep 'RefSeq_database'])
        RefSeq_release_txt_file = files(i).name;
        
        fprintf(sprintf('\t--> OK, downloading %s...\n', RefSeq_release_txt_file));
        mget(ftpobj, RefSeq_release_txt_file);
        found_txt_file = 1;
        cd(cur_dir);
    end
end

if ~found_txt_file
    fprintf('\t--> failed\n');
    cd(cur_dir);
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
end

RefSeq_release = RefSeq_release_txt_file(1:end-4);
RefSeq_release(find(RefSeq_release=='-')) = '_';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maybe latest release available?
AlreadyExists=0;
RefSeq_file_name_header_tmp = sprintf('viral_%s', RefSeq_release);
d_faa    = dir(['..' filesep 'RefSeq_database' filesep sprintf('%s.faa',  RefSeq_file_name_header_tmp)]);
d_gpff   = dir(['..' filesep 'RefSeq_database' filesep sprintf('%s.gpff', RefSeq_file_name_header_tmp)]);
if ~isempty(d_faa)
    AlreadyExists = 1;
elseif ~isempty(d_gpff)
    AlreadyExists = 2;
end
switch AlreadyExists
    case 1
        fprintf('Latest version of the viral RefSeq faa file (%s.faa) has already been downloaded\n',RefSeq_file_name_header_tmp)
    case 2
        fprintf('Latest version of the viral RefSeq gpff file (%s.gpff) has already been downloaded\n',RefSeq_file_name_header_tmp)
end
if AlreadyExists>0
    Error=0;
    LatestReleaseAlreadyDownloaded=1;
    return
end
% cannot proceed further if a file 'viral_RefSeq_releaseXX.gpff' or
% 'viral_RefSeq_releaseXX.faa' are present in the RefSeq_database folder
% (since these will be created below)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% now download *.faa files
fprintf('Searching for *.faa files...\n')
refseq_ftp_dir = '/refseq/release/viral';

try
    cd(ftpobj,refseq_ftp_dir);
    files = dir(ftpobj);
catch
    fprintf('\t--> failed\n');
    cd(cur_dir);
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
end

if isempty(files)
    fprintf('\t--> failed\n');
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
end

% 1. download *.faa.gz file to tmp folder
% 2. extract *.faa.gz file file to Combine_RefSeq_files folder
% 3. delete gz file from tmp folder
% 4. Goto 1 for all *.faa.gz files
% 5. Combine all *.faa files in Combine_RefSeq_files folder
% 6. Move combine_all file to Combine_RefSeq_files folder
% 7. Delete all %.faa files in Combine_RefSeq_files folder
fail = download_and_extract_refseq('faa', files, cur_dir, ftpobj, RefSeq_release);

if fail==1
    fprintf('\t--> failed\n');
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
elseif fail==2
    fprintf('\t--> failed\n');
    h=errordlg('Could not delete contents of Combine_RefSeq_files folder');
    uiwait(h);
    close(ftpobj);
    Error=2;
    return
end

[fail, RefSeq_file_name_header] = download_and_extract_refseq('gpff', files, cur_dir, ftpobj, RefSeq_release);

if fail
    fprintf('\t--> failed\n');
    h=errordlg(err_msg);
    uiwait(h);
    close(ftpobj);
    return
elseif fail==2
    fprintf('\t--> failed\n');
    h=errordlg('Could not delete contents of Combine_RefSeq_files folder');
    uiwait(h);
    close(ftpobj);
    Error=2;
    return
end

% save name of header of RefSeq gene to file
% Downloading does not change the GUI. User needs to manually select this RefSeq file
% save(['..' filesep 'msrc' filesep 'RefSeq_file_name_header.mat'],'RefSeq_file_name_header')

fprintf('\t--> DONE.\n');

RefSeq_was_downloaded= 1;
Error=0;