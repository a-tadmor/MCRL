function lastn = maxNumCompThreads(varargin)
%maxNumCompThreads controls the maximum number of computational threads
%   N = maxNumCompThreads returns the current maximum number of
%   computational threads N.
%
%   LASTN = maxNumCompThreads(N) set the maximum number of computational
%   threads to N, and returns the preivous maximum number of computational
%   threads LASTN.
%
%   LASTN = maxNumCompThreads('automatic') set the maximum number of
%   computational threads to what MATLAB determines to be the most
%   desirable. In addition, it returns the previous maximum number of
%   computational threads LASTN. Currently the maximum number of
%   computational threads is equal to the number of computational cores on
%   your machine. 
%
%   Note that unlike enabling multithreading via the preference panel, the
%   setting does not propagate to the next MATLAB session.

%   Copyright 2007 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2009/04/21 03:24:20 $

narginchk(0, 1)
% warning('MATLAB:maxNumCompThreads:Deprecated','maxNumCompThreads will be removed in a future release. Please remove any instances of this function from your code.');
lastn = maxNumCompThreadsHelper(varargin{:});
