function good = legal_evalue(x, COMMAND_LINE)

if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

good = 0;
if isempty(x) || length(x)>1 || ~isempty(x) && (x<0 || x>10)
    % invalid entry
    if ~COMMAND_LINE
        h=warndlg('E value must be a postive number < 10 (e.g. 0.001 or 1e-3)','Notice'); uiwait(h);
    else
        error('E value must be a postive number < 10 (e.g. 0.001 or 1e-3)')
    end
    return
end
good = 1;