function OUT  = get_annotation_faster(IN, FILE_PARSE, FILE_PARSE_ARRAY, gene_id, COMMAND_LINE, SELECT_FASTA)
% <-- MCRL_MAIN.m

% Find location of this gene's record in the FASTA or GenPept file (doing it in the main is more memory efficient)
found = 0;
rec=find(contains(FILE_PARSE_ARRAY,gene_id));
if ~isempty(rec)
    found=1;
    rec=rec(1);
end

if isempty(IN.GENPEP_REFSEQ_FILE) || ~isempty(SELECT_FASTA) && SELECT_FASTA==1
    % FASTA FILE SUPPLIED
    if ~found
        errmsg=sprintf('gene ID ''%s'' was not found in: %s\n', gene_id, IN.FASTA_REFSEQ_FILE);
        fprintf('%s\n',errmsg);
        if ~COMMAND_LINE
            h=errordlg(errmsg);
            uiwait(h);
            error(errmsg)
        else
            error(errmsg);
        end
        keyboard
    end
    OUT  = obtain_description_FASTA(IN.FASTA_REFSEQ_FILE,FILE_PARSE(rec).RecordLocation,gene_id);   
else % GENPEPT FILE SUPPLIED
    if ~found
        errmsg=sprintf('\ngene ID ''%s'' was not found in: %s\n',gene_id, IN.GENPEP_REFSEQ_FILE);
        fprintf('%s\n',errmsg);
        if ~COMMAND_LINE
            h=errordlg(errmsg);
            uiwait(h);
            error(errmsg)
        else
            error(errmsg);
        end
        keyboard
    end
    if rec==1
        StartOfRecord = 0;
        StartSearchFrom = []; % don't need this
    else
        StartOfRecord = []; % will need to find this
        StartSearchFrom = FILE_PARSE(rec-1).RecordLocation; % file location of last Version field - start search from here
    end
    OUT  = obtain_description_GENPEPT(IN.GENPEP_REFSEQ_FILE,StartSearchFrom,StartOfRecord); 
end