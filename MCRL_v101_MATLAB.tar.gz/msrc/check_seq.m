function check_seq(SEQ, FASTA_filename, COMMAND_LINE)
%<--fastaread_fun.m
global PROG_NAME

SEQ=upper(SEQ);
N = sum(SEQ=='A')+sum(SEQ=='B')+sum(SEQ=='C')+sum(SEQ=='D')+sum(SEQ=='E')+sum(SEQ=='F')+sum(SEQ=='G')+sum(SEQ=='H')+sum(SEQ=='I')+sum(SEQ=='K')+sum(SEQ=='L')+sum(SEQ=='M')+sum(SEQ=='N')+sum(SEQ=='P')+sum(SEQ=='Q')+sum(SEQ=='R')+sum(SEQ=='S')+sum(SEQ=='T')+sum(SEQ=='V')+sum(SEQ=='W')+sum(SEQ=='Y')+sum(SEQ=='U')+sum(SEQ=='O')+sum(SEQ=='B')+sum(SEQ=='Z')+sum(SEQ=='J')+sum(SEQ=='X')+sum(SEQ=='*');
if N~=length(SEQ)
    if N+sum(SEQ=='-')==length(SEQ)
        fprintf('Detected gap(s) in ''%s'': please remvove and rerun %s\n',FASTA_filename, PROG_NAME);
        if ~COMMAND_LINE
            h=errordlg(sprintf('Detected gap(s) in ''%s'': please remvove and rerun %s',FASTA_filename, PROG_NAME),'Notice'); uiwait(h);
            error('Detected gap(s) in ''%s'': please remvove and rerun %s', FASTA_filename, PROG_NAME);
        else
            error('Detected gap(s) in ''%s'': please remvove and rerun %s', FASTA_filename, PROG_NAME);
        end
    else
        fprintf('Illegal symbol(s) found in ''%s''\n',FASTA_filename);
        if ~COMMAND_LINE
            h=errordlg(sprintf('Illegal symbol(s) found in ''%s''',FASTA_filename),'Notice'); uiwait(h);
            error('Illegal symbol(s) found in ''%s''', FASTA_filename);
        else
            error('Illegal symbol(s) found in ''%s''', FASTA_filename);
        end
    end
    keyboard
end