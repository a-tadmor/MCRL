function par_run_MCRL(in, FASTA_METAGENOME_FILE_ARRAY)
%<-- par_command_line_MCRL_EXE.m
clc

ParallelToolBoxFound = 0;
MatVer = ver;
for i=1:length(MatVer)
    if strcmp(MatVer(i).Name,'Parallel Computing Toolbox')
        ParallelToolBoxFound = 1;
    end
end
if ~ParallelToolBoxFound
    fprintf('Parallel processing toolbox is not installed\n');
    return
end

% Shut down parallel processing if open
poolobj = gcp('nocreate');
if ~isempty(poolobj)
    delete(poolobj);
end
Max_threads = maxNumCompThreads('automatic');
val_N_THREADS = length(FASTA_METAGENOME_FILE_ARRAY);
if val_N_THREADS>Max_threads
    fprintf('Maximum number of threads allowed = %d', Max_threads);
    return
end
% poolobj = parpool(val_N_THREADS); % v3.0.13
% v3.0.13
if verLessThan('matlab','8.0.1')
    matlabpool(val_N_THREADS);
else
    patchJobStorageLocation; % make sure storage folder has unique ID
    poolobj = parpool(val_N_THREADS);
end

if iscell(in.OUTPUT_NAME)
   if length(in.OUTPUT_NAME) ~= length(FASTA_METAGENOME_FILE_ARRAY) 
      error('output name array and metagenome filename array do not match in length\n') 
   end
end

% Run MCRL
for i=1:val_N_THREADS
    in_array{i}                             = in;
    if iscell(in.OUTPUT_NAME)
        % User provided different name for each metagenome
        rmfield(in_array{i}, 'OUTPUT_NAME');
        in_array{i}.OUTPUT_NAME             = in.OUTPUT_NAME{i};
    end
    in_array{i}.FASTA_METAGENOME_FILE =  FASTA_METAGENOME_FILE_ARRAY{i};
    if isempty(in.RUN_ID)
        in_array{i}.RUN_ID                   = in.RUN_ID_ARRAY{i};
    end
end

parfor i=1:val_N_THREADS
    MCRL_fun(in_array{i});
end
