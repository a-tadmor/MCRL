function empty_fastafile_error(FASTA_filename, COMMAND_LINE)
%<--fastaread_fun.m
global PROG_NAME

fprintf('%s.m Error: cannot open FASTA file ''%s''\n',mfilename,FASTA_filename);
if ~COMMAND_LINE
    h=errordlg(sprintf('%s cannot open %s',PROG_NAME, FASTA_filename),'Notice'); uiwait(h);
    error('%s cannot open %s',PROG_NAME, FASTA_filename);
else
    error('%s cannot open %s',PROG_NAME, FASTA_filename);
end
keyboard