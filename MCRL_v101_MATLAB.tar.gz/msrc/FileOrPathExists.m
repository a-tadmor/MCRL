function good = FileOrPathExists(filename, COMMAND_LINE)
% should be legal for both UNIX and DOS. blast files can't have spaces for PCs
if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

good = 1;
if isempty(filename)
    good = 0;
    if ~COMMAND_LINE
        h=warndlg('File name cannot be blank','Notice');
        uiwait(h);
    else
        error('Please note: file name cannot be blank');
    end
    return
end

if exist(filename, 'file')==0
    if ~COMMAND_LINE
        h=warndlg([filename ' does not exist'],'Notice');
        uiwait(h);
    else
        error('%s does not exist',filename);
    end
    good = 0;
    return
end