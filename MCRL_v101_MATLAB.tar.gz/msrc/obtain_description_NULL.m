function OUT = obtain_description_NULL()
% <-- MCRL_MAIN.m

% Get definition of gene_id
OUT.Definition  =  'N/A';
OUT.Sequence    =  'N/A';
OUT.gene_len    =  -1;
OUT.LocusGenBankDivision  = 'N/A';
OUT.LocusMoleculeType     = 'N/A';
OUT.Source                = 'N/A';
OUT.SourceOrganism        = 'N/A';
OUT.Comment               = 'N/A';
OUT.Features              = 'N/A';


