function ST = keep_only_delegates(lowest_E_value_index_vec, ST_or_FBHT, SIGNATURE_HASH)
% <--MCRL_MAIN.m
% lowest_E_value_index_vec(i): i-th index corresponds to the ST_or_FBHT structure

count = 0;
for i=1:length(lowest_E_value_index_vec)
    % Find all other RefSeq genes who belong to networks where 'lowest_E_value_index_vec(i)' is the RefSeq gene with the lowest E value
    if lowest_E_value_index_vec(i)~=-1
        % indices of all genes related to 'lowest_E_value_index_vec(i)' that have higher E values
        ST_or_FBHT_indices_vec = find(lowest_E_value_index_vec==lowest_E_value_index_vec(i));
        
        % add one more declared RefSeq gene
        count = count + 1;
        
        % index of declared RefSeq gene (this is the only part required for MCRL's iterative filtering)
        ST.best_ST_or_FBHT_indx_vec(count) = lowest_E_value_index_vec(i); 
        ST.best_ST_or_FBHT_str{count}      = ST_or_FBHT.Unique_phage_gene_vec{lowest_E_value_index_vec(i)};
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % REPORTING
        % For reporting: signature of declared RefSeq gene
        ST.List_of_contigs{count}   = ST_or_FBHT.List_of_contigs{lowest_E_value_index_vec(i)};
        
        % For reporting: related RefSeq genes
        % All ST_or_FBHT_indices_vec genes are related to 'lowest_E_value_index_vec(i)'.
        % 'lowest_E_value_index_vec(i)' may not be in this list because it may be represented by another RegSeq gene
        ST.related_refseq_genes_FHBT_ind_vec{count} = unique([lowest_E_value_index_vec(i), ST_or_FBHT_indices_vec]);
        
        % convert indices to RefSeq gene IDs
        ST.related_refseq_genes_array{count} = {};
        for k=1:length(ST.related_refseq_genes_FHBT_ind_vec{count})
            ST_or_FBHT_idx  = ST.related_refseq_genes_FHBT_ind_vec{count}(k);
            ST.related_refseq_genes_array{count}= [ST.related_refseq_genes_array{count}, ST_or_FBHT.Unique_phage_gene_vec{ST_or_FBHT_idx}];
        end
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
        % Remove these indices for next interations, don't need to visit them again
        lowest_E_value_index_vec(ST_or_FBHT_indices_vec) = -1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REPORTING

% For reporting purposes find out members of reported RefSeq gene cluster:

% Carry over to current iteration previous related genes that declared a given RefGen 
% If this is iteration=1 then no history is input structure ST_or_FBHT since no declarations have been made
if ~isfield(ST_or_FBHT, 'related_refseq_genes_TOT_array')
    for i=1:length(ST_or_FBHT.List_of_contigs)
        ST_or_FBHT.related_refseq_genes_TOT_array{i} = {}; % no history yet -> list of all RefSeq gene IDs that are related to declared RefSeq gene and declared it
    end
end

% Go over every declared RefSeq gene 
for count=1:length(ST.best_ST_or_FBHT_indx_vec) % count = index of current declared RefSeq gene
    
    % Find previous related genes that declared a RefSeq gene
    indx = ST.best_ST_or_FBHT_indx_vec(count); % Index in ST_or_FBHT of current declared RefSeq gene
    
    % all previously related genes associated with this declared RefSeq gene
    Previous_related_genes_that_declared_current_RefSeq    = ST_or_FBHT.related_refseq_genes_TOT_array{indx};

    % List of related RefSeq genes declaring current RefSeq genes determined in current iteration
    New_related_genes_that_declared_current_RefSeq          = ST.related_refseq_genes_array{count};
    ST.related_refseq_genes_TOT_array{count}        = unique([New_related_genes_that_declared_current_RefSeq , Previous_related_genes_that_declared_current_RefSeq]);
end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For reporting purposes find out total signature of RefSeq gene cluster:

% Carry over previous signatures to current signatures
% Go over every declared RefSeq gene 
for count=1:length(ST.best_ST_or_FBHT_indx_vec)
    % Go over all current and previous related genes that declared current RefSeq
    ST.list_of_contigs_in_network_TOT_array{count} = {}; % no history yet
    for j = 1:length(ST.related_refseq_genes_TOT_array{count})
        current_related_gene                              = ST.related_refseq_genes_TOT_array{count}{j};
        new_signature                                     = SIGNATURE_HASH(current_related_gene);
        ST.list_of_contigs_in_network_TOT_array{count}    = [ST.list_of_contigs_in_network_TOT_array{count}, new_signature'];
    end
    ST.list_of_contigs_in_network_TOT_array{count}    = unique(ST.list_of_contigs_in_network_TOT_array{count});
    ST.N_tot_contigs_in_network(count)                = length(ST.list_of_contigs_in_network_TOT_array{count});
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Report back these BLAST values for each of best REFSEQ genes found
ST.N_contigs_vec                = ST_or_FBHT.N_contigs_vec(ST.best_ST_or_FBHT_indx_vec);          % Each element = number of contigs assoicated with the REFSEQ gene yielding the lowest E value for a given network
ST.min_E_value_vec              = ST_or_FBHT.min_E_value_vec(ST.best_ST_or_FBHT_indx_vec);        % Each element = lowest E value for a given network
ST.max_Percent_Ident_vec        = ST_or_FBHT.max_Percent_Ident_vec(ST.best_ST_or_FBHT_indx_vec);  % Each element = percent identity of best contig with respect to REFSEQ gene yielding the lowest E value for a given network
ST.max_Number_of_Ident_vec      = ST_or_FBHT.max_Number_of_Ident_vec(ST.best_ST_or_FBHT_indx_vec);% Each element = number of identical aa of best contig with respect to REFSEQ gene yielding the lowest E value for a given network
ST.Unique_phage_gene_vec        = ST_or_FBHT.Unique_phage_gene_vec(ST.best_ST_or_FBHT_indx_vec);  % Each element = Description of  REFSEQ gene yielding the lowest E value for a given network
ST.best_Align_length_vec        = ST_or_FBHT.best_Align_length_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_Gene_len_vec            = ST_or_FBHT.best_Gene_len_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_Align_perc_of_gene_vec  = ST_or_FBHT.best_Align_perc_of_gene_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_seq_vec                 = ST_or_FBHT.best_seq_vec(ST.best_ST_or_FBHT_indx_vec);
ST.best_description_vec         = ST_or_FBHT.best_description_vec(ST.best_ST_or_FBHT_indx_vec);
ST.LocusGenBankDivision         = ST_or_FBHT.LocusGenBankDivision(ST.best_ST_or_FBHT_indx_vec);
ST.LocusMoleculeType            = ST_or_FBHT.LocusMoleculeType(ST.best_ST_or_FBHT_indx_vec);
ST.Source                       = ST_or_FBHT.Source(ST.best_ST_or_FBHT_indx_vec);
ST.SourceOrganism               = ST_or_FBHT.SourceOrganism(ST.best_ST_or_FBHT_indx_vec);
ST.Comment                      = ST_or_FBHT.Comment(ST.best_ST_or_FBHT_indx_vec);
ST.Features                     = ST_or_FBHT.Features(ST.best_ST_or_FBHT_indx_vec);

    

