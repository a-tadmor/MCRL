function RefSeq_plot = fix_label(RefSeq)
% <-- plot_user_topology.m


RefSeq_plot=[];
for ii=1:length(RefSeq)
    if RefSeq(ii)=='_'
        RefSeq_plot = [RefSeq_plot '\_'];
    else
        RefSeq_plot = [RefSeq_plot RefSeq(ii)];
    end
end