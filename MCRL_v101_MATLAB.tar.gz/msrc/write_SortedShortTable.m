function write_SortedShortTable(outfile,ST,msg,IN_FASTA_METAGENOME_FILE,IN_MolType, COMMAND_LINE)
% <--MCRL_MAIN.m

% IN_FASTA_METAGENOME = fastaread(IN_FASTA_METAGENOME_FILE); % requires Bioinforamtics toolbox -> canceled
IN_FASTA_METAGENOME = FASTAread(IN_FASTA_METAGENOME_FILE, [], [], COMMAND_LINE);

% Create HASH table
for i=1:length(IN_FASTA_METAGENOME)
    HEADER{i} =  IN_FASTA_METAGENOME(i).Header;
    SEQ{i}    =  IN_FASTA_METAGENOME(i).Sequence;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% v3.0.8 Remove sequenecs that are redudant
% [~, indx_vec] = unique(HEADER);
% if length(indx_vec)==length(HEADER)
%     fprintf('%s.m: No non-unique headers if FASTA file found\n',mfilename)
% else
%     fprintf('%s.m: Found %d non-unique headers if FASTA file found -> removing them\n',mfilename, length(HEADER)-length(indx_vec))
% end
% HEADER = HEADER(indx_vec);
% SEQ    = SEQ(indx_vec);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% IN_FASTA_METAGENOME_HASH = containers.Map(HEADER,SEQ);

if ~isdeployed; fprintf('Writing output file: %s\n\n',outfile); end

% PRINT JUST SHORT LIST OF EACH NCBI GENE REPRESENTATIVE FOR EACH NETWORK
fp3 = fopen(outfile,'w');

switch IN_MolType
    case 'prot'
        format1 = 'amino acids';
        format2 = 'aa';
    case 'nucl'
        format1 = 'nucleotides';
        format2 = 'nt';
end

if ~isdeployed; fprintf(    '%s\n\n',msg); end
fprintf(fp3,'%s\n\n',msg);

if ~isdeployed; fprintf(    'Index\tReference gene\tRepresentative contig\tSize of signature of reference gene\tSize of signature of reference gene cluster\t# of related reference genes\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tRepresentative contig length (%s)\tReference gene length (amino acids)\t %% of reference gene aligned\tRepresentative contig %s sequence\tRepresentative contig definition\tReference gene aa sequence\tReference gene definition', format1, format2); end
fprintf(fp3,'Index\tReference gene\tRepresentative contig\tSize of signature of reference gene\tSize of signature of reference gene cluster\t# of related reference genes\t %% identity\t# of identical amino acids\tE value\tAlignment length (amino acids)\tRepresentative contig length (%s)\tReference gene length (amino acids)\t %% of reference gene aligned\tRepresentative contig %s sequence\tRepresentative contig definition\tReference gene aa sequence\tReference gene definition', format1, format2);
if ~isdeployed; fprintf(     '\tGenPept GenBank division\tGenPept molecule type\tGenPept source\tGenPept classification\tGenPept comments\tGenPept Features\n'); end
fprintf(fp3, '\tGenPept GenBank division\tGenPept molecule type\tGenPept source\tGenPept classification\tGenPept comments\tGenPept Features\n');

if isempty(ST)
    fprintf(fp3,sprintf('No hits found\n'));
    fclose(fp3);
    return
end

% Sort RefSeqs by number of related contigs
[~, Ncontig_sort_ind] = sort(ST.N_contigs_vec);
Ncontig_sort_ind = fliplr(Ncontig_sort_ind);

for j=1:length(ST.N_contigs_vec)
    i= Ncontig_sort_ind(j);
    Reported_RefSeq = ST.Unique_phage_gene_vec{i};
    
    [best_Gene_len_vec,  best_Align_perc_of_gene_vec] = str_format(ST.best_Gene_len_vec(i),ST.best_Align_perc_of_gene_vec(i));
    
    % BEGIN CHANGE Aug 2019
    % After MCRL converges find reported RefSeq gene in original short
    % table list to extract total signature and number of related genes
    
    Total_sig     = ST.N_tot_contigs_in_network(i);
    Related_genes = length(ST.related_refseq_genes_TOT_array{i});
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % v3.0.8
    contig_name = ST.List_of_contigs{i}{1};
    % First try to find perfect match
    i_contig = find(strcmp(HEADER,contig_name));
    if length(i_contig)>=2
        Contig_seq         = 'non unique metagenome fasta record';
        Contig_len         = -1;
        Contig_description = 'N\A';
    else
        if length(i_contig)==1
            % done
            Contig_seq         = SEQ{i_contig};
            Contig_len         = length(Contig_seq);
            Contig_description = HEADER{i_contig};
        else
            % Not found -> Header may description not included in contig_name -> try to search for unique match using strfind
            i_contig_vec = [];
            found_arrray = strfind(HEADER, contig_name);
            for i_tmp = 1:length(HEADER)
                if ~isempty(found_arrray{i_tmp}) && found_arrray{i_tmp}==1
                    i_contig_vec = [i_contig_vec, i_tmp];
                end
            end
            
            if isempty(i_contig_vec) || length(i_contig_vec)>=2
                % failed
                Contig_seq         = 'metagenome fasta record not unique or not found';
                Contig_len         = -1;
                Contig_description = 'N\A';
            else
                % success
                Contig_seq         = SEQ{i_contig_vec};
                Contig_len         = length(i_contig_vec);
                Contig_description = HEADER{i_contig_vec};
            end
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % END CHANGE Aug 2019
    
    if ~isdeployed; fprintf(    '%d)\t%s\t%s\t%d\t%d\t%d\t%.1f\t%d\t%e\t%d\t%d\t%s\t%s\t%s\t%s\t%s\t%s',j,Reported_RefSeq, ST.List_of_contigs{i}{1}, ST.N_contigs_vec(i),Total_sig, Related_genes,ST.max_Percent_Ident_vec(i), ST.max_Number_of_Ident_vec(i),ST.min_E_value_vec(i), ST.best_Align_length_vec(i), Contig_len, best_Gene_len_vec,best_Align_perc_of_gene_vec, Contig_seq, Contig_description, ST.best_seq_vec{i},ST.best_description_vec{i}); end
                    fprintf(fp3,'%d)\t%s\t%s\t%d\t%d\t%d\t%.1f\t%d\t%e\t%d\t%d\t%s\t%s\t%s\t%s\t%s\t%s',j,Reported_RefSeq, ST.List_of_contigs{i}{1}, ST.N_contigs_vec(i),Total_sig, Related_genes,ST.max_Percent_Ident_vec(i), ST.max_Number_of_Ident_vec(i),ST.min_E_value_vec(i), ST.best_Align_length_vec(i), Contig_len, best_Gene_len_vec,best_Align_perc_of_gene_vec, Contig_seq, Contig_description, ST.best_seq_vec{i},ST.best_description_vec{i});
    
    if ~isdeployed; fprintf(    '\t%s\t%s\t%s\t%s\t%s\t%s\n',ST.LocusGenBankDivision{i}, ST.LocusMoleculeType{i} , ST.Source{i}, ST.SourceOrganism{i}, ST.Comment{i}, ST.Features{i}); end
                    fprintf(fp3,'\t%s\t%s\t%s\t%s\t%s\t%s\n',ST.LocusGenBankDivision{i}, ST.LocusMoleculeType{i} , ST.Source{i}, ST.SourceOrganism{i}, ST.Comment{i}, ST.Features{i});
    
end

fclose(fp3);
