function ST  = add_annotation_ST(ST,  ANNOTATION_HASH)
% <-- MCRL_MAIN.m

for j=1:length(ST.Unique_phage_gene_vec)
    reported_gene = ST.Unique_phage_gene_vec{j};
    ST.best_seq_vec{j}                = ANNOTATION_HASH.best_seq_vec(reported_gene);
    ST.best_description_vec{j}        = ANNOTATION_HASH.best_description_vec(reported_gene);
    ST.best_Gene_len_vec(j)           = ANNOTATION_HASH.best_Gene_len_vec(reported_gene);
    ST.LocusGenBankDivision{j}        = ANNOTATION_HASH.LocusGenBankDivision(reported_gene);
    ST.LocusMoleculeType{j}           = ANNOTATION_HASH.LocusMoleculeType(reported_gene);
    ST.Source{j}                      = ANNOTATION_HASH.Source(reported_gene);
    ST.SourceOrganism{j}              = ANNOTATION_HASH.SourceOrganism(reported_gene);
    ST.Comment{j}                     = ANNOTATION_HASH.Comment(reported_gene);
    ST.Features{j}                    = ANNOTATION_HASH.Features(reported_gene);
    gene_len                          = ANNOTATION_HASH.best_Gene_len_vec(reported_gene);
    ST.best_Align_perc_of_gene_vec(j) = ST.best_Align_length_vec(j)/gene_len*100;
end