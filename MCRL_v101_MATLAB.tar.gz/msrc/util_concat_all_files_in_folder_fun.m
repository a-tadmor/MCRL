function util_concat_all_files_in_folder_fun()

outfile = 'combined_all';

filenames = dir;
filenames = filenames(3:end);

f = 0;
for i=1:length(filenames)
    % skip source code in directory
    if isempty(strfind(filenames(i).name, 'util_concat_all_files_in_folder'))
        f=f+1;
        good_filenames{f} = filenames(i).name;
    end
end

fp_out = fopen(outfile,'w');

for i = 1:length(good_filenames)
    fprintf('combining file (%d/%d): %s\n',i,length(good_filenames),good_filenames{i});
    fp_in = fopen(good_filenames{i},'r');
    while ~feof(fp_in)
        next_line = fgets(fp_in);        
        if next_line(1) ~= -1
            fprintf(fp_out,'%s',next_line);
        end
    end
    fclose(fp_in);
end

fclose(fp_out);

