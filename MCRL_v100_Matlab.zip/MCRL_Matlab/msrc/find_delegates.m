function lowest_ST_or_FBHT_E_value_index_vec = find_delegates(related_hits_for_ith_hit, ST_or_FBHT)
% <--MCRL_MAIN.m

lowest_ST_or_FBHT_E_value_index_vec     = [];

% Find for each network the REFSEQ gene that has the lowest E value
for i = 1:length(related_hits_for_ith_hit)
    debug_b=0;
    i_net_vec   = related_hits_for_ith_hit{i}; % this list always includes self (i)
    
    best_val  = min( ST_or_FBHT.min_E_value_vec(i_net_vec) );
    j_vec    = find(ST_or_FBHT.min_E_value_vec(i_net_vec) == best_val);
    % could have more than one relative with the same minimal E value
    min_ind_vec  = i_net_vec(j_vec);
    
    if length(min_ind_vec)>1
        debug_b=1;
        % resolve multiple solutions by taking the one with the larger percent identity
        best_val  = max( ST_or_FBHT.max_Percent_Ident_vec(min_ind_vec) );
        j_vec    = find(ST_or_FBHT.max_Percent_Ident_vec(min_ind_vec) == best_val);
        % could have more than one relative with the same minal E value
        min_ind_vec  = min_ind_vec(j_vec);
    end
    if length(min_ind_vec)>1
        debug_b=2;
        % further resolve by taking the one with the largest number of identical amino acids in alignment
        best_val  = max( ST_or_FBHT.max_Number_of_Ident_vec(min_ind_vec) );
        j_vec    = find(ST_or_FBHT.max_Number_of_Ident_vec(min_ind_vec) == best_val);
        % could have more than one relative with the same minal E value
        min_ind_vec  = min_ind_vec(j_vec);
    end
    
    if length(min_ind_vec)>1
        % further resolve by taking the one with the largest percent of the RefSeq gene aligned (i.e. alignment length/gene length)
        best_val  = max( ST_or_FBHT.best_Align_perc_of_gene_vec(min_ind_vec) );
        j_vec    = find(ST_or_FBHT.best_Align_perc_of_gene_vec(min_ind_vec) == best_val);
        % could have more than one relative with the same minal E value;
        min_ind_vec  = min_ind_vec(j_vec);
        debug_b=3;
    end
    
    if length(min_ind_vec)>1
        debug_b=4;
        % probably two identical or nearly identical sequences - choose by gene id.
        % Since these genes will always be related (being identical/nearly identical) choosing by gene id will always elect the same delegate.
        [~, j_vec] = sort(ST_or_FBHT.Unique_phage_gene_vec(min_ind_vec));
        min_ind_vec = min_ind_vec(j_vec(1));
    end
    %if debug_b>0
    %    fprintf('%d->%d\n',i,debug_b);
    %end
    lowest_ST_or_FBHT_E_value_index_vec(i)= min_ind_vec;
end

fprintf('\n');
