function found_source = found_blast_sourcecode(BLAST_BIN_FOLDER)
global blast_ver

% Is correct version of BLAST installed and source code located
       
found_source = 0; % found blastp source code in BLAST_BIN_FOLDER

% check if BLAST_BIN_FOLDER exists
if exist(BLAST_BIN_FOLDER,'dir')==0
    %h=errordlg(sprintf('The specified path ''%s'' is not a valid folder',BLAST_BIN_FOLDER));
    %uiwait(h);
    return
end

% check if 'blastp' exists in bin folder (note: on some platforms blastp is added to the global path)
found_a_blastp = 0;
cur_path = pwd;
cd(BLAST_BIN_FOLDER);

% find out version of blastp
[stat, msg] = system(['.' filesep 'blastp -version']);

% find out if source code is installed
ext = ''; if ispc, ext='.exe'; end
if ~isempty(dir(['blastp' ext]))
    found_a_blastp = 1; %found blast source but not necessarily the right version
end

cd(cur_path);

% check if version is correct

if stat==0 && ~isempty(strfind(msg,blast_ver)) && found_a_blastp
    found_source =1;    
end

if stat==0 && isempty(strfind(msg,blast_ver)) && found_a_blastp
    h=warndlg(sprintf('BLAST source code is wrong version. Required version is %s',blast_ver));
    uiwait(h);
end

