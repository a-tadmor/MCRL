function A = get_hash(HASH,B)

C = HASH(B);
if ~iscell(C)
    A{1} = C;
else
    A    = C;
end