function badfilename = CheckIfFilenameIsIllegal(filename,action, COMMAND_LINE)
% should be legal for both UNIX and DOS. blast files can't have spaces for PCs

badfilename = 0;
if ~exist('action','var')
    action = [];
end

if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

x=filename;

if (isempty(x) || isempty(strtrim(x))) && ~strcmp(action, 'output')
    if ~COMMAND_LINE
        h=errordlg('File name cannot be blank');
        uiwait(h)
    else
        error('File name cannot be blank');
    end
    badfilename = 1;
    return
end

if strcmp(action, 'output') && isempty(x)
    return
end

if strcmp(action,'blast')
    badfilename = max(x==')' | x=='(' | x=='^' | x=='#' | x=='@' | x=='!' | x=='"' | x=='*' | x=='/' | x==':' | x=='<' | x=='>' | x=='?' | x=='\' | x=='|' | x=='%' | x==';' | x=='&' | x==' ');
else
    badfilename = max(x==')' | x=='(' | x=='^' | x=='#' |x=='@' | x=='!' | x=='"' | x=='*' | x=='/' | x==':' | x=='<' | x=='>' | x=='?' | x=='\' | x=='|' | x=='%' | x==';' | x=='&');
end

badfilename = badfilename | x(1)=='.' | x(1)=='-' | x(end)=='.';

if badfilename
    % invalid entry
    if strcmp(action,'blast')
        if ~COMMAND_LINE
            h=errordlg('Bad file name: filename cannot include the following characters: ( ) ^ # @ ! " * / : < > ? \ | % ; & space');
        else
            error('Bad file name: filename cannot include the following characters: ( ) ^ # @ ! " * / : < > ? \\ | %% ; & space');
        end
    else
        if ~COMMAND_LINE
            h=errordlg('Bad file name: filename cannot include the following characters: ( ) ^ # @ ! " * / : < > ? \ | % ; &');
        else
            error('Bad file name: filename cannot include the following characters:  ( ) ^ # @ ! " * / : < > ? \\ | %% ; &');
        end
    end
    if ~COMMAND_LINE, uiwait(h); end
    return
end