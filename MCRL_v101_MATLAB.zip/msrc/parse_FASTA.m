function [FILE_PARSE, FILE_PARSE_ARRAY] = parse_FASTA(FASTA_filename)
% Return the header and location of the start of all records (i.e. '>')

FILE_PARSE = [];
FILE_PARSE_ARRAY={};

fid  = fopen(FASTA_filename,'r');

if fid==-1
    fprintf('%s.m Error: cannot open FASTA file ''%s''\n',mfilename,FASTA_filename);
    keyboard
end

line = fgetl(fid);

last_record_count = -1;
record_count      = 0;
last_location     = 0;
% ttt               = 0;

PROGRESS_STRING='';
while ~feof(fid) 
    % Print counter to screen
    if record_count/1e4 == round(record_count/1e4) && record_count>last_record_count && record_count>0
        for i_timer=1:length(PROGRESS_STRING); fprintf('\b'); end
        PROGRESS_STRING = sprintf('%d genes read...',record_count);
        %ttt=ttt+1; if ttt ==4, fprintf('\n'); ttt=0; end
        fprintf('%s',PROGRESS_STRING);
        last_record_count = record_count;
    end
    
    % Find the next record
    if  ~isempty(strfind(line,'>'))
        record_count = record_count +1;
        FILE_PARSE(record_count).Header         = line;           % Entire header of record
        FILE_PARSE_ARRAY{record_count}          = line;
        FILE_PARSE(record_count).RecordLocation = last_location;  % File location of header
    end
    last_location = ftell(fid);
    line = fgetl(fid);
end
fprintf('done.\n')
fclose(fid);