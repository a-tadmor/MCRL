function [best_Gene_len_vec_out,  best_Align_perc_of_gene_vec_out] =  str_format(best_Gene_len_vec_in,  best_Align_perc_of_gene_vec_in)

if best_Gene_len_vec_in==-1
    best_Gene_len_vec_out = 'N/A';
else
    best_Gene_len_vec_out = sprintf('%d',best_Gene_len_vec_in);
end

if best_Align_perc_of_gene_vec_in==-1
    best_Align_perc_of_gene_vec_out = 'N/A';
else
    best_Align_perc_of_gene_vec_out = sprintf('%.1f',best_Align_perc_of_gene_vec_in);
end