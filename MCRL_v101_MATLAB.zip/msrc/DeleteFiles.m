function DeleteFiles(files)
% <-- main_gui2.m

for i=1:length(files)
    fprintf(' --> deleting temporary file %s\n', files{i})
    delete(files{i});
end