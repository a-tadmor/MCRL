function  [FILE_PARSE, FILE_PARSE_ARRAY] = parse_GENPEPT(genpeptfile)
% Find location value of 'Version' fields 

FILE_PARSE = [];
FILE_PARSE_ARRAY={};
fid  = fopen(genpeptfile,'r');
if fid==-1
    fprintf('%s debug: cannot open GenPept file ''%s''\n',mfilename,genpeptfile);
    keyboard
end

line = fgetl(fid);
last_record_count = -1;
record_count = 0;
last_location = 0;
% ttt=0;

PROGRESS_STRING='';
while ~feof(fid)
    if record_count/1e4 == round(record_count/1e4) && record_count>last_record_count && record_count>0
        for i_timer=1:length(PROGRESS_STRING); fprintf('\b'); end
        PROGRESS_STRING = sprintf('%d genes read...',record_count);
        % ttt=ttt+1; if ttt ==4, fprintf('\n'); ttt=0; end
        fprintf('%s',PROGRESS_STRING);
        last_record_count = record_count;
    end
    % Find next VERSION field
    L = length(line);
    line10 = line(1:min([L,10]));
    if ~isempty(strfind(line10,'VERSION'))
        [s,f,t] = regexp(line,'VERSION\s+(\w|\W)+');  %#ok
        rmdr = line(t{1}(1):t{1}(2));
        GIPos = strfind(rmdr,'GI:');
        if ~isempty(GIPos)
            Version = strtrim(rmdr(1:GIPos-1));
        else
            Version = strtrim(rmdr);
        end
        record_count = record_count +1;
       % NOTE: According to RefSeq release notes "The GI and "ACCESSION.VERSION"  identifiers provide the finest resolution reference to a sequence"
        FILE_PARSE(record_count).Version                          = Version;       % Version field
        
        % Search for Version in gene_id
        % NOTE: According to RefSeq release notes "The GI and
        % "ACCESSION.VERSION"  identifiers provide the finest resolution reference to a sequence",
        FILE_PARSE_ARRAY{record_count}                            = Version;                         % v3.0.13
        FILE_PARSE(record_count).RecordLocation                   = last_location; % File location of Version field
    end
    last_location = ftell(fid);
    line = fgetl(fid);
end
fprintf('done.\n')
fclose(fid);
