function it_is_linux = islinux()

it_is_linux = 0;
if strcmp(computer,'GLNX86') || strcmp(computer,'GLNXA64')
    it_is_linux  = 1;
end