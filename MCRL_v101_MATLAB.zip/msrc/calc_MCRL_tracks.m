function [MEGA_TRACK, EDGE_MAT, LUT_NODE] = calc_MCRL_tracks(signature_HASH0, relatedgenes_HASH_ITI1)
% <-- plot_network.m

% All delegates (elected reference genes in first iteration) with E<Eth
reference_gene_delegates_vec = keys(relatedgenes_HASH_ITI1);

% All reference genes with E<Eth
RefSeq_seq_vec_ALL = keys(signature_HASH0); % all RefSeq_cur genes with E val < Eth

% Create node LUT:
% Create scalar look up table for all reference genes with E<Eth to be the nodes in the network
LUT_NODE = containers.Map(RefSeq_seq_vec_ALL, [1:length(RefSeq_seq_vec_ALL)]);
if length(RefSeq_seq_vec_ALL)~=length(unique(RefSeq_seq_vec_ALL)), keyboard; end

TIMER='0.0% ...';
fprintf('Percent completed: %s', TIMER);

z=0;
doublecheck_reported_ref_gene={};
for i=1:length(RefSeq_seq_vec_ALL)
    if i/100==round(i/100)
         for i_timer=1:length(TIMER); fprintf('\b'); end
        TIMER = sprintf('%.1f%%...',i/length(RefSeq_seq_vec_ALL)*100);
        fprintf('%s',TIMER);
    end
    
    RefSeq_cur = RefSeq_seq_vec_ALL{i};
    END_TRACK=0;
    
    % Track always starts with current reference gene
    track  = {RefSeq_cur};
    
    while ~END_TRACK
        % Who does RefSeq_cur elect?
        
        % Search for a reference gene cluster (before compressing) that this gene belongs to
        found=0;
        for j=1:length(reference_gene_delegates_vec)
            RefSeq_delegate_j = reference_gene_delegates_vec{j};
            if ~isempty(intersect(relatedgenes_HASH_ITI1(RefSeq_delegate_j),RefSeq_cur)) % HASH list for each delegate contains all related genes in cluster but not the delegate itself
                found=1;
                break;
                % Note: a reference gene will appear only once in a all clusters  (the gene list under "table2")
            end
        end
        if ~found
            % RefSeq_cur does elect anyone. Is therefore must have been
            % elected, othewise there is a bug !
            if ~isempty(intersect(RefSeq_cur, reference_gene_delegates_vec)) % (a delegate can be elected by any reference genes, therefore it can appear many times in reference_gene_delegates_vec) 
                % This reference gene did not elect anyone, therefore it is
                % a reported reference gene !
                END_TRACK = 1;
            else
                % bug
                keyboard
            end
            
            % Track ended here
            if length(track)==1 % Track started and ended with this reference gene: reference gene elected itself ! (Maybe other genes also elected it). Reported reference genes will always be in this catagory because by definition they dont elect anybody else)
                z=z+1; EDGE_MAT(z,:) = [LUT_NODE(RefSeq_cur), LUT_NODE(RefSeq_cur)];
                doublecheck_reported_ref_gene  = [doublecheck_reported_ref_gene RefSeq_cur];
            end
        else
            % add to track elected reference gene (i.e., delegate)
            track = [track, RefSeq_delegate_j];
            
            % add new edge: RefSeq_cur->RefSeq_delegate_j
            z=z+1; EDGE_MAT(z,:) = [LUT_NODE(RefSeq_cur), LUT_NODE(RefSeq_delegate_j)];
            
            % Current gene because new delegate
            RefSeq_cur = RefSeq_delegate_j;
        end
    end
    
%                 fprintf('%d)\t%.1f%%\t%d\t%s', i, i/length(RefSeq_seq_vec_ALL)*100, length(track), track{1});
    if length(track)>1
        for m=2:length(track)
%                         fprintf(' -> %s', track{m});
        end
    end
%     fprintf('\t==>\t%s\n',track{end})
    MEGA_TRACK{i} = track;
end

for i_timer=1:length(TIMER); fprintf('\b'); end
fprintf('100%% done.\n');
