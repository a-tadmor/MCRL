function ANNOTATION_HASH = get_annotation_for_reported_genes(CFBHT, FILE_PARSE, FILE_PARSE_ARRAY, IN, COMMAND_LINE)
% <-- MCRL_MAIN.m

gene_id_array       = CFBHT.gene_id;
reported_gene_array = CFBHT.Unique_phage_gene_vec;

TIMER='0.0% ...';
fprintf('Percent completed: %s', TIMER);

for ig=1:length(gene_id_array)
    
    if ig/100==round(ig/100)
        for i_timer=1:length(TIMER); fprintf('\b'); end
        TIMER = sprintf('%.1f%%...',ig/length(gene_id_array)*100);
        fprintf('%s',TIMER);
    end
    
    gene_id = gene_id_array{ig};
    
    % Find location of this gene's record in the FASTA or GenPept file (doing it in the main is more memory efficient)
    % Find location of this gene's record in the FASTA or GenPept file (doing it in the main is more memory efficient)
    found = 0;
    rec=find(contains(FILE_PARSE_ARRAY,gene_id));
    if ~isempty(rec)
        found=1;
        rec=rec(1);
    end

    if isempty(IN.GENPEP_REFSEQ_FILE)
        % FASTA FILE SUPPLIED
        if ~found
            errmsg=sprintf('gene ID ''%s'' was not found in: %s\n', gene_id, IN.FASTA_REFSEQ_FILE);
            fprintf('%s\n',errmsg);
            if ~COMMAND_LINE
                h=errordlg(errmsg);
                uiwait(h);
                error(errmsg)
            else
                error(errmsg);
            end
            keyboard
        end
        OUT  = obtain_description_FASTA(IN.FASTA_REFSEQ_FILE,FILE_PARSE(rec).RecordLocation,gene_id);
    else % GENPEPT FILE SUPPLIED
        if ~found
            errmsg=sprintf('\ngene ID ''%s'' was not found in: %s\n',gene_id, IN.GENPEP_REFSEQ_FILE);
            fprintf('%s\n',errmsg);
            if ~COMMAND_LINE
                h=errordlg(errmsg);
                uiwait(h);
                error(errmsg)
            else
                error(errmsg);
            end
            keyboard
        end
        if rec==1
            StartOfRecord = 0;
            StartSearchFrom = []; % don't need this
        else
            StartOfRecord = []; % will need to find this
            StartSearchFrom = FILE_PARSE(rec-1).RecordLocation; % file location of last Version field - start search from here
        end
        OUT  = obtain_description_GENPEPT(IN.GENPEP_REFSEQ_FILE,StartSearchFrom,StartOfRecord);
    end
    
    
    gene_len(ig)             = OUT.gene_len;
    Sequence{ig}             = OUT.Sequence;
    Definition{ig}           = OUT.Definition;
    LocusGenBankDivision{ig} = OUT.LocusGenBankDivision;
    LocusMoleculeType{ig}    = OUT.LocusMoleculeType;
    Source{ig}               = OUT.Source;
    SourceOrganism{ig}       = OUT.SourceOrganism;
    Comment{ig}              = OUT.Comment;
    Features{ig}             = OUT.Features;
end

for i_timer=1:length(TIMER); fprintf('\b'); end
fprintf('100%% done.\n');

ANNOTATION_HASH.best_Gene_len_vec    = containers.Map(reported_gene_array, gene_len);
ANNOTATION_HASH.best_seq_vec         = containers.Map(reported_gene_array, Sequence);
ANNOTATION_HASH.best_description_vec = containers.Map(reported_gene_array, Definition);
ANNOTATION_HASH.LocusGenBankDivision = containers.Map(reported_gene_array, LocusGenBankDivision);
ANNOTATION_HASH.LocusMoleculeType    = containers.Map(reported_gene_array, LocusMoleculeType);
ANNOTATION_HASH.Source               = containers.Map(reported_gene_array, Source);
ANNOTATION_HASH.SourceOrganism       = containers.Map(reported_gene_array, SourceOrganism);
ANNOTATION_HASH.Comment              = containers.Map(reported_gene_array, Comment);
ANNOTATION_HASH.Features             = containers.Map(reported_gene_array, Features);


