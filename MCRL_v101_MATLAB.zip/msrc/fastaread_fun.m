function FASTA_out = fastaread_fun(FASTA_filename, MODE, DESIRED_RECORD, COMMAND_LINE)
%<-- FASTAread.m

FASTA_out = [];
fid  = fopen(FASTA_filename,'r');

if fid==-1
    empty_seq_error(FASTA_filename, COMMAND_LINE);
end


last_record_count      = -1;
record_count           = 0;
% ttt                    = 0;
DESIRED_RECORD_REACHED = 0;
IN_RECORD              = 0;

line = fgetl(fid);
while 1 
    % Print counter to screen
    if record_count/1e4 == round(record_count/1e4) && record_count>last_record_count && record_count>0
        fprintf('%s.m: %d genes read...\n',mfilename, record_count);
%         ttt=ttt+1; if ttt ==4, fprintf('\n'); ttt=0; end
        last_record_count = record_count;
    end
    
    if IN_RECORD
        if ~isempty(strfind(line,'>'))
            if isempty(FASTA(record_count).Sequence)
                % Reach next record but prev sequence not provided
                empty_seq_error(FASTA_filename, COMMAND_LINE);
            else
                % Reached next record
                IN_RECORD = 0;
            end
        else
            % get sequence
            SEQ = strtrim(line);
            check_seq(SEQ, FASTA_filename, COMMAND_LINE);
            if ~isempty(SEQ)
                FASTA(record_count).Sequence = [FASTA(record_count).Sequence, SEQ];
            end
        end
    end
    
    % Find the next record
    if  ~isempty(strfind(line,'>'))
        if IN_RECORD
            % reached next record but previous record not ended
            fprintf('%s.m Error: FASTA file ''%s'' invalid state\n',mfilename,FASTA_filename);
            keyboard
        end
        
        % Blockread mode: Desired record reached?
        if strcmp(MODE, 'Blockread') && DESIRED_RECORD_REACHED  
            FASTA_out = FASTA(DESIRED_RECORD);
            return
        end
        
        % Start next record
        record_count = record_count +1;
        HEADER = line(2:end);
        check_header(strtrim(HEADER), FASTA_filename, COMMAND_LINE);
        
        FASTA(record_count).Header         = HEADER; % Entire header of record
        FASTA(record_count).Sequence       = [];   % Initialize sequence
        IN_RECORD = 1;
        
        if strcmp(MODE, 'Blockread') && record_count==DESIRED_RECORD
           DESIRED_RECORD_REACHED = 1; 
        end
    end
    if ~ischar(line) || feof(fid), break, end
    line = fgetl(fid);
end
fclose(fid);

if isempty(FASTA(record_count).Sequence)
    % Reach next record but prev sequence not provided
  empty_seq_error(FASTA_filename, COMMAND_LINE)
end

if record_count==DESIRED_RECORD && strcmp(MODE, 'Blockread')
    FASTA_out = FASTA(DESIRED_RECORD);
    return
end

FASTA_out = FASTA;


