function FASTAwrite(FASTA_filename, F, COMMAND_LINE)
% Return the header and location of the start of all records (i.e. '>')

if ~exist('COMMAND_LINE','var') || exist('COMMAND_LINE','var') && isempty(COMMAND_LINE)
    COMMAND_LINE = 0;
end

fid=fopen(FASTA_filename,'w');

if fid==-1
    fprintf('%s.m Error: Cannot create file to write ''%s''\n',mfilename,FASTA_filename);
    if ~COMMAND_LINE
        h=warndlg(sprintf('Cannot create file to write ''%s''',FASTA_filename),'Notice');
        uiwait(h);
        error('Cannot create file to write ''%s''', FASTA_filename);
    else
        error('Cannot create file to write ''%s''', FASTA_filename);
    end
    keyboard
end

for i=1:length(F)
    fprintf(fid, '>%s\n',F(i).Header); 
    fprintf(fid, '%s\n',F(i).Sequence);
end
fclose(fid);


