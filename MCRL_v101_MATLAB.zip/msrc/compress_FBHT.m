function CFBHT = compress_FBHT(ST, FBHT)
% <-- MCRL_MAIN.m

[~, Ncontig_sort_ind] = sort(ST.N_contigs_vec); 
Ncontig_sort_ind = fliplr(Ncontig_sort_ind);

for j=1:length(ST.N_contigs_vec)
    i= Ncontig_sort_ind(j);
    Reported_RefSeq = ST.Unique_phage_gene_vec{i};
    indx = find(strcmp(FBHT.Unique_phage_gene_vec,Reported_RefSeq));
    
    if isempty(indx)
        fprintf('%s.m: error\n', mfilename)
        keyboard
    end
    
    CFBHT.gene_id{j}                              = FBHT.gene_id{indx};   % v3.0.13
    
    CFBHT.Unique_phage_gene_vec{j}                = Reported_RefSeq;
    CFBHT.best_seq_vec{j}                         = FBHT.best_seq_vec{indx};
    CFBHT.best_description_vec{j}                 = FBHT.best_description_vec{indx};

    CFBHT.best_Align_length_vec(j)                = FBHT.best_Align_length_vec(indx);
    CFBHT.N_contigs_vec(j)                        = FBHT.N_contigs_vec(indx);
    CFBHT.best_Gene_len_vec(j)                    = FBHT.best_Gene_len_vec(indx);
    CFBHT.best_Align_perc_of_gene_vec(j)          = FBHT.best_Align_perc_of_gene_vec(indx);
    CFBHT.N_contigs_vec(j)                        = FBHT.N_contigs_vec(indx);
    CFBHT.max_Percent_Ident_vec(j)                = FBHT.max_Percent_Ident_vec(indx);
    CFBHT.max_Number_of_Ident_vec(j)              = FBHT.max_Number_of_Ident_vec(indx);
    CFBHT.min_E_value_vec(j)                      = FBHT.min_E_value_vec(indx);
    
    for t=1:length(FBHT.List_of_contigs{indx})
        CFBHT.List_of_contigs{j}{t}              = FBHT.List_of_contigs{indx}{t};
    end

 
end

