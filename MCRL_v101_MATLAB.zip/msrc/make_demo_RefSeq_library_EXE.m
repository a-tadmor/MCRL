% clear all
% Create FASTA and GenPept files for first 1000 records for input RefSeq library
% Genes required for demo_contigs.faa
DEBUG=1;
Add_these_RefSeqGenes = {'YP_009238667.1'
    'YP_009249960.1'
    'YP_009254947.1'
    'YP_009148880.1'
    'YP_009173733.1'
    'YP_009177448.1'
    'YP_009182312.1'
    'YP_009186748.1'
    'YP_009197488.1'
    'YP_009210054.1'
    'YP_009217831.1'
    'YP_009225645.1'
    'YP_009345567.1'
    'YP_009001498.1'
    'YP_009325868.1'
    'YP_009330243.1'
    'YP_009011090.1'
    'YP_009015548.1'
    'YP_009015602.1'
    'YP_009015055.1'
    'YP_006383099.1'
    'YP_006908627.1'
    'YP_006987101.1'
    'YP_007006388.1'
    'YP_009031126.1'
    'YP_007392492.1'
    'YP_009042324.1'
    'YP_009049868.1'
    'YP_008052628.1'
    'YP_008052747.1'
    'YP_009091959.1'
    'YP_009094648.1'
    'YP_008530464.1'
    'YP_009111221.1'
    'YP_009120282.1'
    'YP_009121907.1'
    'YP_008770526.1'
    'YP_008771337.1'
    'YP_009133285.1'
    'YP_009046811.1'
    'YP_803305.1'
    'YP_001110973.1'
    'YP_002290892.1'
    'YP_009329269.1'
    'YP_009329403.1'
    'YP_001651017.1'
    'YP_009189062.1'
    'YP_009151486.1'
    'YP_009187616.1'
    'YP_009152818.1'
    'NP_148910.1'
    'YP_004732823.1'
    'YP_008004627.1'
    'YP_654526.1'
    'NP_689201.1'
    'NP_663278.1'
    'NP_872562.1'
    'YP_001257069.1'
    'NP_891963.1'
    'YP_009165351.1'
    'NP_047686.1'
    'YP_001649129.1'
    'NP_059294.1'
    'YP_003429432.1'
    'YP_003517787.1'
    'YP_851174.1'
    'YP_004347016.1'
    'YP_003406906.1'
    'YP_003422492.1'
    'YP_293894.1'
    'YP_009010399.1'
    'YP_009010638.1'
    'YP_009010863.1'
    'YP_004893810.1'
    'YP_002003734.1'
    'NP_068326.1'
    'YP_004957306.1'
    'NP_149493.1'
    'YP_008357395.1'
    'YP_008004327.1'
    'YP_654678.1'
    'YP_009506054.1'
    'YP_009506213.1'
    'YP_009506810.1'
    'YP_009513161.1'
    'YP_008437119.1'
    'YP_009345848.1'
    'YP_009591141.1'
    'YP_009593537.1'
    'YP_009594055.1'
    'YP_009595586.1'
    'YP_009595951.1'
    'YP_009602434.1'
    'YP_009215975.1'
    'YP_009099171.1'
    'YP_009216194.1'
    'YP_008770106.1'
    'YP_008772112.1'
    'YP_002300444.1'
    'YP_002300482.1'
    'YP_008319141.1'
    'YP_009480977.1'
    'YP_009481925.1'
    'YP_009483059.1'
    'YP_009701593.1'
    'YP_009702129.1'
    'YP_008857219.1'
    };
MAX_REC = 1000;
% FASTA file
fprintf('Loading FASTA file...\n')
F=fastaread('..\RefSeq_database\viral_RefSeq_release99.faa');

G=F(1:MAX_REC);

count_record1=0;

if ~DEBUG
    c=MAX_REC;
    for i=MAX_REC+1:length(F)
        R = F(i).Header;
        is = find(R==' ');
        R = R(1:is(1)-1);
        if ~isempty(intersect(R, Add_these_RefSeqGenes))
            count_record1=count_record1+1;
            fprintf('count_record in fasta=%d/%d\n',count_record1, length(Add_these_RefSeqGenes));
            c=c+1;
            G(c).Header   = F(i).Header;
            G(c).Sequence = F(i).Sequence;
        end
    end
    
    fprintf('Writing first %d FASTA file records for fasta file (found %d records from list)...\n', c, count_record1)
    
    fastawrite('..\RefSeq_database\demo_reference_library.faa', G);
end

% GenPept file
for i=1:length(Add_these_RefSeqGenes)
    RefSeq = Add_these_RefSeqGenes{i};
    id=find(RefSeq=='.');
    Add_these_RefSeqGenes_LOCUS{i} = RefSeq(1:id(end)-1);
end
fp_in=fopen('..\RefSeq_database\viral_RefSeq_release99.gpff','r');
fp_out=fopen('..\RefSeq_database\demo_reference_library.gpff','w');

END_RECORD=0;
end_rec_MAX_REC = F(MAX_REC).Header;
is=find(end_rec_MAX_REC==' ');
end_rec_MAX_REC = end_rec_MAX_REC(1:is(1)-1);

fprintf('Writing first 1000 FASTA file records for gpff file...\n')

count_record2=0;
PHASE2=0;
IN_RECORD=0;
while 1
    tline = fgetl(fp_in);
    if ~PHASE2
        % write first 1000 records
        fprintf(fp_out,'%s\n',tline);
    end
    
    if strfind(tline, end_rec_MAX_REC)
        END_RECORD = 1;
    end
    
    if END_RECORD && strcmp(tline, '//')
        PHASE2=1;
    end
    
    if PHASE2 && length(tline)>13 && strcmp(tline(1:5), 'LOCUS')
        t=tline(13:end);
        s_vec=find(t==' ');
        LOCUS = t(1:s_vec(1)-1);
        if ~isempty(intersect(Add_these_RefSeqGenes_LOCUS, LOCUS))
            count_record2=count_record2+1;
            fprintf('count_record in gpff=%d/%d\n',count_record2, length(Add_these_RefSeqGenes));
            IN_RECORD=1;
        end
    end
    
    if PHASE2 && IN_RECORD
        fprintf(fp_out,'%s\n',tline);
    end
    
    if PHASE2 && IN_RECORD && strcmp(tline, '//')
        IN_RECORD=0;
        if count_record2==length(Add_these_RefSeqGenes)
            % Finished list. Exit.
            break
        end
    end
    
end
fclose(fp_in);
fclose(fp_out);
fprintf('found %d records in gpff file\n',count_record2);

% convert to MAT file
% clear all
% Create FASTA and GenPept files for first 1000 records for input RefSeq library
% Genes required for demo_contigs.faa
DEBUG=1;
Add_these_RefSeqGenes = {'YP_009238667.1'
    'YP_009249960.1'
    'YP_009254947.1'
    'YP_009148880.1'
    'YP_009173733.1'
    'YP_009177448.1'
    'YP_009182312.1'
    'YP_009186748.1'
    'YP_009197488.1'
    'YP_009210054.1'
    'YP_009217831.1'
    'YP_009225645.1'
    'YP_009345567.1'
    'YP_009001498.1'
    'YP_009325868.1'
    'YP_009330243.1'
    'YP_009011090.1'
    'YP_009015548.1'
    'YP_009015602.1'
    'YP_009015055.1'
    'YP_006383099.1'
    'YP_006908627.1'
    'YP_006987101.1'
    'YP_007006388.1'
    'YP_009031126.1'
    'YP_007392492.1'
    'YP_009042324.1'
    'YP_009049868.1'
    'YP_008052628.1'
    'YP_008052747.1'
    'YP_009091959.1'
    'YP_009094648.1'
    'YP_008530464.1'
    'YP_009111221.1'
    'YP_009120282.1'
    'YP_009121907.1'
    'YP_008770526.1'
    'YP_008771337.1'
    'YP_009133285.1'
    'YP_009046811.1'
    'YP_803305.1'
    'YP_001110973.1'
    'YP_002290892.1'
    'YP_009329269.1'
    'YP_009329403.1'
    'YP_001651017.1'
    'YP_009189062.1'
    'YP_009151486.1'
    'YP_009187616.1'
    'YP_009152818.1'
    'NP_148910.1'
    'YP_004732823.1'
    'YP_008004627.1'
    'YP_654526.1'
    'NP_689201.1'
    'NP_663278.1'
    'NP_872562.1'
    'YP_001257069.1'
    'NP_891963.1'
    'YP_009165351.1'
    'NP_047686.1'
    'YP_001649129.1'
    'NP_059294.1'
    'YP_003429432.1'
    'YP_003517787.1'
    'YP_851174.1'
    'YP_004347016.1'
    'YP_003406906.1'
    'YP_003422492.1'
    'YP_293894.1'
    'YP_009010399.1'
    'YP_009010638.1'
    'YP_009010863.1'
    'YP_004893810.1'
    'YP_002003734.1'
    'NP_068326.1'
    'YP_004957306.1'
    'NP_149493.1'
    'YP_008357395.1'
    'YP_008004327.1'
    'YP_654678.1'
    'YP_009506054.1'
    'YP_009506213.1'
    'YP_009506810.1'
    'YP_009513161.1'
    'YP_008437119.1'
    'YP_009345848.1'
    'YP_009591141.1'
    'YP_009593537.1'
    'YP_009594055.1'
    'YP_009595586.1'
    'YP_009595951.1'
    'YP_009602434.1'
    'YP_009215975.1'
    'YP_009099171.1'
    'YP_009216194.1'
    'YP_008770106.1'
    'YP_008772112.1'
    'YP_002300444.1'
    'YP_002300482.1'
    'YP_008319141.1'
    'YP_009480977.1'
    'YP_009481925.1'
    'YP_009483059.1'
    'YP_009701593.1'
    'YP_009702129.1'
    'YP_008857219.1'
    };
MAX_REC = 1000;
% FASTA file
fprintf('Loading FASTA file...\n')
F=fastaread('..\RefSeq_database\viral_RefSeq_release99.faa');

G=F(1:MAX_REC);

count_record1=0;

if ~DEBUG
    c=MAX_REC;
    for i=MAX_REC+1:length(F)
        R = F(i).Header;
        is = find(R==' ');
        R = R(1:is(1)-1);
        if ~isempty(intersect(R, Add_these_RefSeqGenes))
            count_record1=count_record1+1;
            fprintf('count_record in fasta=%d/%d\n',count_record1, length(Add_these_RefSeqGenes));
            c=c+1;
            G(c).Header   = F(i).Header;
            G(c).Sequence = F(i).Sequence;
        end
    end
    
    fprintf('Writing first %d FASTA file records for fasta file (found %d records from list)...\n', c, count_record1)
    
    fastawrite('..\RefSeq_database\demo_reference_library.faa', G);
end

% GenPept file
for i=1:length(Add_these_RefSeqGenes)
    RefSeq = Add_these_RefSeqGenes{i};
    id=find(RefSeq=='.');
    Add_these_RefSeqGenes_LOCUS{i} = RefSeq(1:id(end)-1);
end
fp_in=fopen('..\RefSeq_database\viral_RefSeq_release99.gpff','r');
fp_out=fopen('..\RefSeq_database\demo_reference_library.gpff','w');

END_RECORD=0;
end_rec_MAX_REC = F(MAX_REC).Header;
is=find(end_rec_MAX_REC==' ');
end_rec_MAX_REC = end_rec_MAX_REC(1:is(1)-1);

fprintf('Writing first 1000 FASTA file records for gpff file...\n')

count_record2=0;
PHASE2=0;
IN_RECORD=0;
while 1
    tline = fgetl(fp_in);
    if ~PHASE2
        % write first 1000 records
        fprintf(fp_out,'%s\n',tline);
    end
    
    if strfind(tline, end_rec_MAX_REC)
        END_RECORD = 1;
    end
    
    if END_RECORD && strcmp(tline, '//')
        PHASE2=1;
    end
    
    if PHASE2 && length(tline)>13 && strcmp(tline(1:5), 'LOCUS')
        t=tline(13:end);
        s_vec=find(t==' ');
        LOCUS = t(1:s_vec(1)-1);
        if ~isempty(intersect(Add_these_RefSeqGenes_LOCUS, LOCUS))
            count_record2=count_record2+1;
            fprintf('count_record in gpff=%d/%d\n',count_record2, length(Add_these_RefSeqGenes));
            IN_RECORD=1;
        end
    end
    
    if PHASE2 && IN_RECORD
        fprintf(fp_out,'%s\n',tline);
    end
    
    if PHASE2 && IN_RECORD && strcmp(tline, '//')
        IN_RECORD=0;
        if count_record2==length(Add_these_RefSeqGenes)
            % Finished list. Exit.
            break
        end
    end
    
end
fclose(fp_in);
fclose(fp_out);
fprintf('found %d records in gpff file\n',count_record2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% convert to a MAT file
F_ref_fasta = fastaread('..\RefSeq_database\demo_reference_library.faa');
fid=fopen('..\RefSeq_database\demo_reference_library.gpff');
i=0;
while 1
    tline = fgetl(fid);
    if ~ischar(tline), break, end
    i=i+1;
    F_ref_gpff{i} = tline;
end
fclose(fid);

save('demo_reference_library','F_ref_gpff','F_ref_fasta');

