function [percent_min, percent_max] = calc_percent_identical_contigs_faster(list1, list2)
% <-- find_related_genes.m, write_RelatedGenesTable.m
% Determine percent identity between two lists .
% Note that percent (output) is symetric with respect to list1 and list2:
%
% calc_percent_identical_contigs_faster(list1, list2) = calc_percent_identical_contigs_faster(list2, list1)

L1=length(list1);
L2=length(list2);
if min([L1,L2])>=20
    % faster for long signatures
    matches = length(intersect(list1, list2));
else
    % faster for short signatures
    matches = 0;
    for i = 1:L1
        debug_counter_same_entries=0;
        for j = 1:L2
            if strcmp(list1{i},list2{j})
                matches = matches + 1;
                debug_counter_same_entries = debug_counter_same_entries + 1;
            end
        end
        if debug_counter_same_entries>1
            % debug_counter_same_entries should always be 0 or 1
            error('Problem in %s.m: multiple identical entries in contig list', mfilename);
            keyboard
        end
    end
end


% symmetric/stringent overlap
percent_min = min([matches/L1*100, matches/L2*100]); % Require that the contig overlap with respect to both genes exceeds the threshold
% asymmetric/inclusive overlap
percent_max = max([matches/L1*100, matches/L2*100]);

