function  [relatedgenes_HASH, TOT_relatedgenes_EVAL_HASH, Delegate_Eval_HASH] = parse_relatedGenes(MCRL_RelatedGenes)
%  <-- plot_network.m

fid=fopen(MCRL_RelatedGenes);

tab=sprintf('\t');

fprintf('Parsing all related reference genes ');
counter=0;
TOT_counter=0;
tline = fgetl(fid);
while 1
    if length(tline)>5 && strcmp(tline(1:6),'table1')
        counter=counter+1;
        if counter/1000 == round(counter/1000), fprintf('.'); end
        % Parse RefSeq gene
        it=find(tline==tab);
        RefSeq_gene = tline(it(2)+1:it(3)-1);
        Delegate_Eval = str2num(tline(it(9)+1:it(10)-1));
        
        tline = fgetl(fid); % skip header
        tline = fgetl(fid); % skip header
        
        END=0;
        related = {};
        Eval    = [];
        while ~END
            if length(tline)>6 && strcmp(tline(1:6),'table2') 
                it=find(tline==tab);
                related_RefSeq = tline(it(2)+1:it(3)-1);
                related = [related related_RefSeq];
                Eval_RefSeq = str2num(tline(it(9)+1:it(10)-1));
                Eval    =  [Eval   Eval_RefSeq]; 
                
                TOT_counter=TOT_counter+1;
                
                TOT_RefSeq_gene_array{TOT_counter} = related_RefSeq;
                TOT_Eval_array(TOT_counter)        = Eval_RefSeq;
            end
            tline = fgetl(fid);
            END= length(tline)>6 && ~strcmp(tline(1:6),'table2') || ~ischar(tline);
        end
        RefSeq_gene_array{counter} = RefSeq_gene;
        related_array{counter}     = related;
        Delegate_Eval_vec(counter) = Delegate_Eval;
    else
        tline = fgetl(fid);
        if ~ischar(tline) , break, end
    end
end
fclose(fid);
relatedgenes_HASH            = containers.Map(RefSeq_gene_array, related_array);
Delegate_Eval_HASH           = containers.Map(RefSeq_gene_array, Delegate_Eval_vec);
TOT_relatedgenes_EVAL_HASH   = containers.Map(TOT_RefSeq_gene_array, TOT_Eval_array);

fprintf('\n');
