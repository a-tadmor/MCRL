function write_params(IN,OUTFILE,start,finish,dt,blastall_command, val_N_THREADS, val_N_THREADS_BLAST)
% <-- MCRL_MAIN.m
fprintf('Writing output file: %s\n\n',OUTFILE{1});
global PROG_NAME;
global blast_ver

fid2 = fopen(OUTFILE{1},'w');

% GATHER SYSTEM INFORMATION
fprintf(fid2, 'SYSTEM INFORMATION:\n');
fprintf(fid2, '-------------------\n');

try
    [~, computer_name] = system('hostname');
    fprintf(fid2,'Host name = %s\n',computer_name);
catch
    fprintf(fid2,'Cannot resolve host name\n');
end
fprintf(fid2,'Matlab version = %s\n',version);
v=ver; 
for i=1:length(v)
    if ~isempty(strfind(lower(v(i).Name),'parallel'))
        fprintf(fid2,'Parallel toolbox found = %s %s %s %s\n',v(i).Name,v(i).Version,v(i).Release,v(i).Date);
    end
end

fprintf(fid2,'Operating system detected = %s\n',computer);
fprintf(fid2,'Path = %s\n\n',pwd);

% GATHER METACAT RUN INFORMATION
fprintf(fid2,'\n%s %s RUN SUMMARY:\n',PROG_NAME,IN.version);
fprintf(fid2, '--------------------------\n');

switch IN.ALIGNER_METHOD
    case 'blast'
        
        fprintf(fid2,'blast version: %s\n',blast_ver);
    case 'diamond'
        if isunix
            QUOTE = '''';
        else
            QUOTE = '"';
        end
        [s, result]=system([QUOTE IN.val_DIAMOND_BIN_FOLDER 'diamond' QUOTE ' version']);
        if s==0
            fprintf(fid2,'DIAMOND aligner: %s\n', strtrim(result));
        else
            fprintf(fid2,'DIAMOND aligner: N/A\n');
        end
end

if exist('blastall_command','var') && ~isempty(blastall_command)
    % BLAST EXECUTION INFO:
    fprintf(fid2,'%s command(s) executed:\n', upper(IN.ALIGNER_METHOD));
    for i=1:length(blastall_command)
        fprintf(fid2,'%s\n',blastall_command{i});
    end

    fprintf(fid2,'\nBLAST START TIME %s %dh%dm%ds\n' ,start.blast_date, round(start.blast_time(4:end)));
    fprintf(fid2,'BLAST END TIME   %s %dh%dm%ds\n'  ,finish.blast_date, round(finish.blast_time(4:end)));
    fprintf(fid2,'Run time = %.2f hours\n\n',dt.blast/3600);
end

fprintf(fid2,'MCRL START TIME %s %dh%dm%ds\n'   ,start.metaminer_date, round(start.metaminer_time(4:end)));
fprintf(fid2,'MCRL END TIME   %s %dh%dm%ds\n'  ,finish.metaminer_date, round(finish.metaminer_time(4:end)));
fprintf(fid2,'Run time = %.2f hours\n\n',dt.MCRL/3600);

fprintf(fid2,'\nINPUT PARAMETERS FOR MCRL:\n');
fprintf(fid2,'-----------------------------\n');
fprintf(fid2,'Number of threads used for %s = %d\n',PROG_NAME, val_N_THREADS);
fprintf(fid2,'Number of threads used by aligner (%s) = %d\n',IN.Aligner, val_N_THREADS_BLAST);

names = fieldnames(IN);

for i=1:length(names)
    next_field = getfield(IN,names{i});
    if ischar(next_field)
        fprintf(fid2,'%s = %s\n',names{i}, next_field);
    else
        fprintf(fid2,'%s = %g\n',names{i}, next_field);
    end
end

fprintf(fid2,'\nOUTPUT FILES GENERATED:\n');
fprintf(fid2,'-----------------------\n');
for i = 1:length(OUTFILE)
    fprintf(fid2,'%s\n',OUTFILE{i});
end

fclose(fid2);


