function correct_blast_is_installed = is_blast_installed(BLAST_BIN_FOLDER)
% Is correct version of BLAST installed and source code located
global blast_ver

correct_blast_is_installed     = 0;    % found blastp installed 

% is blasp on a global path? - if yes the user just needs to locate the bin folder
% [stat msg] = system('blastp -version');

% check if BLAST_BIN_FOLDER exists

% check if 'blastp' exists in bin folder (note: on some platforms blastp is added to the global path)
%if stat~=0 && exist(BLAST_BIN_FOLDER)
if exist(BLAST_BIN_FOLDER, 'dir')
    cur_path = pwd;
    cd(BLAST_BIN_FOLDER);
    % even if blastp is on the global path, if a blastp is in the directory, its version will be returned
    [stat, msg] = system(['.' filesep 'blastp -version']);
    cd(cur_path);
    if stat==0 && ~isempty(strfind(msg,blast_ver))
        % it's the right version!
        correct_blast_is_installed =1;
    end

end
% check if version is correct




