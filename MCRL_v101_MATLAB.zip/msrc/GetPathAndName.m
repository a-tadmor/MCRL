function [filename_nospaces, fullfilename_nospaces, success, BAD_METAGENOME_FORMAT] = GetPathAndName(fullfilename, action, COMMAND_LINE, RUN_ID)
% remove spaces and copy file to appropriate local directory needed to run blast

if ~exist('action','var')
    action = [];
    fprintf('error\n')
    keyboard
end

if ~exist('COMMAND_LINE','var')
    COMMAND_LINE=0;
end

switch action
    case {'blast_GUI'}
        success = 1;
        BAD_METAGENOME_FORMAT=0;
        [pth, name, ext]        = fileparts(fullfilename);
        filename              = [name ext];
        filename_nospaces     = filename;
        fullfilename_nospaces = []; % not used
        return
        
    case {'blast_rerun'}
        success = 1;
        BAD_METAGENOME_FORMAT=0;
        [pth, name, ext]        = fileparts(fullfilename);
        name2 = sprintf('%s_%s', RUN_ID, name);
        filename              = [name ext]; % do not add RUN_ID for rerun
        filename_nospaces     = [name2 ext];
        if isempty(pth)
            % If no path was provided then assume output directory
            fullfilename_nospaces = ['..' filesep 'output' filesep filename];
        else
            fullfilename_nospaces = fullfilename;
        end
        return
        
    case {'blast'}
        success = 1;
        BAD_METAGENOME_FORMAT=0;
        [pth, name, ext]        = fileparts(fullfilename);
        name = sprintf('%s_%s', RUN_ID, name);
        filename              = [name ext];
        filename_nospaces     = filename;
        if isempty(pth)
            % If no path was provided then assume output directory
            fullfilename_nospaces = ['..' filesep 'output' filesep filename];
        else
            fullfilename_nospaces = [pth filesep filename];
        end
        return
        
    case {'refseq', 'metagenome'}
        success = 1;
        BAD_METAGENOME_FORMAT=0;
        [pth, name, ext]        = fileparts(fullfilename);
        name = sprintf('%s_%s', RUN_ID, name);
        filename              = [name ext];
        filename_nospaces     = filename;
        
    case 'CHECK_FILE_EXISTS'
        success = 1;
        BAD_METAGENOME_FORMAT=0;
        [pth, name, ext]        = fileparts(fullfilename);
        filename              = [name ext];
        filename_nospaces     = filename;
        fullfilename_nospaces = fullfilename;
        
    otherwise
        fprintf('unknown action\n')
        keyboard
        
end

% from here eon action = metagenome or refseq or CHECK_FILE_EXISTS:

if exist('action','var') && ~isempty(action)
    % check if file exists
    if strcmp(action,'CHECK_FILE_EXISTS')
        if exist(fullfilename,'file')==0
            if ~COMMAND_LINE
                h=warndlg(sprintf('%s does not exist',fullfilename),'Notice');
                uiwait(h);
            else
                error('The input file ''%s'' does not exist',fullfilename);
            end
            success = 0;
            return
        end
        return
    end
    
    % from here on action = metagenome or refseq 

    % remove spaces from file name
    spaces = find(filename==' ');
    if ~isempty(spaces)
        filename_nospaces(spaces)='_';
    end
    
    % local path (legal format for blast)
    switch action
        case {'refseq','metagenome'}
            filepath_withsep  = ['..' filesep 'tmp' filesep];
            
        otherwise
            % debugging
            if isempty(action)
                action = '';
            end
            fprintf('debug %s.m: unknown action %s\n',mfilename,action)
            success = 0;
            return
    end
    
    % all spaces must be removed from file name
    fullfilename_nospaces = [filepath_withsep filename_nospaces];
    
    % Copy files to local directory with RUN_ID
    fprintf('Copying file with RUN_ID=%s to local MCRL tmp folder: %s->%s\n',RUN_ID, fullfilename,fullfilename_nospaces);
    if exist(fullfilename_nospaces,'file')
        fprintf('--> need to delete previous temporary metagenome FASTA file %s\n',fullfilename_nospaces);
        delete(fullfilename_nospaces);
    end
    [s, m, id] = copyfile(fullfilename, fullfilename_nospaces, 'f');
    
    % START Aug 2019
    % Swap +/- symbols with _ from metagenom fasta file
    switch action
        case 'metagenome'
            fprintf('Checking format of metagenome FASTA file...\n');
            % Confirm records don't contain +/- symbols. If so, copy to new file
            %G = fastaread(fullfilename_nospaces); % % requires Bioinforamtics toolbox -> canceled
            G = FASTAread(fullfilename_nospaces,[],[], COMMAND_LINE); % v301
            
            for i=1:length(G)
                if ~isempty(strfind(G(i).Header,'-')) || ~isempty(strfind(G(i).Header,'+'))
                    BAD_METAGENOME_FORMAT = 1;
                    G(i).Header(G(i).Header=='-') = '_';
                    G(i).Header(G(i).Header=='+') = '_';
                end
            end
            if BAD_METAGENOME_FORMAT
                fprintf('Need to substitute +/- symbols with underscore\n');
                fprintf('\t --> need to delete current temporary metagenome FASTA file %s\n',fullfilename_nospaces);
                delete(fullfilename_nospaces);
                
                filename_nospaces= ['no_pm_' filename_nospaces];
                filepath_withsep = ['..' filesep 'tmp' filesep]; 
                
                fullfilename_nospaces = [filepath_withsep filename_nospaces];
                if exist(fullfilename_nospaces,'file')
                    fprintf('--> need to delete previous temporary ''no_pm'' metagenome FASTA file %s\n',fullfilename_nospaces);
                    delete(fullfilename_nospaces);
                end
                fprintf('writing new metagenome FASTA file %s\n',fullfilename_nospaces);
                % fastawrite(fullfilename_nospaces, G); % requires Bioinforamtics toolbox -> canceled
                FASTAwrite(fullfilename_nospaces, G, COMMAND_LINE);   % v310
            else
                fprintf('OK\n');
            end
    end
    % END Aug 2019
end

