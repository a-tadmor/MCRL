function check_header(HEADER, FASTA_filename, COMMAND_LINE)
%<--fastaread_fun.m

HEADER = strtrim(HEADER);
if isempty(HEADER)
    fprintf('%s.m Error: Detected empty header in ''%s''\n',mfilename,FASTA_filename);
    if ~COMMAND_LINE
        h=errordlg(sprintf('Detected empty header in ''%s''',FASTA_filename));
        uiwait(h);
        error('Detected empty header in ''%s''', FASTA_filename);
    else
        error('Detected empty header in ''%s''', FASTA_filename);
    end
    keyboard
end


