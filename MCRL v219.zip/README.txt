MCRL - Metagenome Clustering by Reference Library

RELEASE
v2.1.6 (April 2019)

AUTHORS
Arbel D. Tadmor(1,2)
1) TRON - Translational Oncology at the University Medical Center of the Johannes Gutenberg, University Mainz, 55131, Mainz, Germany
2) Department of Biochemistry and Molecular Biophysics, California Institute of Technology, Pasadena, CA 91125, USA

SYSTEM REQUIREMENTS
* Matlab 2014a or later 
* Bioinformatics toolbox 
* Parallel Computing toolbox v4.2 or higher (optional) 
* Installation of MetaCAT requires an internet connection 

MCRL is platform independent.

INSTALLATION INSTRUCTIONS
1. Extract the compressed sources of MCRL locally 
2. Start up Matlab 
3. Change directories in Matlab to the 'bin' folder of MCRL 
4. Run MCRL by typing MCRL_EXE in the Matlab command prompt 
5. Click �Automatic installation (recommended)� 
6. Once the installation of BLAST starts click �next� and accept all of the default entries. Once blast is locally installed MCRL will proceed to download and assemble the most recent viral RefSeq database.
7. Once the main interface of MCRL loads you may start using MCRL. 

It is recommended to install MCRL as the root/administrator and disable the firewall for the installation.

Installation may take 10 to 20 minutes depending on the computer and interent connection speed.

USER GUIDE
For more detailed information regarding installation and use of MCRL please refer to the user guide (MCRL user guide.pdf).

LICENSE AGREENENT 
By using this program you agree to the terms provided in the license agreement (License.txt).



