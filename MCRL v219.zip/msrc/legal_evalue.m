function good = legal_evalue(x)

good = 0;
if isempty(x) || length(x)>1 || ~isempty(x) && (x<0 || x>1)  
    % invalid entry
    errordlg('E value must be a postive number < 1 (e.g. 0.001 or 1e-3)')
    return
end
good = 1;